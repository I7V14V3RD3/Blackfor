package mx.com.tecnetia.orthogonal.utils.crypto;

import lombok.extern.log4j.Log4j2;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;


@Log4j2
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(MockitoExtension.class)
class ApacheCryptoTest {
    private static ApacheCrypto apacheCrypto;

    @BeforeAll
    static void setUp() {
        apacheCrypto = new ApacheCrypto();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    @Order(1)
    @DisplayName("Encripta una cadena")
    void encrypt() {
        var str = "Esta es la cadena a encriptar";
        var encriptada = apacheCrypto.encrypt(str);
        var desencriptada = apacheCrypto.decrypt(encriptada);
        log.info("Dentro encrypt");
        assertEquals(str, desencriptada, "Las cadenas no son iguales");
    }

    @Test
    @Order(2)
    void decrypt() {
        log.info("Dentro decrypt");
    }

    @ParameterizedTest
    @ValueSource(strings = {"primero", "segundo"})
    void parametrizado(String cadena) {
        log.info("paramétro: {}", cadena);
        log.info("Dentro parametrizado");
    }
}
