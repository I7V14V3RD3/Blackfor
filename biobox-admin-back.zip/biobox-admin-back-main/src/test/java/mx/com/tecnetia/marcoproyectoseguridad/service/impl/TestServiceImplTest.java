package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.TestService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.LongStream;

import static org.junit.jupiter.api.Assertions.*;

class TestServiceImplTest {

    TestService testService = new TestServiceImpl();

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getTest() {
    }

    @Test
    void reciclarSync() {
        ExecutorService executorService = Executors.newFixedThreadPool(5);
        Long[] numbers = new Long[]{4L, 5L, 6L, 4L, 7L};
        try {
            for (var num : numbers) {
                executorService.submit(() -> this.testService.reciclarConcurrent(num));
            }
        } finally {
            executorService.shutdown();
        }

    }

    @Test
    void reciclarConcurrent() throws InterruptedException {
        var runs = new ArrayList<Runnable>();
        var ids = new Long[]{4L, 5L, 6L, 4L, 7L, 8L, 45L, 3L, 8L, 5L};
        var threads = new ArrayList<Thread>();
        var count = 0;
        for (var id : ids) {
            runs.add(() -> {
                this.testService.reciclarConcurrent(id);
            });
            threads.add(new Thread(runs.get(count++)));
        }
        threads.forEach(Thread::start);
        threads.forEach(t -> {
            try {
                t.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
    }
}
