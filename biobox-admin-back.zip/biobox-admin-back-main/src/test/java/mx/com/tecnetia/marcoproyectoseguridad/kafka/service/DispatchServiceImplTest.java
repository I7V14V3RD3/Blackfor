package mx.com.tecnetia.marcoproyectoseguridad.kafka.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DispatchServiceImplTest {
    DispatchServiceImpl service = new DispatchServiceImpl();

    @BeforeEach
    void setUp() {
        service = new DispatchServiceImpl();
    }

    @Test
    void process() {
        service.process("payload");
    }
}
