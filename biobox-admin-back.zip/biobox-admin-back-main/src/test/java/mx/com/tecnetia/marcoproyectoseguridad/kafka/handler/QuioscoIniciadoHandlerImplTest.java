package mx.com.tecnetia.marcoproyectoseguridad.kafka.handler;

import mx.com.tecnetia.marcoproyectoseguridad.kafka.service.DispatchService;
import mx.com.tecnetia.marcoproyectoseguridad.kafka.service.DispatchServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class QuioscoIniciadoHandlerImplTest {
    private QuioscoIniciadoHandlerImpl handler;
    private DispatchService dispatchServiceMock;

    @BeforeEach
    void setUp() {
        this.dispatchServiceMock = mock(DispatchServiceImpl.class);
        handler = new QuioscoIniciadoHandlerImpl(dispatchServiceMock);
    }

    @Test
    void listen() {
        handler.listen("payload");
        verify(dispatchServiceMock, times(1)).process("payload");
    }
}
