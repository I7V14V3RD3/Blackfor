package mx.com.tecnetia.orthogonal.utils.crypto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.time.LocalDate;

class AESUtilsTest {
    @Test
    void givenString_whenEncrypt_thenSuccess() {

        String input = "baeldung";
        SecretKey key = AESUtils.generateKey(256);
        IvParameterSpec ivParameterSpec = AESUtils.generateIv();
//     AES/GCM/NoPadding     AES/CBC/PKCS5Padding
        String algorithm = "AES/CBC/PKCS5Padding";

        String cipherText = AESUtils.encrypt(algorithm, input, key, ivParameterSpec);
        String plainText = AESUtils.decrypt(algorithm, cipherText, key, ivParameterSpec);
        Assertions.assertEquals(input, plainText, "Ambas cadenas deben ser iguales.");
    }

    @Test
    void testingDates() {
        var enero = LocalDate.of(2024, 1, 1);
        var diciembre = enero.getMonth().minus(1).getValue();
        var anioDiciembre = enero.minusMonths(1).getYear();

        System.out.println("diciembre: " + diciembre);
        System.out.println("anioDiciembre: " + anioDiciembre);
    }

}
