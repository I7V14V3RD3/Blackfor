package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "punto_reciclaje")
public class PEntityPuntoReciclaje {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_punto_reciclaje")
    private Long idPuntoReciclaje;
    @Basic
    @Column(name = "latitud")
    private String latitud;
    @Basic
    @Column(name = "longitud")
    private String longitud;
    @Basic
    @Column(name = "qr_generado")
    private String qrGenerado;
    @OneToMany(mappedBy = "puntoReciclajeByIdPuntoReciclaje")
    private Collection<PEntityRecicladoLote> recicladoLotesByIdPuntoReciclaje;
}
