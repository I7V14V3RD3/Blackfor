package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.*;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos.ProductoPuntosDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityProductoReciclable;
import org.apache.logging.log4j.core.config.plugins.validation.constraints.NotBlank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PEntityProductoReciclableRepository extends JpaRepository<PEntityProductoReciclable, Long> {
    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.FabricanteDTO(
                ent.idFabricante, ent.nombre)
            from PEntityFabricante ent
            order by ent.nombre
            """)
    List<FabricanteDTO> getCatalogoFabricantes();

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.MarcaDTO(
                ent.idMarca, ent.nombre)
            from PEntityMarca ent
            order by ent.nombre
            """)
    List<MarcaDTO> getCatalogoMarcas();

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.SubMarcaDTO(
                m.idMarca, sm.idSubMarca, sm.nombre)
            from PEntitySubMarca sm
                join sm.marcaByIdMarca m
            order by sm.nombre
            """)
    List<SubMarcaDTO> getCatalogoSubMarcas();

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.SubMarcaDTO(
                m.idMarca, sm.idSubMarca, sm.nombre)
            from PEntitySubMarca sm
                join sm.marcaByIdMarca m
                where m.idMarca = :idMarca
            order by sm.nombre
            """)
    List<SubMarcaDTO> getCatalogoSubMarcas(@Param("idMarca") Long idMarca);

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.UnidadMedidaDTO(
                ent.idUnidadMedida, ent.nombre)
            from PEntityUnidadMedida ent
            order by ent.nombre
            """)
    List<UnidadMedidaDTO> getCatalogoUnidadesMedida();

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.MaterialDTO(
                ent.idMaterial, ent.nombre)
            from PEntityMaterial ent
            order by ent.nombre
            """)
    List<MaterialDTO> getCatalogoMateriales();

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.ProductoReciclableDTO(
                ent.idProductoReciclable, ent.sku, ent.barCode, ent.idMaterial, ent.idSubMarca,ent.idFabricante, um.idUnidadMedida,
                cap.cantidad, ent.pesoMinimo,ent.pesoMaximo, pp.puntos)
            from PEntityProductoReciclable ent
                join ent.capacidad cap
                join cap.unidadMedidaByIdUnidadMedida um
                join PEntityProductoReciclableColorPuntos pp on (pp.idProductoReciclable = ent.idProductoReciclable and pp.fechaFin is null)
            where ent.sku = :sku
            """)
    Optional<ProductoReciclableDTO> getBySKU(@Param("sku") @NotBlank String sku);

    @Query("""
                select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos.ProductoPuntosDTO(
                    ent.idProductoReciclableColorPuntos, ent.idProductoReciclable, ent.puntos, pr.sku, sm.nombre, marca.nombre,
                    concat(capacidad.cantidad,' ',um.siglas))
                from PEntityProductoReciclableColorPuntos ent
                    join ent.productoReciclableByIdProductoReciclable pr
                    join pr.subMarca sm
                    join sm.marcaByIdMarca marca
                    join pr.capacidad capacidad
                    join capacidad.unidadMedidaByIdUnidadMedida um
            
                where ent.fechaFin is null
                order by marca.idMarca, sm.idSubMarca, pr.sku
            """)
    List<ProductoPuntosDTO> getProductosPuntos();

    boolean existsBySku(@NotBlank String sku);

    boolean existsBySkuOrBarCode(String sku, String barCode);
}
