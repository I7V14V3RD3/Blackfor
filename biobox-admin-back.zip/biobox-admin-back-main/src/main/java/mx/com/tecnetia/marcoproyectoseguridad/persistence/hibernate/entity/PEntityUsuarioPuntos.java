package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "usuario_puntos")
public class PEntityUsuarioPuntos {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_usuario_puntos")
    private Long idUsuarioPuntos;
    @Basic
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;
    @Basic
    @Column(name = "puntos")
    private Integer puntos;
}
