package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.NuevaSubMarcaDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityFabricante;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityMarca;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntitySubMarca;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityFabricanteRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityMarcaRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntitySubMarcaRepository;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.GestionCatalogoService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class GestionCatalogoServiceImpl implements GestionCatalogoService {
    private final PEntityMarcaRepository pEntityMarcaRepository;
    private final PEntityFabricanteRepository pEntityFabricanteRepository;
    private final PEntitySubMarcaRepository pEntitySubMarcaRepository;

    @Override
    @Transactional
    public void nuevaMarca(@NotBlank String nombre) {
        nombre = nombre.toUpperCase().trim();
        if (this.pEntityMarcaRepository.findByNombre(nombre).isPresent()) {
            throw new IllegalArgumentException("Ya existe una marca con el mismo nombre");
        }
        var ent = new PEntityMarca().setNombre(nombre);
        this.pEntityMarcaRepository.save(ent);
    }

    @Override
    @Transactional
    public void nuevoFabricante(@NotBlank String nombre) {
        nombre = nombre.toUpperCase().trim();
        if (this.pEntityFabricanteRepository.findByNombre(nombre).isPresent()) {
            throw new IllegalArgumentException("Ya existe un fabricante con el mismo nombre");
        }
        var ent = new PEntityFabricante().setNombre(nombre);
        this.pEntityFabricanteRepository.save(ent);
    }

    @Override
    @Transactional
    public void nuevaSubMarca(@Valid NuevaSubMarcaDTO nuevaSubMarcaDTO) {
        nuevaSubMarcaDTO.setNombre(nuevaSubMarcaDTO.getNombre().toUpperCase().trim());
        var opt = this.pEntitySubMarcaRepository.findByNombreAndIdMarca(nuevaSubMarcaDTO.getNombre(), nuevaSubMarcaDTO.getIdMarca());
        if (opt.isPresent()) {
            throw new IllegalArgumentException("Ya existe una submarca con el mismo nombre asociada a esa marca");
        }
        var marca = this.pEntityMarcaRepository.findById(nuevaSubMarcaDTO.getIdMarca())
                .orElseThrow(() -> new IllegalArgumentException("No existe la marca especificada"));
        var ent = new PEntitySubMarca().setMarcaByIdMarca(marca).setNombre(nuevaSubMarcaDTO.getNombre());
        this.pEntitySubMarcaRepository.save(ent);
    }
}
