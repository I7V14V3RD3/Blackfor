package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "producto_reciclado")
public class PEntityProductoReciclado {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_producto_reciclado")
    private Long idProductoReciclado;
    @Basic
    @Column(name = "momento_reciclaje")
    private LocalDateTime momentoReciclaje;
    @Basic
    @Column(name = "id_producto_reciclable", insertable = false, updatable = false)
    private Long idProductoReciclable;
    @Basic
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;
    @Basic
    @Column(name = "exitoso")
    private Boolean exitoso;
    @OneToOne(mappedBy = "productoReciclado")
    private PEntityFotoProductoReciclado fotoProductoReciclado;
    @ManyToOne
    @JoinColumn(name = "id_producto_reciclable", referencedColumnName = "id_producto_reciclable", nullable = false)
    private PEntityProductoReciclable productoReciclable;
    @OneToOne(mappedBy = "productoRecicladoByIdProductoReciclado")
    private PEntityProductoRecicladoQuiosco productoRecicladoQuiosco;
    @OneToOne(mappedBy = "productoRecicladoByIdProductoReciclado")
    private PEntityRecicladoLote recicladoLoteByIdProductoReciclado;
    @OneToMany(mappedBy = "productoRecicladoByIdProductoReciclado")
    private Collection<PEntityUsuarioPuntosColorAcumulado> usuarioPuntosColorAcumulados;
}
