package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityFotoProductoReciclado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PEntityFotoProductoRecicladoRepository extends JpaRepository<PEntityFotoProductoReciclado, Long> {

    boolean existsByIdProductoRecicladoAndExitoso(Long idProductoReciclado, Boolean exitoso);
}
