package mx.com.tecnetia.orthogonal.security;

import java.util.Collection;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import org.springframework.security.core.GrantedAuthority;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO para el login del usuario. Dependiendo del tipo de usuario, el campo correspondiente contendrá la información del usuario que se logea.")
public class JwtDTO {
    @NotBlank
    private String token;
    @NotBlank
    private String bearer = "Bearer";
    @NotBlank
    private String nick;
    @NotEmpty
    private Collection<? extends GrantedAuthority> authorities;

    public JwtDTO(String token, String nick, Collection<? extends GrantedAuthority> authorities) {
        this.token = token;
        this.nick = nick;
        this.authorities = authorities;
    }


}
