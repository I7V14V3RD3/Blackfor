package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "sku_prontipago")
public class PEntitySkuProntipago {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_sku_prontipago")
    private Long idSkuProntipago;
    @Basic
    @Column(name = "id_prontipago", insertable = false, updatable = false)
    private Long idProntipago;
    @Basic
    @Column(name = "sku")
    private String sku;
    @Basic
    @Column(name = "fecha_inicio")
    private LocalDateTime fechaInicio;
    @Basic
    @Column(name = "fecha_fin")
    private LocalDateTime fechaFin;
    @ManyToOne
    @JoinColumn(name = "id_prontipago", referencedColumnName = "id_programa_prontipago", nullable = false)
    private PEntityProgramaProntipago programaProntipagoByIdProntipago;
}
