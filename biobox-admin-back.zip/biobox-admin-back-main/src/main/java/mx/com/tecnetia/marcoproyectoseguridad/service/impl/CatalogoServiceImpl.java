package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.*;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityFabricante;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityFabricanteRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityMarcaRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityProductoReciclableRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityProductoRecicladoRepository;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.CatalogoService;
import org.springframework.data.domain.Limit;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class CatalogoServiceImpl implements CatalogoService {
    private final PEntityProductoReciclableRepository pEntityProductoReciclableRepository;
    private final PEntityFabricanteRepository pEntityFabricanteRepository;
    private final PEntityMarcaRepository pEntityMarcaRepository;

    @Override
    @Transactional(readOnly = true)
    public List<UnidadMedidaDTO> getCatalogoUnidadesMedida() {
        return this.pEntityProductoReciclableRepository.getCatalogoUnidadesMedida();
    }

    @Override
    @Transactional(readOnly = true)
    public List<SubMarcaDTO> getCatalogoSubMarcas() {
        return this.pEntityProductoReciclableRepository.getCatalogoSubMarcas();
    }

    @Override
    @Transactional(readOnly = true)
    public List<SubMarcaDTO> getCatalogoSubMarcas(Long idMarca) {
        return this.pEntityProductoReciclableRepository.getCatalogoSubMarcas(idMarca);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MarcaDTO> getCatalogoMarcas() {
        return this.pEntityProductoReciclableRepository.getCatalogoMarcas();
    }

    @Override
    @Transactional(readOnly = true)
    public List<MarcaDTO> getCatalogoMarcasLike(String nombreLike) {
        return this.pEntityMarcaRepository.getCatalogoMarcasLike(nombreLike,Limit.of(1000));
    }

    @Override
    @Transactional(readOnly = true)
    public List<FabricanteDTO> getCatalogoFabricantes() {
        return this.pEntityProductoReciclableRepository.getCatalogoFabricantes();
    }

    @Override
    @Transactional(readOnly = true)
    public List<FabricanteDTO> getCatalogoFabricantesLike(String nombreLike) {
        return this.pEntityFabricanteRepository.getCatalogoFabricantesLike(nombreLike, Limit.of(1000));
    }

    @Override
    @Transactional(readOnly = true)
    public List<MaterialDTO> getCatalogoMateriales() {
        return this.pEntityProductoReciclableRepository.getCatalogoMateriales();
    }
}
