package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "media_historia")
public class PEntityMediaHistoria {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_media_historia")
    private Long idMediaHistoria;
    @Basic
    @Column(name = "id_historia", insertable = false, updatable = false)
    private Long idHistoria;
    @Basic
    @Column(name = "proxima", insertable = false, updatable = false)
    private Long proxima;
    @Basic
    @Column(name = "file")
    private byte[] file;
    @Basic
    @Column(name = "nombre_file")
    private String nombreFile;
    @Basic
    @Column(name = "ext_file")
    private String extFile;
    @Basic
    @Column(name = "url_foto")
    private String urlFoto;
    @ManyToOne
    @JoinColumn(name = "id_historia", referencedColumnName = "id_historia", nullable = false)
    private PEntityHistoria historiaByIdHistoria;
    @ManyToOne
    @JoinColumn(name = "proxima", referencedColumnName = "id_media_historia")
    private PEntityMediaHistoria mediaHistoriaByProxima;
    @OneToMany(mappedBy = "mediaHistoriaByProxima")
    private Collection<PEntityMediaHistoria> mediaHistoriasByIdMediaHistoria;
}
