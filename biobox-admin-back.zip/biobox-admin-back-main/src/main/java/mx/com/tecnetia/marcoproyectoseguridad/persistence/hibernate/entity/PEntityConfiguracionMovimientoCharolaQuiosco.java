package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "configuracion_movimiento_charola_quiosco")
public class PEntityConfiguracionMovimientoCharolaQuiosco {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_configuracion_movimiento_charola_quiosco")
    private Long idConfiguracionMovimientoCharolaQuiosco;
    @Basic
    @Column(name = "id_quiosco", insertable = false, updatable = false)
    private Long idQuiosco;
    @Basic
    @Column(name = "id_movimiento_charola", insertable = false, updatable = false)
    private Integer idMovimientoCharola;
    @Basic
    @Column(name = "id_material", insertable = false, updatable = false)
    private Integer idMaterial;
    @ManyToOne
    @JoinColumn(name = "id_quiosco", referencedColumnName = "id_quiosco", nullable = false)
    private PEntityQuiosco quioscoByIdQuiosco;
    @ManyToOne
    @JoinColumn(name = "id_movimiento_charola", referencedColumnName = "id_movimiento_charola", nullable = false)
    private PEntityMovimientoCharola movimientoCharolaByIdMovimientoCharola;
    @ManyToOne
    @JoinColumn(name = "id_material", referencedColumnName = "id_material", nullable = false)
    private PEntityMaterial materialByIdMaterial;
}
