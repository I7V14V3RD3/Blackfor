package mx.com.tecnetia.marcoproyectoseguridad.validators;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.NuevoQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityQuioscoRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Log4j2
@Component
public class NuevoQuioscoValidator implements ConstraintValidator<NuevoQuioscoConstraint, NuevoQuioscoDTO> {
    private final PEntityQuioscoRepository pEntityQuioscoRepository;

    @Override
    public void initialize(NuevoQuioscoConstraint constraintAnnotation) {
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isValid(NuevoQuioscoDTO value, ConstraintValidatorContext context) {
        if (Boolean.TRUE.equals(value.getTipoArduino()) && value.getModelo() != null) {
            context.buildConstraintViolationWithTemplate("Si es de tipo Arduino no puede tener modelo.").addConstraintViolation();
            return false;
        }
        if (Boolean.FALSE.equals(value.getTipoArduino()) && value.getModelo() == null) {
            context.buildConstraintViolationWithTemplate("Si no es de tipo Arduino debe tener un modelo.").addConstraintViolation();
            return false;
        }
        var ret = this.pEntityQuioscoRepository.existsByIpOrNombreAllIgnoreCase(value.getIp(), value.getNombre());
        if (ret) {
            context.buildConstraintViolationWithTemplate("Ya existe un quiosco con ea IP o ese nombre.").addConstraintViolation();
            return false;
        }
        return true;
    }
}
