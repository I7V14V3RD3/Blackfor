package mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NuevaSubMarcaDTO {
    @NotNull
    private Integer idMarca;
    @NotBlank
    private String nombre;
}
