package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.NuevoProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.ProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos.ProductoPuntosDTO;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ProductoReciclableService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", exposedHeaders = "Content-Disposition")
@RestController
@RequestMapping("/producto")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Productos reciclables.", description = "Operaciones con los productos reciclables.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class GestionProductoRestController {
    private final ProductoReciclableService productoReciclableService;

    @Operation(summary = "Creación", description = "Crea un producto",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Producto creado",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/")
    public ResponseEntity<Void> nuevoProducto(@RequestBody @NotNull @Valid NuevoProductoReciclableDTO dto) {
        this.productoReciclableService.nuevoProductoReciclable(dto);
        return ResponseEntity.ok(null);
    }

    @Operation(summary = "Edición", description = "Edita un producto",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Producto editado",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PutMapping(value = "/")
    public ResponseEntity<Void> editaProducto(@RequestBody @NotNull @Valid ProductoReciclableDTO dto) {
        this.productoReciclableService.editaProductoReciclable(dto);
        return ResponseEntity.ok(null);
    }

    @Operation(summary = "SKU", description = "Busca el producto dado su SKU",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Producto encontrado",
            content = @Content(schema = @Schema(implementation = ProductoReciclableDTO.class)))})
    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/")
    public ResponseEntity<ProductoReciclableDTO> productoBySKU(@RequestParam("sku") @NotBlank String sku) {
        var ent = this.productoReciclableService.getBySKU(sku);
        return ent.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.ok(null));
    }

    @Operation(summary = "Productos y puntos", description = "Todos los productos y la cantidad de puntos asociados",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de productos y sus puntos.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = ProductoPuntosDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/puntos")
    public ResponseEntity<List<ProductoPuntosDTO>> getProductosPuntos() {
        var ret = this.productoReciclableService.getProductosPuntos();
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Puntos", description = "Asigna la misma cantidad de puntos a todos los productos",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Ok",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PatchMapping(value = "/puntos-all")
    public ResponseEntity<Void> updatePuntosAllProductos(@RequestParam("puntos") Integer puntos) {
        this.productoReciclableService.updatePuntosAllProductos(puntos);
        return ResponseEntity.ok(null);
    }

    @Operation(summary = "Puntos", description = "Asigna los puntos a un producto",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Ok",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PatchMapping(value = "/puntos")
    public ResponseEntity<Void> updatePuntosOneProducto(@RequestParam("puntos") Integer puntos,
                                                        @RequestParam("id") Long id) {
        this.productoReciclableService.updatePuntosOneProducto(puntos, id);
        return ResponseEntity.ok(null);
    }
}
