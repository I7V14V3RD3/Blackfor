package mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductoReciclableDTO extends NuevoProductoReciclableDTO {
    @NotNull
    @Positive
    private Long idProductoReciclable;

    public ProductoReciclableDTO(Long idProductoReciclable, @NotBlank String sku, @NotBlank String barCode, @NotNull @Positive Integer idMaterial,
                                 @NotNull @Positive Integer idSubMarca, @NotNull @Positive Integer idFabricante, @NotNull @Positive Integer idUnidadMedida,
                                 @NotNull @Positive BigDecimal capacidad, @NotNull @Positive BigDecimal pesoMinimo,
                                 @NotNull @Positive BigDecimal pesoMaximo, Integer puntos) {
        super(sku, barCode, idMaterial, idSubMarca, idFabricante, idUnidadMedida, capacidad, pesoMinimo, pesoMaximo, puntos);
        this.idProductoReciclable = idProductoReciclable;
    }
}
