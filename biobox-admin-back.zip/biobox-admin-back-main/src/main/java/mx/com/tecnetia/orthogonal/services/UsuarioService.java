package mx.com.tecnetia.orthogonal.services;

import mx.com.tecnetia.orthogonal.persistence.hibernate.entity.ArqUsuarioEntity;
import mx.com.tecnetia.orthogonal.security.NuevoUsuarioArquitecturaDTO;
import mx.com.tecnetia.orthogonal.security.UsuarioPrincipal;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface UsuarioService {
    Optional<ArqUsuarioEntity> getByNick(String nu);

    Optional<ArqUsuarioEntity> getByEmail(String email);

    boolean existePorNick(String nu);

    boolean existePorEmail(String email);

    ArqUsuarioEntity guardar(ArqUsuarioEntity usuario);

    ArqUsuarioEntity guardar(NuevoUsuarioArquitecturaDTO nuevoUsuario);

    boolean cambiaContrasena(Long idUsuario, String anterior, String nueva);

    String generaToken(@Email @NotEmpty String email);

    void cambiaPassw(UsuarioPrincipal usuarioLogeado, String passw);

    ArqUsuarioEntity getUsuarioLogeado();

    @Transactional(readOnly = true)
    Long getIdUsuarioLogeado();

    void desactivaUsuario(Long idArqUsuario);
}
