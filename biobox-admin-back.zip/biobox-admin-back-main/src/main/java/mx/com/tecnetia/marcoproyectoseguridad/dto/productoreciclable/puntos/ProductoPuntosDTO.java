package mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductoPuntosDTO {
    private Long idProductoReciclablePuntos;
    private Long idProductoReciclable;
    private Integer puntos;
    private String sku;
    private String submarcaNombre;
    private String marcaNombre;
    private String capacidad;
}
