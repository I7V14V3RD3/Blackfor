package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "fabricante")
public class PEntityFabricante {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_fabricante")
    private Integer idFabricante;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @OneToMany(mappedBy = "fabricante")
    private Collection<PEntityProductoReciclable> productoReciclablesByIdFabricante;
}
