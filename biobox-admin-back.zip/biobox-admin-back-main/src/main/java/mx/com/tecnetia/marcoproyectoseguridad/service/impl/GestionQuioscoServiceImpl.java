package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import com.github.f4b6a3.uuid.UuidCreator;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.ModeloQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.NuevoQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QRQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoCreadoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.mapper.PEntityQuioscoMapper;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityQuiosco;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityModeloQuioscoRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityQuioscoRepository;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.GestionQuioscoService;
import mx.com.tecnetia.marcoproyectoseguridad.validators.NuevoQuioscoConstraint;
import mx.com.tecnetia.orthogonal.utils.image.QRUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class GestionQuioscoServiceImpl implements GestionQuioscoService {
    private static final Pattern uuidRegex = Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");
    private static final String QUIOSCO_NO_ENCONTRADO = "No se encontró el quiosco especificado";

    private final PEntityQuioscoRepository pEntityQuioscoRepository;
    private final PEntityQuioscoMapper pEntityQuioscoMapper;
    private final PEntityModeloQuioscoRepository pEntityModeloQuioscoRepository;
    @Resource
    @Lazy
    private GestionQuioscoServiceImpl gestionQuioscoService;

    @Override
    @Transactional
    public QuioscoCreadoDTO nuevoQuiosco(@NotNull @Valid @NuevoQuioscoConstraint NuevoQuioscoDTO nuevoDTO) {
        var ent = this.pEntityQuioscoMapper.toEntity(nuevoDTO);
        var qr = UuidCreator.getTimeOrderedEpoch();
        ent.setQr(qr);
        verificaModelo(nuevoDTO, ent);
        this.pEntityQuioscoRepository.save(ent);
        return new QuioscoCreadoDTO(qr.toString());
    }

    @Override
    @Transactional
    public QRQuioscoDTO nuevoQuioscoQR(NuevoQuioscoDTO nuevoDTO) {
        var quiosco = gestionQuioscoService.nuevoQuiosco(nuevoDTO);
        byte[] bytes = QRUtils.generaImagenQR(quiosco.getQr());
        return new QRQuioscoDTO(quiosco.getQr(), bytes);
    }

    private void verificaModelo(NuevoQuioscoDTO nuevoDTO, PEntityQuiosco ent) {
        if (nuevoDTO.getModelo() != null && !nuevoDTO.getTipoArduino()) {
            var modelo = this.pEntityModeloQuioscoRepository.findByNombreIgnoreCase(nuevoDTO.getModelo())
                    .orElseThrow(() -> new IllegalArgumentException("El modelo especificado no se encuentra en la BD."));
            ent.setModeloQuiosco(modelo);
            ent.setTipoArduino(false);
        } else {
            ent.setModeloQuiosco(null);
            ent.setTipoArduino(true);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuioscoDTO> getQuioscosByDireccionSimilar(@NotBlank String dir) {
        var localeMx = new Locale("es", "MX");
        return this.pEntityQuioscoRepository.getQuioscosByDireccionSimilar(dir.toUpperCase(localeMx));
    }

    @Override
    @Transactional(readOnly = true)
    public List<QuioscoDTO> getAllQuioscos() {
        return this.pEntityQuioscoRepository.getAllQuioscos();
    }

    @Override
    @Transactional
    public void editarQuiosco(QuioscoDTO dto) {
        var ent = this.pEntityQuioscoRepository.findById(dto.getIdQuiosco())
                .orElseThrow(() -> new IllegalArgumentException(QUIOSCO_NO_ENCONTRADO));
        var qr = ent.getQr();
        ent = this.pEntityQuioscoMapper.partialUpdate(dto, ent);
        ent.setQr(qr);
        verificaModelo(dto, ent);
        this.pEntityQuioscoRepository.save(ent);
    }

    @Override
    @Transactional
    public String editarQuioscoConNuevoQR(QuioscoDTO dto) {
        var ent = this.pEntityQuioscoRepository.findById(dto.getIdQuiosco())
                .orElseThrow(() -> new IllegalArgumentException(QUIOSCO_NO_ENCONTRADO));
        var qr = UuidCreator.getTimeOrderedEpoch();
        ent = this.pEntityQuioscoMapper.partialUpdate(dto, ent);
        ent.setQr(qr);
        verificaModelo(dto, ent);
        this.pEntityQuioscoRepository.save(ent);
        return qr.toString();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ModeloQuioscoDTO> getAllModelosQuiosco() {
        return this.pEntityQuioscoRepository.getAllModelosQuiosco();
    }

    /*Para usar solo 1 vez*/
    @Override
    @Transactional
    public void creaTodosQRValidos() {
        var quioscos = this.pEntityQuioscoRepository.findAll();
        if (!quioscos.isEmpty()) {
            quioscos.forEach((PEntityQuiosco q) -> {
                if (!uuidRegex.matcher(q.getQr().toString()).matches()) {
                    q.setQr(UuidCreator.getTimeOrderedEpoch());
                }
            });
            this.pEntityQuioscoRepository.saveAll(quioscos);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public QRQuioscoDTO generaImagenQR(Long idQuiosco) {
        var ent = this.pEntityQuioscoRepository.findById(idQuiosco)
                .orElseThrow(() -> new IllegalArgumentException(QUIOSCO_NO_ENCONTRADO));
        var bytes = QRUtils.generaImagenQR(ent.getQr().toString());
        return new QRQuioscoDTO(ent.getQr().toString(), bytes);
    }

    @Override
    @Transactional
    public void deleteQuiosco(Long idQuiosco) {
        var ent = this.pEntityQuioscoRepository.findById(idQuiosco)
                .orElseThrow(() -> new IllegalArgumentException(QUIOSCO_NO_ENCONTRADO));
        this.pEntityQuioscoRepository.delete(ent);
    }

}
