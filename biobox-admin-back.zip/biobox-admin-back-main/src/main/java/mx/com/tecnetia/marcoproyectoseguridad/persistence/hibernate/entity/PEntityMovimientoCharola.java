package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "movimiento_charola")
public class PEntityMovimientoCharola {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_movimiento_charola")
    private Integer idMovimientoCharola;
    @Basic
    @Column(name = "codigo")
    private String codigo;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "descripcion")
    private String descripcion;
    @OneToMany(mappedBy = "movimientoCharolaByIdMovimientoCharola")
    private Collection<PEntityConfiguracionMovimientoCharolaQuiosco> configuracionMovimientoCharolaQuioscosByIdMovimientoCharola;
}
