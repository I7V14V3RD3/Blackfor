package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "reciclado_lote")
public class PEntityRecicladoLote {
    @Id
    @Column(name = "id_producto_reciclado")
    private Long idProductoReciclado;
    @Basic
    @Column(name = "id_punto_reciclaje", insertable = false, updatable = false)
    private Long idPuntoReciclaje;
    @ManyToOne
    @JoinColumn(name = "id_punto_reciclaje", referencedColumnName = "id_punto_reciclaje", nullable = false)
    private PEntityPuntoReciclaje puntoReciclajeByIdPuntoReciclaje;
    @OneToOne
    @JoinColumn(name = "id_producto_reciclado", referencedColumnName = "id_producto_reciclado", nullable = false)
    private PEntityProductoReciclado productoRecicladoByIdProductoReciclado;
}
