package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.FabricanteDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityFabricante;
import org.springframework.data.domain.Limit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PEntityFabricanteRepository extends JpaRepository<PEntityFabricante, Integer> {
    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.FabricanteDTO(
                ent.idFabricante, ent.nombre)
            from PEntityFabricante ent
            where ent.nombre like %:likeNombre%
            order by ent.nombre
            """)
    List<FabricanteDTO> getCatalogoFabricantesLike(@Param("likeNombre") String likeNombre, Limit limit);
    Optional<PEntityFabricante> findByNombre(String nombre);
}
