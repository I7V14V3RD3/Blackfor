package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "ayuda")
public class PEntityAyuda {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_ayuda")
    private Integer idAyuda;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "anterior", insertable = false, updatable = false)
    private Integer anterior;
    @Basic
    @Column(name = "file")
    private byte[] file;
    @Basic
    @Column(name = "nombre_file")
    private String nombreFile;
    @Basic
    @Column(name = "ext_file")
    private String extFile;
    @Basic
    @Column(name = "texto")
    private String texto;
    @Basic
    @Column(name = "url_foto")
    private String urlFoto;
    @ManyToOne
    @JoinColumn(name = "anterior", referencedColumnName = "id_ayuda")
    private PEntityAyuda ayudaByAnterior;
    @OneToMany(mappedBy = "ayudaByAnterior")
    private Collection<PEntityAyuda> ayudasByIdAyuda;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PEntityAyuda that = (PEntityAyuda) o;
        return Objects.equals(idAyuda, that.idAyuda) && Objects.equals(nombre, that.nombre) && Objects.equals(anterior, that.anterior) && Arrays.equals(file, that.file) && Objects.equals(nombreFile, that.nombreFile) && Objects.equals(extFile, that.extFile) && Objects.equals(texto, that.texto) && Objects.equals(urlFoto, that.urlFoto);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(idAyuda, nombre, anterior, nombreFile, extFile, texto, urlFoto);
        result = 31 * result + Arrays.hashCode(file);
        return result;
    }
}
