package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "grado_jerarquico")
public class PEntityGradoJerarquico {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_grado_jerarquico")
    private Long idGradoJerarquico;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "descripcion")
    private String descripcion;
    @Basic
    @Column(name = "anterior", insertable = false, updatable = false)
    private Long anterior;
    @Basic
    @Column(name = "imagen")
    private byte[] imagen;
    @Basic
    @Column(name = "url_foto")
    private String urlFoto;
    @ManyToOne
    @JoinColumn(name = "anterior", referencedColumnName = "id_grado_jerarquico")
    private PEntityGradoJerarquico gradoJerarquicoByAnterior;
    @OneToMany(mappedBy = "gradoJerarquicoByAnterior")
    private Collection<PEntityGradoJerarquico> gradoJerarquicosByIdGradoJerarquico;
    @OneToMany(mappedBy = "gradoJerarquicoByIdGradoJerarquico")
    private Collection<PEntityRequisitoGrado> requisitoGradosByIdGradoJerarquico;
    @OneToMany(mappedBy = "gradoJerarquicoByIdGradoJerarquico")
    private Collection<PEntityUsuarioGrado> usuarioGradosByIdGradoJerarquico;
}
