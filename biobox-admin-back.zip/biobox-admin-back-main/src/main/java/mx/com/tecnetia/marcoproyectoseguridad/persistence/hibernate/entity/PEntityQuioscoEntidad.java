package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "quiosco_entidad")
public class PEntityQuioscoEntidad {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_quiosco_entidad")
    private Long idQuioscoEntidad;
    @Basic
    @Column(name = "id_quiosco", insertable = false, updatable = false)
    private Long idQuiosco;
    @Basic
    @Column(name = "id_entidad_reciclaje", insertable = false, updatable = false)
    private Long idEntidadReciclaje;
    @Basic
    @Column(name = "fecha_inicio")
    private LocalDateTime fechaInicio;
    @Basic
    @Column(name = "fecha_fin")
    private LocalDateTime fechaFin;
    @ManyToOne
    @JoinColumn(name = "id_quiosco", referencedColumnName = "id_quiosco", nullable = false)
    private PEntityQuiosco quioscoByIdQuiosco;
    @ManyToOne
    @JoinColumn(name = "id_entidad_reciclaje", referencedColumnName = "id_entidad_reciclaje", nullable = false)
    private PEntityEntidadReciclaje entidadReciclajeByIdEntidadReciclaje;
}
