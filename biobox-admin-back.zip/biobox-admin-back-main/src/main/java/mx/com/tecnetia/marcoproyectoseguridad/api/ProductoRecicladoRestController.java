package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.EstadisticaReciclajesNoExitososDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ProductoParaValidarDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ValidaReciclajeDTO;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ProductoRecicladoService;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ValidacionService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", exposedHeaders = "Content-Disposition")
@RestController
@RequestMapping("/producto-reciclado")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Producto reciclado.", description = "Operaciones con los productos reciclados.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class ProductoRecicladoRestController {
    private final ProductoRecicladoService productoRecicladoService;
    private final ValidacionService validacionService;

    @Operation(summary = "Para validar", description = "Busca todos los productos para validar dentro de un rango de fechas.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de productos para validar.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = ProductoParaValidarDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/para-validar")
    public ResponseEntity<List<ProductoParaValidarDTO>> buscarProductosParaValidar(@RequestParam(value = "fecha-inicial") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicial,
                                                                                   @RequestParam(value = "fecha-final") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFinal) {
        var ret = this.productoRecicladoService.getProductosParaValidar(fechaInicial.atStartOfDay(), fechaFinal.atStartOfDay().plusHours(23));
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Foto", description = "Foto de un producto reciclado",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Operación exitosa.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = Byte.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/foto", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<byte[]> getFotoProductoReciclado(@NotNull @RequestParam("id-producto-reciclado") Long idProductoReciclado) {
        var httpHeaders = new HttpHeaders();
        var foto = this.productoRecicladoService.getFotoReciclado(idProductoReciclado);
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
        httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, UUID.randomUUID().toString());
        return ResponseEntity.ok().headers(httpHeaders).body(foto.orElse(new byte[0]));
    }

    @Operation(summary = "Estadística", description = "Estadística de los reciclajes no exitosos",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Objeto con las estadísticas",
            content = @Content(schema = @Schema(implementation = EstadisticaReciclajesNoExitososDTO.class)))})
    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/estadistica-no-exitosos")
    public ResponseEntity<EstadisticaReciclajesNoExitososDTO> estadistica() {
        var ret = this.productoRecicladoService.getDatosRecicladosNoExitosos();
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Validacion", description = "Valida un reciclaje",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Validación realizada",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PutMapping(value = "/validacion")
    public ResponseEntity<Void> validaReciclaje(@RequestBody @NotNull @Valid ValidaReciclajeDTO dto) {
        this.validacionService.validaReciclaje(dto);
        return ResponseEntity.ok(null);
    }
}
