package mx.com.tecnetia.orthogonal.services;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.persistence.hibernate.entity.ArqUsuarioEntity;
import mx.com.tecnetia.orthogonal.persistence.hibernate.entity.ArqUsuarioRolEntity;
import mx.com.tecnetia.orthogonal.persistence.hibernate.repository.ArqClienteEntityRepository;
import mx.com.tecnetia.orthogonal.persistence.hibernate.repository.ArqRolAplicacionRepository;
import mx.com.tecnetia.orthogonal.persistence.hibernate.repository.ArqUsuarioRepository;
import mx.com.tecnetia.orthogonal.persistence.hibernate.repository.ArqUsuarioRolAplicacionEntityRepository;
import mx.com.tecnetia.orthogonal.security.NuevoUsuarioArquitecturaDTO;
import mx.com.tecnetia.orthogonal.security.UsuarioPrincipal;
import mx.com.tecnetia.orthogonal.security.auth.AuthenticationFacadeComponent;
import mx.com.tecnetia.orthogonal.utils.crypto.AES;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Log4j2
public class UsuarioServiceImpl implements UsuarioService {

    private final ArqUsuarioRepository arqUsuarioRepository;
    private final ArqRolAplicacionRepository arqRolAplicacionRepository;
    private final PasswordEncoder passwordEncoder;
    private final ArqUsuarioRolAplicacionEntityRepository arqUsuarioRolAplicacionEntityRepository;
    private final ArqClienteEntityRepository arqClienteEntityRepository;
    private final AuthenticationFacadeComponent authenticationFacadeComponent;
    @Value("${cliente.codigo}")
    private String codigoCliente;
    final String secretKey = "ssshhhhhhhhhhh!!!!";

    @Override
    @Transactional
    public ArqUsuarioEntity guardar(ArqUsuarioEntity usuario) {
        return arqUsuarioRepository.save(usuario);
    }

    @Override
    @Transactional
    public ArqUsuarioEntity guardar(NuevoUsuarioArquitecturaDTO nuevoUsuario) {
        this.existeUsuario(nuevoUsuario);
        var usuarioEntity = new ArqUsuarioEntity();
        usuarioEntity.setActivo(true);
        usuarioEntity.setNombres(nuevoUsuario.getNombres());
        usuarioEntity.setNick(nuevoUsuario.getEmail());
        usuarioEntity.setTelefono(nuevoUsuario.getTelefono());
        usuarioEntity.setPassw(passwordEncoder.encode(nuevoUsuario.getPassw()));
        usuarioEntity.setApellidoMaterno(nuevoUsuario.getApellidoMaterno());
        usuarioEntity.setApellidoPaterno(nuevoUsuario.getApellidoPaterno());
        usuarioEntity.setEmail(nuevoUsuario.getEmail());
        usuarioEntity.setPendienteConfirmacion(false);
        var cliente = this.arqClienteEntityRepository.findByCodigoAndActivoIsTrue(codigoCliente)
                .orElseThrow(() -> new IllegalArgumentException("No está asignado el código del cliente en la BD"));
        usuarioEntity.setArqClienteByIdArqCliente(cliente);
        usuarioEntity = this.guardar(usuarioEntity);

        var rolEsp = arqRolAplicacionRepository.findByNombre(nuevoUsuario.getRol())
                .orElseThrow(() -> new IllegalArgumentException("El rol especificado no es válido."));

        var arqUsuarioRolAplicacion = new ArqUsuarioRolEntity();
        arqUsuarioRolAplicacion.setArqUsuarioByIdArqUsuario(usuarioEntity);
        arqUsuarioRolAplicacion.setArqRolByIdArqRol(rolEsp);

        arqUsuarioRolAplicacionEntityRepository.save(arqUsuarioRolAplicacion);

        log.info("Usuario de arquitectura guardado satisfactoriamente.");
        return usuarioEntity;
    }

    @Override
    public boolean cambiaContrasena(Long idUsuario, String anterior, String nueva) {
        return false;
    }

    @Override
    @Transactional(readOnly = true)
    public String generaToken(@Email @NotEmpty String email) {
        this.arqUsuarioRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("El email no existe en nuestra base de datos"));

        var builder = new StringBuilder();
        builder.append(email).append(",").append(LocalDateTime.now().plusHours(1));
        return AES.encrypt(builder.toString(), secretKey);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ArqUsuarioEntity> getByNick(String nick) {
        return this.arqUsuarioRepository.findByNick(nick);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ArqUsuarioEntity> getByEmail(String email) {
        return this.arqUsuarioRepository.findByEmail(email);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existePorNick(String nu) {
        return false;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existePorEmail(String email) {
        return false;
    }

    @Transactional(readOnly = true)
    public void existeUsuario(NuevoUsuarioArquitecturaDTO nuevoUsuario) {
        if (this.arqUsuarioRepository.existsByEmail(nuevoUsuario.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado.");
        }
        if (this.arqUsuarioRepository.existsByNick(nuevoUsuario.getNick())) {
            throw new IllegalArgumentException("El nick ya está registrado.");
        }
    }

    @Override
    @Transactional
    public void cambiaPassw(UsuarioPrincipal usuarioLogeado, String passw) {
        ArqUsuarioEntity arqUsuarioEnt = arqUsuarioRepository.findByEmail(usuarioLogeado.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("El email del usuario logeado no aparece en la BD."));

        arqUsuarioEnt.setPassw(passwordEncoder.encode(passw));
        this.arqUsuarioRepository.save(arqUsuarioEnt);
    }


    @Override
    @Transactional(readOnly = true)
    public ArqUsuarioEntity getUsuarioLogeado() {
        var usuarioLogeado = (UsuarioPrincipal) authenticationFacadeComponent.getAuthentication().getPrincipal();
        return this.arqUsuarioRepository.findByEmail(usuarioLogeado.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("El email del usuario logeado no aparece en la BD"));
    }

    @Override
    @Transactional(readOnly = true)
    public Long getIdUsuarioLogeado() {
        return this.getUsuarioLogeado().getIdArqUsuario();
    }

    /**
     * @param idArqUsuario
     */
    @Override
    @Transactional
    public void desactivaUsuario(Long idArqUsuario) {
        var usuario = this.arqUsuarioRepository.findById(idArqUsuario)
                .orElseThrow(()-> new IllegalArgumentException("No existe el usuario especificado"));
        usuario.setActivo(false);
        this.arqUsuarioRepository.save(usuario);

    }
}
