package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "entidad_reciclaje")
public class PEntityEntidadReciclaje {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_entidad_reciclaje")
    private Long idEntidadReciclaje;
    @Basic
    @Column(name = "id_socio_reciclaje", insertable = false, updatable = false)
    private Long idSocioReciclaje;
    @Basic
    @Column(name = "direccion")
    private String direccion;
    @Basic
    @Column(name = "latitud")
    private String latitud;
    @Basic
    @Column(name = "longitud")
    private String longitud;
    @ManyToOne
    @JoinColumn(name = "id_socio_reciclaje", referencedColumnName = "id_socio_reciclaje", nullable = false)
    private PEntitySocioReciclaje socioReciclajeByIdSocioReciclaje;
    @OneToMany(mappedBy = "entidadReciclajeByIdEntidadReciclaje")
    private Collection<PEntityQuioscoEntidad> quioscoEntidadsByIdEntidadReciclaje;
}
