package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.NuevoProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.ProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos.ProductoPuntosDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.*;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.*;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ProductoPuntosService;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ProductoReciclableService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class ProductoReciclableServiceImpl implements ProductoReciclableService {
    private final PEntityProductoReciclableRepository pEntityProductoReciclableRepository;
    private final PEntityCapacidadRepository pEntityCapacidadRepository;
    private final PEntityMaterialRepository pEntityMaterialRepository;
    private final PEntitySubMarcaRepository pEntitySubMarcaRepository;
    private final PEntityUnidadMedidaRepository pEntityUnidadMedidaRepository;
    private final PEntityFabricanteRepository pEntityFabricanteRepository;
    private final PEntityProductoReciclableColorPuntosRepository productoPuntosRepository;
    private final ProductoPuntosService productoPuntosService;

    @Override
    @Transactional
    public void nuevoProductoReciclable(@NotNull @Valid NuevoProductoReciclableDTO dto) {
        if (this.pEntityProductoReciclableRepository.existsBySkuOrBarCode(dto.getSku(), dto.getBarCode())) {
            throw new IllegalArgumentException("El SKU o el código de barras ya existen.");
        }
        var ent = new PEntityProductoReciclable();
        this.llenaPEntityProductoReciclable(dto, ent);
        ent = this.pEntityProductoReciclableRepository.save(ent);
        this.productoPuntosService.nuevo(ent, dto.getPuntos());
    }

    @Override
    @Transactional
    public void editaProductoReciclable(@NotNull @Valid ProductoReciclableDTO dto) {
        var ent = this.pEntityProductoReciclableRepository.findById(dto.getIdProductoReciclable())
                .orElseThrow(() -> new IllegalArgumentException("El producto especificado no está registrado"));
        this.llenaPEntityProductoReciclable(dto, ent);
        this.pEntityProductoReciclableRepository.save(ent);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProductoReciclableDTO> getBySKU(String sku) {
        return this.pEntityProductoReciclableRepository.getBySKU(sku);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProductoPuntosDTO> getProductosPuntos() {
        return this.pEntityProductoReciclableRepository.getProductosPuntos();
    }

    @Override
    @Transactional
    public void updatePuntosAllProductos(Integer puntos) {
        this.productoPuntosRepository.updatePuntosAllProductos(puntos);
    }

    @Override
    @Transactional
    public void updatePuntosOneProducto(Integer puntos, Long idProductoReciclableColorPuntos) {
        this.productoPuntosRepository.updatePuntosOneProducto(puntos, idProductoReciclableColorPuntos);
    }

    private void llenaPEntityProductoReciclable(@NotNull @Valid NuevoProductoReciclableDTO dto,
                                                @NotNull @Valid PEntityProductoReciclable ent) {
        ent.setBarCode(dto.getBarCode())
                .setCapacidad(this.capacidad(dto.getIdUnidadMedida(), dto.getCapacidad()))
                .setFabricante(this.fabricante(dto.getIdFabricante()))
                .setMaterial(this.material(dto.getIdMaterial()))
                .setPesoMaximo(dto.getPesoMaximo())
                .setPesoMinimo(dto.getPesoMinimo())
                .setSku(dto.getSku())
                .setSubMarca(this.subMarca(dto.getIdSubMarca()));
    }

    private PEntityMaterial material(Integer id) {
        return this.pEntityMaterialRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("El material especificado no está registrado."));
    }

    private PEntitySubMarca subMarca(Integer id) {
        return this.pEntitySubMarcaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("La submarca especificada no está registrada."));
    }

    private PEntityFabricante fabricante(Integer id) {
        return this.pEntityFabricanteRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("El fabricante especificado no está registrado."));
    }

    private PEntityCapacidad capacidad(Integer id, BigDecimal cantidad) {
        var unidad = this.pEntityUnidadMedidaRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("La unidad de medida especificada no está registrada."));
        var capacidad = new PEntityCapacidad();
        capacidad.setCantidad(cantidad)
                .setUnidadMedidaByIdUnidadMedida(unidad);
        return this.pEntityCapacidadRepository.save(capacidad);
    }
}
