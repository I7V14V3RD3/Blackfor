package mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModeloQuioscoDTO {
    private Integer idModeloQuiosco;
    private String nombre;
}
