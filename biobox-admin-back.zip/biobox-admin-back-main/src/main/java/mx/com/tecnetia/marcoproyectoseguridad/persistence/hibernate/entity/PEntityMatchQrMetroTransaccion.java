package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "match_qr_metro_transaccion")
public class PEntityMatchQrMetroTransaccion {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "match_qr_metro_transaccion")
    private Long matchQrMetroTransaccion;
    @Basic
    @Column(name = "id_transaccion", insertable = false, updatable = false)
    private Long idTransaccion;
    @Basic
    @Column(name = "id_qr_metro_generado", insertable = false, updatable = false)
    private Long idQrMetroGenerado;
    @ManyToOne
    @JoinColumn(name = "id_transaccion", referencedColumnName = "id_transaccion", nullable = false)
    private PEntityTransaccion transaccionByIdTransaccion;
    @ManyToOne
    @JoinColumn(name = "id_qr_metro_generado", referencedColumnName = "id_qr_metro_generado", nullable = false)
    private PEntityQrMetroGenerado qrMetroGeneradoByIdQrMetroGenerado;
}
