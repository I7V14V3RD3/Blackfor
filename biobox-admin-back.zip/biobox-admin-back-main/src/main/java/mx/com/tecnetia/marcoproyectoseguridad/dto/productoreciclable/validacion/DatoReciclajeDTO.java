package mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DatoReciclajeDTO {
    private Integer anio;
    private Integer mes;
    private Long cantidad;
}
