package mx.com.tecnetia.orthogonal.utils;

import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestControllerAdvice
@Log4j2
public class GlobalExceptionsManager extends ResponseEntityExceptionHandler {
    private static final String MENSAJE = "message";
    private static final String TIME = "localdatetime";
    private static final String STATUS = "status";
    private static final String MSG_GENERICO = "ERROR EN LA OPERACIÓN.";

    @Override
    @NonNull
    protected ResponseEntity<Object> handleMethodArgumentNotValid(org.springframework.web.bind.MethodArgumentNotValidException ex,
                                                                  org.springframework.http.HttpHeaders headers,
                                                                  org.springframework.http.HttpStatusCode status,
                                                                  org.springframework.web.context.request.WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put(TIME, LocalDateTime.now());
        body.put(STATUS, status.value());
        // Get all errors:
        List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).toList();
        headers.set(MENSAJE, errors.toString());
        body.put(MENSAJE, errors.isEmpty() ? MSG_GENERICO : errors);
        log.error("MethodArgumentNotValidException: {}", errors.isEmpty() ? MSG_GENERICO : errors);
        return new ResponseEntity<>(body, headers, status);
    }

    @ExceptionHandler(value = IllegalArgumentException.class)
    protected ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        var result = getResult(ex);
        return handleExceptionInternal(ex, result.body(), result.headers(), HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(value = IllegalStateException.class)
    protected ResponseEntity<Object> handleConflict(IllegalStateException ex, WebRequest request) {
        var result = getResult(ex);
        return handleExceptionInternal(ex, result.body(), result.headers(), HttpStatus.EXPECTATION_FAILED, request);
    }

    @ExceptionHandler(value = DataIntegrityViolationException.class)
    protected ResponseEntity<Object> handleDataIntegrityViolationException(DataIntegrityViolationException ex, WebRequest request) {
        var result = getResult(ex);
        return handleExceptionInternal(ex, result.body(), result.headers(), HttpStatus.NOT_ACCEPTABLE, request);
    }

    private static Result getResult(RuntimeException ex) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put(TIME, LocalDateTime.now());
        body.put(MENSAJE, ex.getLocalizedMessage() == null ? MSG_GENERICO : ex.getLocalizedMessage());
        var headers = new HttpHeaders();
        headers.set(MENSAJE, ex.getLocalizedMessage() == null ? MSG_GENERICO : ex.getLocalizedMessage());
        log.error("Excepción manejada por el manejador global: {}", ex.getLocalizedMessage() == null ? MSG_GENERICO : ex.getLocalizedMessage());
        return new Result(body, headers);
    }

    private static Result getResult(RuntimeException ex, String mensaje) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put(TIME, LocalDateTime.now());
        body.put(MENSAJE, mensaje);
        var headers = new HttpHeaders();
        headers.set(MENSAJE, mensaje);
        log.error("Excepción manejada por el manejador global: {}", ex.getLocalizedMessage() == null ? MSG_GENERICO : ex.getLocalizedMessage());
        return new Result(body, headers);
    }


    private record Result(Map<String, Object> body, HttpHeaders headers) {
    }

    @ExceptionHandler(value = RuntimeException.class)
    protected ResponseEntity<Object> handleConflictAll(RuntimeException ex, WebRequest request) {
        var result = getResult(ex);
        return handleExceptionInternal(ex, result.body(), result.headers(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

//  Este método me tronó al migrar a spring boot 3.2
/*    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Object> handleMaxSizeException(MaxUploadSizeExceededException ex, WebRequest request) {
        var result = getResult(ex);
        return handleExceptionInternal(ex, result.body(), result.headers(), HttpStatus.INTERNAL_SERVER_ERROR, request);
    }*/
}
