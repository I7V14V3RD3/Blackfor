package mx.com.tecnetia.orthogonal.beans;

import lombok.Data;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.dto.ServicioRestDTO;

import java.util.List;

@Data
@Log4j2
public class ServicioRestDTOBean {
    private List<ServicioRestDTO> listaServiciosActivos;
}
