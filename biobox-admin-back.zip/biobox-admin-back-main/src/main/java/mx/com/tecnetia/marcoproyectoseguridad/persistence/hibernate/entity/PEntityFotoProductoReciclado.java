package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "foto_producto_reciclado")
public class PEntityFotoProductoReciclado {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_foto_producto_reciclado")
    private Long idFotoProductoReciclado;
    @Basic
    @Column(name = "id_producto_reciclado", insertable = false, updatable = false)
    private Long idProductoReciclado;
    @Basic
    @Column(name = "foto")
    private byte[] foto;
    @Basic
    @Column(name = "exitoso")
    private Boolean exitoso;
    @OneToOne
    @JoinColumn(name = "id_producto_reciclado", referencedColumnName = "id_producto_reciclado", nullable = false)
    private PEntityProductoReciclado productoReciclado;
}
