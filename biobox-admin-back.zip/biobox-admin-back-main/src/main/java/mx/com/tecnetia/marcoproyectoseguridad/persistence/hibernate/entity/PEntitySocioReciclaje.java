package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "socio_reciclaje")
public class PEntitySocioReciclaje {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_socio_reciclaje")
    private Long idSocioReciclaje;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @OneToMany(mappedBy = "socioReciclajeByIdSocioReciclaje")
    private Collection<PEntityEntidadReciclaje> entidadReciclajesByIdSocioReciclaje;
}
