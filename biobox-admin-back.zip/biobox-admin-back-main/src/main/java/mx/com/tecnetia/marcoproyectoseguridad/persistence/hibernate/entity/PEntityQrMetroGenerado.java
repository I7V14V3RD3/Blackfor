package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "qr_metro_generado")
public class PEntityQrMetroGenerado {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_qr_metro_generado")
    private Long idQrMetroGenerado;
    @Basic
    @Column(name = "bar_code")
    private String barCode;
    @Basic
    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;
    @Basic
    @Column(name = "fecha_sincronizacion")
    private LocalDateTime fechaSincronizacion;
    @Basic
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;
    @Basic
    @Column(name = "id_estacion_metro", insertable = false, updatable = false)
    private Long idEstacionMetro;
    @Basic
    @Column(name = "id_programa_prontipago", insertable = false, updatable = false)
    private Long idProgramaProntipago;
    @OneToMany(mappedBy = "qrMetroGeneradoByIdQrMetroGenerado")
    private Collection<PEntityMatchQrMetroTransaccion> matchQrMetroTransaccionsByIdQrMetroGenerado;
    @ManyToOne
    @JoinColumn(name = "id_estacion_metro", referencedColumnName = "id_estacion_metro", nullable = false)
    private PEntityEstacionMetro estacionMetroByIdEstacionMetro;
    @ManyToOne
    @JoinColumn(name = "id_programa_prontipago", referencedColumnName = "id_programa_prontipago")
    private PEntityProgramaProntipago programaProntipagoByIdProgramaProntipago;
}
