package mx.com.tecnetia.orthogonal.dto.csv;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CsvBean {
}
