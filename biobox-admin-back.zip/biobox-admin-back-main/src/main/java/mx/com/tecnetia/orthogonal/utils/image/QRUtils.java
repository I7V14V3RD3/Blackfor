package mx.com.tecnetia.orthogonal.utils.image;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.qrcode.QRCodeWriter;
import jakarta.validation.constraints.NotBlank;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.service.impl.GestionQuioscoServiceImpl;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;


@Log4j2
public class QRUtils {
    private static final int IMAGE_WIDTH = 400;
    private static final int IMAGE_HEIGHT = 400;

    public static byte[] generaImagenQR(@NotBlank String qr) {
        var image = generateQRCodeImage(qr);
        byte[] bytes;
        try {
            bytes = toByteArray(image, "jpg");
        } catch (IOException e) {
            log.fatal("No se pudo generar el archivo JPG del QR {}", e.getMessage());
            throw new IllegalStateException(e);
        }
        return bytes;
    }

    private static BufferedImage generateQRCodeImage(String barcodeText) {
        var barcodeWriter = new QRCodeWriter();
        try {
            var bitMatrix = barcodeWriter.encode(barcodeText, BarcodeFormat.QR_CODE, IMAGE_WIDTH, IMAGE_HEIGHT);
            return MatrixToImageWriter.toBufferedImage(bitMatrix);
        } catch (WriterException ex) {
            log.fatal("No se pudo generar el QR {}", ex.getMessage());
            throw new IllegalStateException(ex);
        }
    }

    private static byte[] toByteArray(BufferedImage bi, String format) throws IOException {
        var baos = new ByteArrayOutputStream();
        ImageIO.write(bi, format, baos);
        return baos.toByteArray();
    }

}
