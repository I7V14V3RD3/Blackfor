package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "token_cel")
public class PEntityTokenCel {
    @Basic
    @Column(name = "token")
    private String token;
    @Basic
    @Column(name = "alta")
    private LocalDateTime alta;
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;
}
