package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "producto_reciclado_quiosco")
public class PEntityProductoRecicladoQuiosco {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_producto_reciclado")
    private Long idProductoReciclado;
    @Basic
    @Column(name = "id_quiosco", insertable = false, updatable = false)
    private Long idQuiosco;
    @OneToOne(mappedBy = "productoRecicladoQuioscoByIdProductoReciclado")
    private PEntityLoteRevisadoEntidad loteRevisadoEntidadByIdProductoReciclado;
    @OneToOne
    @JoinColumn(name = "id_producto_reciclado", referencedColumnName = "id_producto_reciclado", nullable = false)
    private PEntityProductoReciclado productoRecicladoByIdProductoReciclado;
    @ManyToOne
    @JoinColumn(name = "id_quiosco", referencedColumnName = "id_quiosco", nullable = false)
    private PEntityQuiosco quioscoByIdQuiosco;
}
