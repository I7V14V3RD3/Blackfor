package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.*;

import java.util.List;

public interface CatalogoService {
    List<UnidadMedidaDTO> getCatalogoUnidadesMedida();

    List<SubMarcaDTO> getCatalogoSubMarcas();

    List<SubMarcaDTO> getCatalogoSubMarcas(Long idMarca);

    List<MarcaDTO> getCatalogoMarcas();
    List<MarcaDTO> getCatalogoMarcasLike(String nombreLike);

    List<FabricanteDTO> getCatalogoFabricantes();
    List<FabricanteDTO> getCatalogoFabricantesLike(String nombreLike);

    List<MaterialDTO> getCatalogoMateriales();
}
