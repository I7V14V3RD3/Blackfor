package mx.com.tecnetia.marcoproyectoseguridad.mapper;

import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.NuevoQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityQuiosco;
import org.mapstruct.*;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = MappingConstants.ComponentModel.SPRING)
public interface PEntityQuioscoMapper {
    @Mapping(target = "modeloQuiosco", ignore = true)
    PEntityQuiosco toEntity(NuevoQuioscoDTO nuevoQuioscoDTO);
    @Mapping(target = "modeloQuiosco", ignore = true)
    PEntityQuiosco toEntity(QuioscoDTO nuevoQuioscoDTO);

    @Mapping(target = "modelo", source = "modeloQuiosco.nombre")
    NuevoQuioscoDTO toDto(PEntityQuiosco PEntityQuiosco);
    @Mapping(target = "modelo", source = "modeloQuiosco.nombre")
    QuioscoDTO toQuiosco(PEntityQuiosco PEntityQuiosco);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    PEntityQuiosco partialUpdate(NuevoQuioscoDTO nuevoQuioscoDTO, @MappingTarget PEntityQuiosco pEntityQuiosco);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    PEntityQuiosco partialUpdate(QuioscoDTO quioscoDTO, @MappingTarget PEntityQuiosco pEntityQuiosco);
}
