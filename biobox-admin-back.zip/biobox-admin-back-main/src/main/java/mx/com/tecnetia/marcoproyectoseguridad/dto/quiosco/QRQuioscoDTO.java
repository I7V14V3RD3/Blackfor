package mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.logging.log4j.core.config.plugins.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QRQuioscoDTO extends QuioscoCreadoDTO {
    @NotEmpty
    private byte[] image;

    public QRQuioscoDTO(@NotBlank String qr, @NotEmpty byte[] image) {
        super(qr);
        this.image = image.clone();
    }
}
