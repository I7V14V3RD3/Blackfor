package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityProductoReciclableColorPuntos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PEntityProductoReciclableColorPuntosRepository extends JpaRepository<PEntityProductoReciclableColorPuntos, Long> {
    @Modifying
    @Query("""
                update PEntityProductoReciclableColorPuntos p
                set p.puntos = :puntos
                where p.fechaFin is null
            """)
    void updatePuntosAllProductos(@Param("puntos") Integer puntos);
    @Modifying
    @Query("""
                update PEntityProductoReciclableColorPuntos p
                set p.puntos = :puntos
                where p.idProductoReciclableColorPuntos = :id and p.fechaFin is null
            """)
    void updatePuntosOneProducto(@Param("puntos") Integer puntos, @Param("id") Long idProductoReciclableColorPuntos);
}
