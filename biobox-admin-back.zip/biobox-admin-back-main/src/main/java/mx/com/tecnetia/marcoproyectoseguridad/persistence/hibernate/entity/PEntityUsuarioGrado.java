package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "usuario_grado")
public class PEntityUsuarioGrado {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_usuario_grado")
    private Long idUsuarioGrado;
    @Basic
    @Column(name = "id_grado_jerarquico", insertable = false, updatable = false)
    private Long idGradoJerarquico;
    @Basic
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;
    @Basic
    @Column(name = "fecha_inicio")
    private LocalDateTime fechaInicio;
    @Basic
    @Column(name = "fecha_fin")
    private LocalDateTime fechaFin;
    @ManyToOne
    @JoinColumn(name = "id_grado_jerarquico", referencedColumnName = "id_grado_jerarquico", nullable = false)
    private PEntityGradoJerarquico gradoJerarquicoByIdGradoJerarquico;
}
