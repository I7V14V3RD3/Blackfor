package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "producto_reciclable_color_puntos")
public class PEntityProductoReciclableColorPuntos {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_producto_reciclable_color_puntos")
    private Long idProductoReciclableColorPuntos;
    @Basic
    @Column(name = "id_color", insertable = false, updatable = false)
    private Integer idColor;
    @Basic
    @Column(name = "id_producto_reciclable", insertable = false, updatable = false)
    private Long idProductoReciclable;
    @Basic
    @Column(name = "puntos")
    private Integer puntos;
    @Basic
    @Column(name = "fecha_inicio")
    private LocalDateTime fechaInicio;
    @Basic
    @Column(name = "fecha_fin")
    private Date fechaFin;
    @ManyToOne
    @JoinColumn(name = "id_color", referencedColumnName = "id_color", nullable = false)
    private PEntityColor colorByIdColor;
    @ManyToOne
    @JoinColumn(name = "id_producto_reciclable", referencedColumnName = "id_producto_reciclable", nullable = false)
    private PEntityProductoReciclable productoReciclableByIdProductoReciclable;
}
