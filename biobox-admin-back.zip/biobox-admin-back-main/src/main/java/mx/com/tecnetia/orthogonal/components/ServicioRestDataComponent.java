package mx.com.tecnetia.orthogonal.components;

public interface ServicioRestDataComponent {
    boolean isActive(String uri, String method);
}
