package mx.com.tecnetia.orthogonal.utils.files;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {
    String save(MultipartFile file, String uploadPath);
}
