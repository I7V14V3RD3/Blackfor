package mx.com.tecnetia.marcoproyectoseguridad.kafka.handler;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.kafka.service.DispatchService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@Log4j2
@RequiredArgsConstructor
public class QuioscoIniciadoHandlerImpl implements QuioscoIniciadoHandler {

    private final DispatchService dispatchService;

    /*
    *     @KafkaListener(id = "orderConsumerClient", topics = "order.created",
            groupId = "dispatch.order.created.consumer")*/
    @KafkaListener(
            id = "quyioscoIniciadoClient",
            topics = "quiosco.iniciado.topic",
            groupId = "dispatch.quiosco.iniciado.topic.consumer"
    )
    public void listen(String payload) {
        log.info("Payload: {}", payload);
        this.dispatchService.process(payload);
    }
}
