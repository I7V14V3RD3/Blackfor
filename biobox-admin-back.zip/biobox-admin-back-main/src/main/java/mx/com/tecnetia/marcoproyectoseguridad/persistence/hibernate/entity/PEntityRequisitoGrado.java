package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "requisito_grado")
public class PEntityRequisitoGrado {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_requisito_grado")
    private Long idRequisitoGrado;
    @Basic
    @Column(name = "id_color", insertable = false, updatable = false)
    private Integer idColor;
    @Basic
    @Column(name = "id_grado_jerarquico", insertable = false, updatable = false)
    private Long idGradoJerarquico;
    @Basic
    @Column(name = "puntos")
    private Integer puntos;
    @Basic
    @Column(name = "fecha_inicio")
    private LocalDateTime fechaInicio;
    @Basic
    @Column(name = "fecha_fin")
    private LocalDateTime fechaFin;
    @ManyToOne
    @JoinColumn(name = "id_color", referencedColumnName = "id_color", nullable = false)
    private PEntityColor colorByIdColor;
    @ManyToOne
    @JoinColumn(name = "id_grado_jerarquico", referencedColumnName = "id_grado_jerarquico", nullable = false)
    private PEntityGradoJerarquico gradoJerarquicoByIdGradoJerarquico;
}
