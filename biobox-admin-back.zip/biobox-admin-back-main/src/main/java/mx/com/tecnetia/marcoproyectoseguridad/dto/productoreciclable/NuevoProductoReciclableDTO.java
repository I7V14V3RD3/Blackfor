package mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NuevoProductoReciclableDTO {
    @NotBlank
    private String sku;
    @NotBlank
    private String barCode;
    @NotNull
    @Positive
    private Integer idMaterial;
    @NotNull
    @Positive
    private Integer idSubMarca;
    @NotNull
    @Positive
    private Integer idFabricante;
    @NotNull
    @Positive
    private Integer idUnidadMedida;
    @NotNull
    @Positive
    private BigDecimal capacidad;
    @NotNull
    @Positive
    private BigDecimal pesoMinimo;
    @NotNull
    @Positive
    private BigDecimal pesoMaximo;
    @NotNull
    @PositiveOrZero
    private Integer puntos;
}
