package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "sub_marca")
public class PEntitySubMarca {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_sub_marca")
    private Integer idSubMarca;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "id_marca", insertable = false, updatable = false)
    private Integer idMarca;
    @OneToMany(mappedBy = "subMarca")
    private Collection<PEntityProductoReciclable> productoReciclablesByIdSubMarca;
    @ManyToOne
    @JoinColumn(name = "id_marca", referencedColumnName = "id_marca", nullable = false)
    private PEntityMarca marcaByIdMarca;
}
