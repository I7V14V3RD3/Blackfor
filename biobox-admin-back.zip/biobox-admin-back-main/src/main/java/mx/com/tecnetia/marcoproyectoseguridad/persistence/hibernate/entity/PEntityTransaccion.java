package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "transaccion")
public class PEntityTransaccion {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_transaccion")
    private Long idTransaccion;
    @Basic
    @Column(name = "version")
    private char version;
    @Basic
    @Column(name = "date_time")
    private String dateTime;
    @Basic
    @Column(name = "station")
    private String station;
    @Basic
    @Column(name = "location")
    private String location;
    @Basic
    @Column(name = "bar_code")
    private String barCode;
    @Basic
    @Column(name = "line")
    private String line;
    @Basic
    @Column(name = "station_name")
    private String stationName;
    @Basic
    @Column(name = "auth_type")
    private char authType;
    @Basic
    @Column(name = "id_fichero_transaccion", insertable = false, updatable = false)
    private Long idFicheroTransaccion;
    @OneToMany(mappedBy = "transaccionByIdTransaccion")
    private Collection<PEntityMatchQrMetroTransaccion> matchQrMetroTransaccionsByIdTransaccion;
    @ManyToOne
    @JoinColumn(name = "id_fichero_transaccion", referencedColumnName = "id_fichero_transaccion", nullable = false)
    private PEntityFicheroTransaccion ficheroTransaccionByIdFicheroTransaccion;
}
