package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "producto_reciclable")
public class PEntityProductoReciclable {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_producto_reciclable")
    private Long idProductoReciclable;
    @Basic
    @Column(name = "sku")
    private String sku;
    @Basic
    @Column(name = "bar_code")
    private String barCode;
    @Basic
    @Column(name = "id_material", insertable = false, updatable = false)
    private Integer idMaterial;
    @Basic
    @Column(name = "id_sub_marca", insertable = false, updatable = false)
    private Integer idSubMarca;
    @Basic
    @Column(name = "id_fabricante", insertable = false, updatable = false)
    private Integer idFabricante;
    @Basic
    @Column(name = "id_capacidad", insertable = false, updatable = false)
    private Long idCapacidad;
    @Basic
    @Column(name = "peso_minimo")
    private BigDecimal pesoMinimo;
    @Basic
    @Column(name = "peso_maximo")
    private BigDecimal pesoMaximo;

    @OneToMany(mappedBy = "productoReciclableByIdProductoReciclable")
    private Collection<PEntityEnvaseBebida> envaseBebidasByIdProductoReciclable;
    @ManyToOne
    @JoinColumn(name = "id_material", referencedColumnName = "id_material", nullable = false)
    private PEntityMaterial material;
    @ManyToOne
    @JoinColumn(name = "id_sub_marca", referencedColumnName = "id_sub_marca", nullable = false)
    private PEntitySubMarca subMarca;
    @ManyToOne
    @JoinColumn(name = "id_fabricante", referencedColumnName = "id_fabricante", nullable = false)
    private PEntityFabricante fabricante;
    @ManyToOne
    @JoinColumn(name = "id_capacidad", referencedColumnName = "id_capacidad", nullable = false)
    private PEntityCapacidad capacidad;
    @OneToMany(mappedBy = "productoReciclableByIdProductoReciclable")
    private Collection<PEntityProductoReciclableColorPuntos> productoReciclableColorPuntos;
    @OneToMany(mappedBy = "productoReciclable")
    private Collection<PEntityProductoReciclado> productosReciclados;
}
