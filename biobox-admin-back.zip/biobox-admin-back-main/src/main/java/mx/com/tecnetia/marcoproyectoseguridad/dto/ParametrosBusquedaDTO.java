package mx.com.tecnetia.marcoproyectoseguridad.dto;

public class ParametrosBusquedaDTO {
}
