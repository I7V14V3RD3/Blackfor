package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityProductoReciclable;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityProductoReciclableColorPuntos;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityColorRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityProductoReciclableColorPuntosRepository;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ProductoPuntosService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class ProductoPuntosServiceImpl implements ProductoPuntosService {
    private final PEntityProductoReciclableColorPuntosRepository productoPuntosRepository;
    private final PEntityColorRepository colorRepository;

    @Override
    @Transactional
    public void nuevo(PEntityProductoReciclable pr, Integer puntos) {
        var color = this.colorRepository.findAll().get(0);
        var ent = new PEntityProductoReciclableColorPuntos()
                .setPuntos(puntos)
                .setColorByIdColor(color)
                .setProductoReciclableByIdProductoReciclable(pr)
                .setFechaInicio(LocalDateTime.now())
                .setFechaFin(null);
        this.productoPuntosRepository.save(ent);
    }
}
