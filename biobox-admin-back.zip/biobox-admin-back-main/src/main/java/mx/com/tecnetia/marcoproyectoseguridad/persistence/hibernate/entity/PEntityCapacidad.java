package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "capacidad")
public class PEntityCapacidad {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_capacidad")
    private Long idCapacidad;
    @Basic
    @Column(name = "cantidad")
    private BigDecimal cantidad;
    @Basic
    @Column(name = "id_unidad_medida", insertable = false, updatable = false)
    private Integer idUnidadMedida;
    @ManyToOne
    @JoinColumn(name = "id_unidad_medida", referencedColumnName = "id_unidad_medida", nullable = false)
    private PEntityUnidadMedida unidadMedidaByIdUnidadMedida;
    @OneToMany(mappedBy = "capacidad")
    private Collection<PEntityProductoReciclable> productoReciclablesByIdCapacidad;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PEntityCapacidad that = (PEntityCapacidad) o;
        return Objects.equals(idCapacidad, that.idCapacidad) && Objects.equals(cantidad, that.cantidad) && Objects.equals(idUnidadMedida, that.idUnidadMedida);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCapacidad, cantidad, idUnidadMedida);
    }

}
