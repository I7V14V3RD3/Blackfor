package mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuioscoCreadoDTO {
    @UUID(message = "El QR no tiene un formato válido.")
    private String qr;
}
