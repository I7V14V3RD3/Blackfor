package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ValidaReciclajeDTO;

public interface ValidacionService {
    void validaReciclaje(@NotNull @Valid ValidaReciclajeDTO dto);
}
