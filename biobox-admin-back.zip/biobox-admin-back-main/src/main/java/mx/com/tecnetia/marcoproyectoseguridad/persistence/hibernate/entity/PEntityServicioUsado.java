package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "servicio_usado")
public class PEntityServicioUsado {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_servicio_usado")
    private Long idServicioUsado;
    @Basic
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;
    @Basic
    @Column(name = "momento")
    private LocalDateTime momento;
    @Basic
    @Column(name = "id_programa_prontipago", insertable = false, updatable = false)
    private Long idProgramaProntipago;
    @ManyToOne
    @JoinColumn(name = "id_programa_prontipago", referencedColumnName = "id_programa_prontipago", nullable = false)
    private PEntityProgramaProntipago programaProntipagoByIdProgramaProntipago;
    @OneToMany(mappedBy = "servicioUsadoByIdServicioUsado")
    private Collection<PEntityUsuarioPuntosColorConsumidos> usuarioPuntosColorConsumidosByIdServicioUsado;
}
