package mx.com.tecnetia;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication(scanBasePackages = "mx.com.tecnetia")
@EnableAsync
@OpenAPIDefinition(info = @Info(title = "BioBox Admin", version = "1.0", description = """
        Documentación del API del proyecto Vimed.<br>
        <b>NOTA IMPORTANTE:</b><br>
        El header 'Authorization' debe tener como valor 'Bearer TOKEN',<br>
        donde 'TOKEN' es la cadena encriptada devuelta por el servicio de login."""))
@SecurityScheme(name = "security_auth", type = SecuritySchemeType.HTTP, scheme = "Bearer")
@EnableScheduling
public class MarcoApplication extends SpringBootServletInitializer {
    public static void main(String[] args) {
        SpringApplication.run(MarcoApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(MarcoApplication.class);
    }
}
