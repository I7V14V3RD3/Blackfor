package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "anuncio")
public class PEntityAnuncio {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_anuncio")
    private Long idAnuncio;
    @Basic
    @Column(name = "file")
    private byte[] file;
    @Basic
    @Column(name = "nombre_file")
    private String nombreFile;
    @Basic
    @Column(name = "ext_file")
    private String extFile;
    @Basic
    @Column(name = "url_foto")
    private String urlFoto;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PEntityAnuncio that = (PEntityAnuncio) o;
        return Objects.equals(idAnuncio, that.idAnuncio) && Arrays.equals(file, that.file) && Objects.equals(nombreFile, that.nombreFile) && Objects.equals(extFile, that.extFile) && Objects.equals(urlFoto, that.urlFoto);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(idAnuncio, nombreFile, extFile, urlFoto);
        result = 31 * result + Arrays.hashCode(file);
        return result;
    }
}
