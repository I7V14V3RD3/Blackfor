package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.ProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoOnDTO;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.QuioscoStatsService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", exposedHeaders = "Content-Disposition")
@RestController
@RequestMapping("/quiosco-stats")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Quiosco.", description = "Estadística del quiosco.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class QuioscoStatsRestController {
    private final QuioscoStatsService quioscoStatsService;

    @Operation(summary = "Estado", description = "Estado del encendido del quiosco ")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Estado",
            content = @Content(schema = @Schema(implementation = QuioscoOnDTO.class)))})
    @GetMapping(value = "/free/on")
    public ResponseEntity<QuioscoOnDTO> estado() {
        var ent = this.quioscoStatsService.getDataOn();
        return ResponseEntity.ok(ent);
    }
}
