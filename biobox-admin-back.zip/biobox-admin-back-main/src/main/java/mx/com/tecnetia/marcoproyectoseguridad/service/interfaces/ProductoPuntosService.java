package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityProductoReciclable;

public interface ProductoPuntosService {
    void nuevo(PEntityProductoReciclable pr, Integer puntos);
}
