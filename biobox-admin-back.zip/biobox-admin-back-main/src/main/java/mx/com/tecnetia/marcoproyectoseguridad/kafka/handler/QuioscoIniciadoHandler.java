package mx.com.tecnetia.marcoproyectoseguridad.kafka.handler;

public interface QuioscoIniciadoHandler {
    public void listen(String payload);
}
