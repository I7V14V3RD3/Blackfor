package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.util.Collection;
import java.util.Objects;
import java.util.UUID;

@Entity
@Getter
@Setter
@Table(name = "quiosco")
@DynamicInsert
@DynamicUpdate
public class PEntityQuiosco {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_quiosco")
    private Long idQuiosco;
    @Basic
    @Column(name = "direccion")
    private String direccion;
    @Basic
    @Column(name = "latitud")
    private String latitud;
    @Basic
    @Column(name = "longitud")
    private String longitud;
    @Basic
    @Column(name = "qr")
    private UUID qr;
    @Basic
    @Column(name = "ip")
    private String ip;
    @Basic
    @Column(name = "altura_llenado_mm")
    private Integer alturaLlenadoMm;
    @Basic
    @Column(name = "tipo_arduino")
    private Boolean tipoArduino;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "referencias")
    private String referencias;
    @OneToMany(mappedBy = "quioscoByIdQuiosco")
    private Collection<PEntityConfiguracionMovimientoCharolaQuiosco> configuracionMovimientoCharolaQuioscosByIdQuiosco;
    @OneToMany(mappedBy = "quioscoByIdQuiosco")
    private Collection<PEntityProductoRecicladoQuiosco> productoRecicladoQuioscosByIdQuiosco;
    @OneToMany(mappedBy = "quioscoByIdQuiosco")
    private Collection<PEntityQuioscoEntidad> quioscoEntidadsByIdQuiosco;
    @Basic
    @Column(name = "id_modelo_quiosco", insertable = false, updatable = false)
    private Integer idModeloQuiosco;
    @ManyToOne
    @JoinColumn(name = "id_modelo_quiosco", referencedColumnName = "id_modelo_quiosco")
    private PEntityModeloQuiosco modeloQuiosco;
    @Column(name = "activo")
    private boolean activo;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PEntityQuiosco that = (PEntityQuiosco) o;
        return Objects.equals(idModeloQuiosco, that.idModeloQuiosco);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModeloQuiosco);
    }

}
