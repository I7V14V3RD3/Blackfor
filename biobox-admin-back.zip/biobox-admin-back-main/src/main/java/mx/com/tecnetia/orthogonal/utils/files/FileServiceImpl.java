package mx.com.tecnetia.orthogonal.utils.files;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.*;
import java.util.Objects;

@Service
@RequiredArgsConstructor
@Log4j2
public class FileServiceImpl implements FileService {
    @Override
    public String save(MultipartFile file, String uploadPath) {
        var name = file.getOriginalFilename() != null && !file.getOriginalFilename().isBlank() ? file.getOriginalFilename() : "";
        if (Objects.equals(name, "")) {
            throw new IllegalArgumentException("Falta el nombre del archivo");
        }
        try {
            Path root = Paths.get(uploadPath);
            if (!Files.exists(root)) {
                Files.createDirectory(root);
            }
            Path resolve = root.resolve(file.getOriginalFilename().trim().replaceAll("\\s", ""));
            if (resolve.toFile().exists()) {
                throw new IllegalArgumentException("El archivo ya existe: " + file.getOriginalFilename());
            }
            Files.copy(file.getInputStream(), resolve, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            throw new IllegalArgumentException("No se pudo guardar el archivo subido. Error: " + e.getLocalizedMessage());
        }
        return uploadPath + "/" + file.getOriginalFilename();
    }
}
