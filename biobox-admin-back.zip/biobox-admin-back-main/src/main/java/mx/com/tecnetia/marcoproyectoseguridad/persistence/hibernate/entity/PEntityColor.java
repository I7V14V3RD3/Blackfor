package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "color")
public class PEntityColor {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_color")
    private Integer idColor;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "hexadecimal")
    private String hexadecimal;
    @Basic
    @Column(name = "url_foto")
    private String urlFoto;
    @Basic
    @Column(name = "url_foto_2")
    private String urlFoto2;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityComodin> comodinsByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityConversion> conversionsByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityProductoReciclableColorPuntos> productoReciclableColorPuntosByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityRequisitoGrado> requisitoGradosByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityServicio> serviciosByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityUsuarioPuntosColor> usuarioPuntosColorsByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityUsuarioPuntosColorAcumulado> usuarioPuntosColorAcumuladosByIdColor;
    @OneToMany(mappedBy = "colorByIdColor")
    private Collection<PEntityUsuarioPuntosColorConsumidos> usuarioPuntosColorConsumidosByIdColor;

}
