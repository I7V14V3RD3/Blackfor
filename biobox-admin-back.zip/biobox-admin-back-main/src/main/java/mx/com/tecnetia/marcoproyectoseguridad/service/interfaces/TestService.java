package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import java.time.Instant;

public interface TestService {
    Instant getTest();

    boolean reciclarConcurrent(Long idQuiosco);
}
