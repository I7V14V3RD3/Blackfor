package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "fichero_transaccion")
public class PEntityFicheroTransaccion {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_fichero_transaccion")
    private Long idFicheroTransaccion;
    @Basic
    @Column(name = "file")
    private byte[] file;
    @Basic
    @Column(name = "nombre_file")
    private String nombreFile;
    @Basic
    @Column(name = "signature")
    private String signature;
    @Basic
    @Column(name = "cantidad_registros")
    private Integer cantidadRegistros;
    @Basic
    @Column(name = "key_name")
    private String keyName;
    @OneToMany(mappedBy = "ficheroTransaccionByIdFicheroTransaccion")
    private Collection<PEntityTransaccion> transaccionsByIdFicheroTransaccion;
}
