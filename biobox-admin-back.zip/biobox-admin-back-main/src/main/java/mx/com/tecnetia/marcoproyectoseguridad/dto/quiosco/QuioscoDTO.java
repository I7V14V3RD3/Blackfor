package mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Data
public class QuioscoDTO extends NuevoQuioscoDTO {
    @NotNull
    private Long idQuiosco;

    public QuioscoDTO(Long idQuiosco, @NotBlank String direccion, @NotBlank String latitud, @NotBlank String longitud,
                      @NotBlank UUID qr, @NotBlank String ip, @NotNull @Positive Integer alturaLlenadoMm, @NotNull Boolean tipoArduino,
                      String nombre, String referencias, String modelo, Boolean activo) {
        super(direccion, latitud, longitud, qr, ip, alturaLlenadoMm, tipoArduino, nombre, referencias, modelo, activo);
        this.idQuiosco = idQuiosco;
    }
}
