package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.*;
import mx.com.tecnetia.marcoproyectoseguridad.validators.NuevoQuioscoConstraint;

import java.util.List;


public interface GestionQuioscoService {
    QuioscoCreadoDTO nuevoQuiosco(@NotNull @Valid @NuevoQuioscoConstraint NuevoQuioscoDTO nuevoDTO);

    QRQuioscoDTO nuevoQuioscoQR(@NotNull @Valid @NuevoQuioscoConstraint NuevoQuioscoDTO nuevoDTO);

    List<QuioscoDTO> getQuioscosByDireccionSimilar(@NotBlank String dir);

    List<QuioscoDTO> getAllQuioscos();

    void editarQuiosco(QuioscoDTO dto);

    String editarQuioscoConNuevoQR(QuioscoDTO dto);

    List<ModeloQuioscoDTO> getAllModelosQuiosco();

    void creaTodosQRValidos();

    QRQuioscoDTO generaImagenQR(@NotNull Long idQuiosco);

    void deleteQuiosco(Long idQuiosco);
}
