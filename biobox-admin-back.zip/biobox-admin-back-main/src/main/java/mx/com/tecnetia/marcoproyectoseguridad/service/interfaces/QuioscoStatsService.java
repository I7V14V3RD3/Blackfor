package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoOnDTO;

public interface QuioscoStatsService {
    QuioscoOnDTO getDataOn();
}
