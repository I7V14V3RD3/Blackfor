package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.Synchronized;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.*;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.CatalogoService;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.TestService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Instant;
import java.util.List;

@CrossOrigin(origins = "*", exposedHeaders = "Content-Disposition")
@RestController
@RequestMapping("/catalogo")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Catálogos.", description = "Catálogos de la aplicación")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class CatalogoRestController {
    private final CatalogoService catalogoService;
    private final TestService testService;

    @Operation(summary = "Fabricantes", description = "Catálogo de fabricantes.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de fabricantes.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = FabricanteDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/fabricantes")
    public ResponseEntity<List<FabricanteDTO>> catalogoFabricantes() {
        var ret = this.catalogoService.getCatalogoFabricantes();
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Fabricantes", description = "Catálogo de fabricantes filtrado.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de fabricantes filtrado.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = FabricanteDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/fabricantes-like")
    public ResponseEntity<List<FabricanteDTO>> catalogoFabricantesLike(@RequestParam("nombre") String nombreLike) {
        var ret = this.catalogoService.getCatalogoFabricantesLike(nombreLike);
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Marcas", description = "Catálogo de marcas.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de marcas.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = MarcaDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/marcas")
    public ResponseEntity<List<MarcaDTO>> catalogoMarcas() {
        var ret = this.catalogoService.getCatalogoMarcas();
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Marcas", description = "Catálogo de marcas filtradas.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de marcas filtradas.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = MarcaDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/marcas-like")
    public ResponseEntity<List<MarcaDTO>> catalogoMarcasLike(@RequestParam("nombre") String nombreLike) {
        var ret = this.catalogoService.getCatalogoMarcasLike(nombreLike);
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Sub Marcas", description = "Catálogo de sub marcas.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de sub marcas.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = SubMarcaDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/submarcas")
    public ResponseEntity<List<SubMarcaDTO>> catalogoSubMarcas() {
        var ret = this.catalogoService.getCatalogoSubMarcas();
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Sub Marcas", description = "Sub marcas de una marca.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de sub marcas.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = SubMarcaDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/marca/submarcas")
    public ResponseEntity<List<SubMarcaDTO>> subMarcas(@RequestParam("id-marca") Long idMarca) {
        var ret = this.catalogoService.getCatalogoSubMarcas(idMarca);
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Unidades de medida", description = "Catálogo de unidades de medida.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de unidades de medida.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = UnidadMedidaDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/unidades-medida")
    public ResponseEntity<List<UnidadMedidaDTO>> catalogoUnidadesMedida() {
        var ret = this.catalogoService.getCatalogoUnidadesMedida();
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Materiales", description = "Catálogo de materiales.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de materiales.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = MaterialDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/materiales")
    public ResponseEntity<List<MaterialDTO>> catalogoMateriales() {
        var ret = this.catalogoService.getCatalogoMateriales();
        return ResponseEntity.ok(ret);
    }

    @Operation(summary = "Test", description = "Test de concurrencia")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Momento",
            content = @Content(schema = @Schema(implementation = Instant.class)))})
    @GetMapping(value = "/free/test")
    @Synchronized
    public ResponseEntity<String> test() {
        try {
            var localHost = InetAddress.getLocalHost();
            log.info("Nombre de red: {}. Nombre canónico: {}", localHost.getHostName(), localHost.getCanonicalHostName());
            return ResponseEntity.ok(localHost.getHostName());
        } catch (UnknownHostException e) {
            log.fatal("No se pudo obtener el nombre de red");
            throw new IllegalStateException(e);
        }
//        var ent = this.testService.getTest();

    }
}
