package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.NuevaSubMarcaDTO;

public interface GestionCatalogoService {
    void nuevaMarca(@NotBlank String nombre);
    void nuevoFabricante(@NotBlank String nombre);
    void nuevaSubMarca(@Valid NuevaSubMarcaDTO nuevaSubMarcaDTO);
}
