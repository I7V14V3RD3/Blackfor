package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.NuevoProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.ProductoReciclableDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos.ProductoPuntosDTO;

import java.util.List;
import java.util.Optional;

public interface ProductoReciclableService {
    void nuevoProductoReciclable(@NotNull @Valid NuevoProductoReciclableDTO dto);

    void editaProductoReciclable(@NotNull @Valid ProductoReciclableDTO dto);

    Optional<ProductoReciclableDTO> getBySKU(@NotBlank String sku);

    List<ProductoPuntosDTO> getProductosPuntos();

    void updatePuntosAllProductos(Integer puntos);

    void updatePuntosOneProducto(Integer puntos, Long idProductoReciclableColorPuntos);
}
