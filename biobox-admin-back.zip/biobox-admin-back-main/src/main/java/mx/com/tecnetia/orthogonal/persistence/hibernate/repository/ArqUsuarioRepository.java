package mx.com.tecnetia.orthogonal.persistence.hibernate.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mx.com.tecnetia.orthogonal.persistence.hibernate.entity.ArqUsuarioEntity;

@Repository
public interface ArqUsuarioRepository extends JpaRepository<ArqUsuarioEntity, Long> {

    Optional<ArqUsuarioEntity> findByNick(String nick);

    boolean existsByEmail(String email);

    boolean existsByNick(String nick);

    Optional<ArqUsuarioEntity> findByEmail(String email);


}
