package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "programa_prontipago")
public class PEntityProgramaProntipago {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_programa_prontipago")
    private Long idProgramaProntipago;
    @Basic
    @Column(name = "codigo")
    private String codigo;
    @Basic
    @Column(name = "id_categoria_prontipago", insertable = false, updatable = false)
    private Integer idCategoriaProntipago;
    @ManyToOne
    @JoinColumn(name = "id_categoria_prontipago", referencedColumnName = "id_categoria_prontipago")
    private PEntityCategoriaProntipago categoriaProntipagoByIdCategoriaProntipago;
    @OneToMany(mappedBy = "programaProntipagoByIdProgramaProntipago")
    private Collection<PEntityQrMetroGenerado> qrMetroGeneradosByIdProgramaProntipago;
    @OneToMany(mappedBy = "programaProntipagoByIdProgramaProntipago")
    private Collection<PEntityServicio> serviciosByIdProgramaProntipago;
    @OneToMany(mappedBy = "programaProntipagoByIdProgramaProntipago")
    private Collection<PEntityServicioUsado> servicioUsadosByIdProgramaProntipago;
    @OneToMany(mappedBy = "programaProntipagoByIdProntipago")
    private Collection<PEntitySkuProntipago> skuProntipagosByIdProgramaProntipago;
}
