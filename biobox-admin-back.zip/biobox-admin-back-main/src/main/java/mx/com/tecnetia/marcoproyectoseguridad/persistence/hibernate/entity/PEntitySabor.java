package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "sabor")
public class PEntitySabor {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_sabor")
    private Integer idSabor;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @OneToMany(mappedBy = "saborByIdSabor")
    private Collection<PEntityEnvaseBebida> envaseBebidasByIdSabor;
}
