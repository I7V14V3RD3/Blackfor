package mx.com.tecnetia.marcoproyectoseguridad.kafka.service;

import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

@Service
@Log4j2
public class DispatchServiceImpl implements DispatchService {
    @Override
    public void process(String payload) {
        log.info("DispatchService.process Payload: {}", payload);
    }
}
