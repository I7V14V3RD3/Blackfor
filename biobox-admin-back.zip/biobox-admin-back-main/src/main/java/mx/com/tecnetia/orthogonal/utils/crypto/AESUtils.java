package mx.com.tecnetia.orthogonal.utils.crypto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.extern.log4j.Log4j2;

import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.BadPaddingException;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKeyFactory;
import javax.crypto.SealedObject;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;

/***
 * Clase con los métodos de encriptación y desencriptación.
 * Inspirado en varios tutoriales, principalmente de Baeldung y sin usar librerías externas.
 */
@Log4j2
public final class AESUtils {
    private static final String IV = "M</3BYJtac]}^:K2";
    private static final String KEY = "NnT=]uF~9#[,7m6baq'K.+U@84k;j/z)";
    private static final int IV_PARAMETER_SPEC_SIZE = 16;
    private static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    private static final IvParameterSpec staticIV = new IvParameterSpec(getUTF8Bytes(IV));
    private static final SecretKey staticSecretKey = new SecretKey() {
        @Override
        public String getAlgorithm() {
            return "AES";
        }

        @Override
        public String getFormat() {
            return "RAW";
        }

        @Override
        public byte[] getEncoded() {
            return getUTF8Bytes(KEY);
        }
    };

    private AESUtils() {
    }

    private static byte[] getUTF8Bytes(@NotEmpty String input) {
        return input.getBytes(StandardCharsets.UTF_8);
    }


    public static String staticEncrypt(@NotEmpty String input) {
        return processEncryption(input, TRANSFORMATION, staticSecretKey, staticIV);
    }

    private static String processEncryption(@NotEmpty String input, String transformation, SecretKey staticSecretKey, IvParameterSpec staticIV) {
        try {
            var cipher = Cipher.getInstance(transformation);
            cipher.init(Cipher.ENCRYPT_MODE, staticSecretKey, staticIV);
            byte[] cipherText = cipher.doFinal(input.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder()
                    .encodeToString(cipherText);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    public static String staticDecrypt(@NotEmpty String cipherText) {
        return processStringDecryption(cipherText, TRANSFORMATION, staticSecretKey, staticIV);
    }

    private static String processStringDecryption(@NotEmpty String cipherText, String transformation, SecretKey staticSecretKey, IvParameterSpec staticIV) {
        try {
            var cipher = Cipher.getInstance(transformation);
            cipher.init(Cipher.DECRYPT_MODE, staticSecretKey, staticIV);
            byte[] plainText = cipher.doFinal(Base64.getDecoder()
                    .decode(cipherText));
            return new String(plainText, StandardCharsets.UTF_8);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    public static String encrypt(@NotEmpty String algorithm, @NotEmpty String input, @NotNull SecretKey key, @NotNull IvParameterSpec iv) {
        return processEncryption(input, algorithm, key, iv);
    }

    public static String decrypt(@NotEmpty String algorithm, @NotEmpty String cipherText, @NotNull SecretKey key, @NotNull IvParameterSpec iv) {
        return processStringDecryption(cipherText, algorithm, key, iv);
    }

    public static SecretKey generateKey(int n) {
        try {
            var keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(n);
            return keyGenerator.generateKey();
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    public static SecretKey getKeyFromPassword(@NotEmpty String password, @NotEmpty String salt) {
        try {
            var factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(StandardCharsets.UTF_8), 65536, 256);
            return new SecretKeySpec(factory.generateSecret(spec)
                    .getEncoded(), "AES");
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeySpecException e) {
            log.fatal("InvalidKeySpecException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    public static IvParameterSpec generateIv() {
        var iv = new byte[IV_PARAMETER_SPEC_SIZE];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    public static void encryptFile(@NotEmpty String algorithm, @NotNull SecretKey key, @NotNull IvParameterSpec iv,
                                   @NotNull File inputFile, File outputFile) {
        try (var outputStream = new FileOutputStream(outputFile); var inputStream = new FileInputStream(inputFile)) {
            var cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, key, iv);
            var buffer = new byte[64];
            processCryptoFile(outputStream, inputStream, cipher, buffer);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IOException e) {
            log.fatal("IOException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    private static void processCryptoFile(FileOutputStream outputStream, FileInputStream inputStream, Cipher cipher, byte[] buffer) throws IOException, IllegalBlockSizeException, BadPaddingException {
        int bytesRead;
        while ((bytesRead = inputStream.read(buffer)) != -1) {
            byte[] output = cipher.update(buffer, 0, bytesRead);
            if (output != null) {
                outputStream.write(output);
            }
        }
        byte[] outputBytes = cipher.doFinal();
        if (outputBytes != null) {
            outputStream.write(outputBytes);
        }
    }

    public static void decryptFile(String algorithm, SecretKey key, IvParameterSpec iv,
                                   File encryptedFile, File decryptedFile) {
        try (var inputStream = new FileInputStream(encryptedFile); var outputStream = new FileOutputStream(decryptedFile)) {
            Cipher cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE, key, iv);
            var buffer = new byte[64];
            processCryptoFile(outputStream, inputStream, cipher, buffer);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IOException e) {
            log.fatal("IOException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    public static SealedObject encryptObject(String algorithm, Serializable object, SecretKey key, IvParameterSpec iv) {
        try {
            var cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, key, iv);
            return new SealedObject(object, cipher);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IOException e) {
            log.fatal("IOException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    public static Serializable decryptObject(String algorithm, SealedObject sealedObject, SecretKey key, IvParameterSpec iv) {
        try {
            var cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE, key, iv);
            return (Serializable) sealedObject.getObject(cipher);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IOException e) {
            log.fatal("IOException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (ClassNotFoundException e) {
            log.fatal("ClassNotFoundException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }

    }

    public static String encryptPasswordBased(String plainText, SecretKey key, IvParameterSpec iv) {
        try {
            var cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, key, iv);
            return Base64.getEncoder()
                    .encodeToString(cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }

    }

    public static String decryptPasswordBased(String cipherText, SecretKey key, IvParameterSpec iv) {
        try {
            var cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, key, iv);
            return new String(cipher.doFinal(Base64.getDecoder()
                    .decode(cipherText)), StandardCharsets.UTF_8);
        } catch (NoSuchAlgorithmException e) {
            log.fatal("NoSuchAlgorithmException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (NoSuchPaddingException e) {
            log.fatal("NoSuchPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidAlgorithmParameterException e) {
            log.fatal("InvalidAlgorithmParameterException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (IllegalBlockSizeException e) {
            log.fatal("IllegalBlockSizeException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (InvalidKeyException e) {
            log.fatal("InvalidKeyException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } catch (BadPaddingException e) {
            log.fatal("BadPaddingException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }

    /**
     * @param cipherText
     * @return
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidKeyException
     * @throws InvalidAlgorithmParameterException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException                Código javascript que encripta:
     *                                            var text = "Soy Pablo Rafael López Martínez 79071119065";
     *                                            var secret = "NnT=]uF~9#[,7m6baq'K.+U@84k;j/z)";
     *                                            var encrypted = CryptoJS.AES.encrypt(text, secret);
     *                                            encrypted = encrypted.toString();
     *                                            console.log("Cipher text: " + encrypted);
     */
    public static String getDecryptedTextFromWeb(String cipherText) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        var cipherData = Base64.getDecoder().decode(cipherText);
        var saltData = Arrays.copyOfRange(cipherData, 8, 16);

        var md5 = MessageDigest.getInstance("MD5");
        var keyAndIV = generateKeyAndIV(32, 16, 1, saltData, KEY.getBytes(StandardCharsets.UTF_8), md5);
        var key = new SecretKeySpec(keyAndIV[0], "AES");
        var iv = new IvParameterSpec(keyAndIV[1]);

        var encrypted = Arrays.copyOfRange(cipherData, 16, cipherData.length);
        var aesCBC = Cipher.getInstance(TRANSFORMATION);
        aesCBC.init(Cipher.DECRYPT_MODE, key, iv);
        var decryptedData = aesCBC.doFinal(encrypted);
        return new String(decryptedData, StandardCharsets.UTF_8);
    }

    public static byte[][] generateKeyAndIV(int keyLength, int ivLength, int iterations, byte[] salt, byte[] password, MessageDigest md) {
        var digestLength = md.getDigestLength();
        var requiredLength = (keyLength + ivLength + digestLength - 1) / digestLength * digestLength;
        var generatedData = new byte[requiredLength];
        var generatedLength = 0;
        try {
            md.reset();
            while (generatedLength < keyLength + ivLength) {
                if (generatedLength > 0) {
                    md.update(generatedData, generatedLength - digestLength, digestLength);
                }
                md.update(password);
                if (salt != null) {
                    md.update(salt, 0, 8);
                }
                md.digest(generatedData, generatedLength, digestLength);
                for (int i = 1; i < iterations; i++) {
                    md.update(generatedData, generatedLength, digestLength);
                    md.digest(generatedData, generatedLength, digestLength);
                }
                generatedLength += digestLength;
            }

            var result = new byte[2][];
            result[0] = Arrays.copyOfRange(generatedData, 0, keyLength);
            if (ivLength > 0) {
                result[1] = Arrays.copyOfRange(generatedData, keyLength, keyLength + ivLength);
            }
            return result;
        } catch (DigestException e) {
            log.fatal("Error por DigestException: {}", e.getMessage());
            throw new IllegalStateException(e);
        } finally {
            Arrays.fill(generatedData, (byte) 0);
        }
    }
}
