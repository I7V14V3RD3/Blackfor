package mx.com.tecnetia.orthogonal.utils.files;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileUtils {
    private FileUtils() {

    }

    public static <T> List<T> readObjectsFromJsonFile(@NotBlank String path, @NotNull Class<T> beanClass) throws Exception {
        var myfile = path;
        var jsonData = readFileAsString(myfile);

        var objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();

        var listType = new TypeReference<List<T>>() {
        };

        return objectMapper.readValue(jsonData, listType);
    }

    public static <T> T readAnObjectFromJsonFile(@NotBlank String path, @NotNull Class<T> beanClass) throws Exception {
        var myfile = path;
        var jsonData = readFileAsString(myfile);

        var objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();

        return objectMapper.readValue(jsonData, beanClass);
    }

    private static String readFileAsString(String myFile) throws Exception {
        return new String(Files.readAllBytes(Paths.get(myFile)));
    }
}
