package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "validacion_reciclado")
public class PEntityValidacionReciclado {
    @Id
    @Column(name = "id_producto_reciclado")
    private Long idProductoReciclado;
    @Basic
    @Column(name = "momento_validacion")
    private LocalDateTime momentoValidacion;
    @Basic
    @Column(name = "validador")
    private Long validador;
    @Basic
    @Column(name = "aprobado")
    private Boolean aprobado;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PEntityValidacionReciclado that = (PEntityValidacionReciclado) o;
        return Objects.equals(idProductoReciclado, that.idProductoReciclado) && Objects.equals(momentoValidacion, that.momentoValidacion) && Objects.equals(validador, that.validador) && Objects.equals(aprobado, that.aprobado);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProductoReciclado, momentoValidacion, validador, aprobado);
    }
}
