package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.ModeloQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityQuiosco;
import org.apache.logging.log4j.core.config.plugins.validation.constraints.NotBlank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PEntityQuioscoRepository extends JpaRepository<PEntityQuiosco, Long> {
    boolean existsByQrOrIp(UUID qr, String ip);

    boolean existsByIpOrNombreAllIgnoreCase(@Nullable String ip, @Nullable String nombre);

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoDTO(ent.idQuiosco, ent.direccion, ent.latitud,
            ent.longitud, ent.qr, ent.ip, ent.alturaLlenadoMm, ent.tipoArduino, ent.nombre, ent.referencias, modelo.nombre, ent.activo)
            from PEntityQuiosco ent
             left join ent.modeloQuiosco modelo
            order by ent.latitud, ent.longitud
            """)
    List<QuioscoDTO> getAllQuioscos();

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoDTO(ent.idQuiosco, ent.direccion, ent.latitud,
            ent.longitud, ent.qr, ent.ip, ent.alturaLlenadoMm, ent.tipoArduino, ent.nombre, ent.referencias, modelo.nombre, ent.activo)
            from PEntityQuiosco ent
                left join ent.modeloQuiosco modelo
            where upper(ent.direccion) like %:dir%
            order by ent.latitud, ent.longitud
            """)
    List<QuioscoDTO> getQuioscosByDireccionSimilar(@NotBlank @Param("dir") String dir);

    @Query("""
            select new mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.ModeloQuioscoDTO(ent.idModeloQuiosco, ent.nombre)
            from PEntityModeloQuiosco ent
            order by ent.nombre
            """)
    List<ModeloQuioscoDTO> getAllModelosQuiosco();

}
