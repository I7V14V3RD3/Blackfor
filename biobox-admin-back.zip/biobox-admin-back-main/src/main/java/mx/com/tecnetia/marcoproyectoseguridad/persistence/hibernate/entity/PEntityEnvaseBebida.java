package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "envase_bebida")
public class PEntityEnvaseBebida {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_envase_bebida")
    private Long idEnvaseBebida;
    @Basic
    @Column(name = "id_producto_reciclable", insertable = false, updatable = false)
    private Long idProductoReciclable;
    @Basic
    @Column(name = "id_tipo_bebida", insertable = false, updatable = false)
    private Integer idTipoBebida;
    @Basic
    @Column(name = "id_sabor", insertable = false, updatable = false)
    private Integer idSabor;
    @ManyToOne
    @JoinColumn(name = "id_producto_reciclable", referencedColumnName = "id_producto_reciclable", nullable = false)
    private PEntityProductoReciclable productoReciclableByIdProductoReciclable;
    @ManyToOne
    @JoinColumn(name = "id_tipo_bebida", referencedColumnName = "id_tipo_bebida", nullable = false)
    private PEntityTipoBebida tipoBebidaByIdTipoBebida;
    @ManyToOne
    @JoinColumn(name = "id_sabor", referencedColumnName = "id_sabor", nullable = false)
    private PEntitySabor saborByIdSabor;
}
