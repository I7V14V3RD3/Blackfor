package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.Synchronized;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.TestService;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class TestServiceImpl implements TestService {
    private static final int MILI_SECONDS_TO_SLEEP = 200;
    private final ConcurrentHashMap<Long, Long> quioscosEnUso = new ConcurrentHashMap<>();

    /*Metodología a usar en la aplicación del quiosco para evitar
    que sea usado por más de 1 reciclador:*/
    @Override
    public Instant getTest() {
        log.info("Inicio del método getTest {}", Thread.currentThread().getId());
        sleepThread();
        log.info("Fin del método getTest {}", Thread.currentThread().getId());
        return Instant.now();
    }


    /*Metodología a usar en la aplicación servidor para evitar que se intente reciclar
    en un quiosco cuando está en uso:*/
    @Override
    public boolean reciclarConcurrent(Long idQuiosco) {
        var thId = Thread.currentThread().getId();
        log.info("Intenta reciclaje concurrente de {} en quiosco {}", thId, idQuiosco);
        if (!usarQuiosco(idQuiosco, thId)) {
            return false;
        }
        //Recicla:
        sleepThread();
        //Termina de reciclar:
        soltarQuiosco(idQuiosco);
        return true;
    }

    @Synchronized
    private void soltarQuiosco(Long idQuiosco) {
        log.info("Quioscos end: {}. Eliminando: {}", this.quioscosEnUso, idQuiosco);
        this.quioscosEnUso.remove(idQuiosco);
        log.info("Termina reciclaje concurrente de {} en quiosco {}", Thread.currentThread().getId(), idQuiosco);
    }

    @Synchronized
    private boolean usarQuiosco(Long idQuiosco, long thId) {
        log.info("Quioscos init: {}", this.quioscosEnUso);
        if (!this.quioscosEnUso.containsKey(idQuiosco)) {
            log.info("Inicia reciclaje concurrente de {} en quiosco {}", thId, idQuiosco);
            this.quioscosEnUso.put(idQuiosco, thId);
        } else {
            log.warn("Falla reciclaje concurrente de {} en quiosco {}", thId, idQuiosco);
            return false;
        }
        return true;
    }

    private static void sleepThread() {
        try {
            Thread.sleep(MILI_SECONDS_TO_SLEEP);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

}
