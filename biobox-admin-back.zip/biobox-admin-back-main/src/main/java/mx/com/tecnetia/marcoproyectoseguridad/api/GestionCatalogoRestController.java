package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.NuevaSubMarcaDTO;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.GestionCatalogoService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", exposedHeaders = "Content-Disposition")
@RestController
@RequestMapping("/gestion-catalogo")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Gestión catálogos.", description = "Gestión de los catálogos de la aplicación")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class GestionCatalogoRestController {
    private final GestionCatalogoService gestionCatalogoService;

    @Operation(summary = "Nuevo fabricante.", description = "Crea un nuevo fabricante.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Fabricante creado",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/fabricante")
    public ResponseEntity<Void> crearNuevoFabricante(@RequestBody @NotBlank String nombre) {
        this.gestionCatalogoService.nuevoFabricante(nombre);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @Operation(summary = "Nueva marca.", description = "Crea una nueva marca.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Marca creada",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/marca")
    public ResponseEntity<Void> crearNuevaMarca(@RequestBody @NotBlank String nombre) {
        this.gestionCatalogoService.nuevaMarca(nombre);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @Operation(summary = "Nueva sub marca.", description = "Crea una nueva sub marca.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Sub marca creada",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/sub-marca")
    public ResponseEntity<Void> crearNuevaSubMarca(@RequestBody @Valid @NotNull NuevaSubMarcaDTO dto) {
        this.gestionCatalogoService.nuevaSubMarca(dto);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
