package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "material")
public class PEntityMaterial {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_material")
    private Integer idMaterial;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @OneToMany(mappedBy = "materialByIdMaterial")
    private Collection<PEntityConfiguracionMovimientoCharolaQuiosco> configuracionMovimientoCharolaQuioscosByIdMaterial;
    @OneToMany(mappedBy = "material")
    private Collection<PEntityProductoReciclable> productoReciclablesByIdMaterial;
}
