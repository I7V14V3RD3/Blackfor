package mx.com.tecnetia.orthogonal.utils.crypto;

import jakarta.validation.constraints.NotEmpty;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.crypto.stream.CryptoInputStream;
import org.apache.commons.crypto.stream.CryptoOutputStream;
import org.apache.commons.crypto.utils.AES;
import org.springframework.stereotype.Component;

import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Properties;

/***
 * Clase con los métodos de encriptación y desencriptación usando apache commons
 * Se usó para generar el key y el IV esta página:
 * https://passwordsgenerator.net/
 */
@Component
@RequiredArgsConstructor
@Log4j2
public class ApacheCrypto {
    private static final String TRANSFORM = AES.CBC_PKCS5_PADDING;
    private static final int DECRYPTED_DATA_SIZE = 1024;
    //Debe ser de longitud 16, 24 o 32 bytes:
    private final SecretKeySpec key = AES.newSecretKeySpec(getUTF8Bytes("NnT=]uF~9#[,7m6baq'K.+U@84k;j/z)"));
    //Debe ser de longitud 16 bytes:
    private final IvParameterSpec iv = new IvParameterSpec(getUTF8Bytes("M</3BYJtac]}^:K2"));

    private static byte[] getUTF8Bytes(@NotEmpty String input) {
        return input.getBytes(StandardCharsets.UTF_8);
    }

    public String encrypt(@NotEmpty String input) {
        var properties = new Properties();
        var outputStream = new ByteArrayOutputStream();
        try (var cos = new CryptoOutputStream(TRANSFORM, properties, outputStream, key, iv)) {
            cos.write(getUTF8Bytes(input));
            cos.flush();
        } catch (IOException e) {
            log.fatal("Excepción en la encriptación. IOException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
        return Base64.getEncoder()
                .encodeToString(outputStream.toByteArray());
    }

    public String decrypt(@NotEmpty String cadena) {
        var properties = new Properties();
        var inputStream = new ByteArrayInputStream(Base64.getDecoder().decode(cadena));
        try (var cis = new CryptoInputStream(TRANSFORM, properties, inputStream, key, iv)) {
            var decryptedData = new byte[DECRYPTED_DATA_SIZE];
            var decryptedLen = 0;
            int i;
            while ((i = cis.read(decryptedData, decryptedLen, decryptedData.length - decryptedLen)) > -1) {
                decryptedLen += i;
            }
            return new String(decryptedData, 0, decryptedLen, StandardCharsets.UTF_8);
        } catch (IOException e) {
            log.fatal("Excepción en la desencriptación. IOException: {}", e.getMessage());
            throw new IllegalStateException(e);
        }
    }
}
