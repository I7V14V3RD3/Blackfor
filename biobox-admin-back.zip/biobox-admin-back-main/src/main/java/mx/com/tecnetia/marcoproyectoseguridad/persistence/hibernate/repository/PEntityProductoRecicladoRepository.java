package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import jakarta.validation.constraints.NotNull;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.puntos.ProductoPuntosDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.DatoReciclajeDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ProductoParaValidarDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityProductoReciclado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PEntityProductoRecicladoRepository extends JpaRepository<PEntityProductoReciclado, Long> {

    @Query("""
                select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ProductoParaValidarDTO(
                    reciclado.idProductoReciclado, reciclable.sku, reciclable.barCode, marca.nombre, subMarca.nombre,
                    fabricante.nombre, reciclado.momentoReciclaje, quiosco.nombre)
                from PEntityProductoReciclado reciclado
                    join reciclado.productoReciclable reciclable
                    join reciclable.fabricante fabricante
                    join reciclable.subMarca subMarca
                    join subMarca.marcaByIdMarca marca
                    join reciclado.fotoProductoReciclado foto
                    join PEntityProductoRecicladoQuiosco prq on (prq.idProductoReciclado = reciclado.idProductoReciclado)
                    join prq.quioscoByIdQuiosco quiosco
                where foto.exitoso = false and reciclado.momentoReciclaje between :fechaInicial and :fechaFinal
                    and reciclado.idProductoReciclado not in (
                        select ent.idProductoReciclado
                        from PEntityValidacionReciclado ent
                    )
                order by reciclado.momentoReciclaje
            """)
    List<ProductoParaValidarDTO> getProductosParaValidar(@Param("fechaInicial") @NotNull LocalDateTime fechaInicial,
                                                         @Param("fechaFinal") @NotNull LocalDateTime fechaFinal);

    @Query("""
                select ent.foto
                from PEntityFotoProductoReciclado ent
                where ent.idProductoReciclado = :idProductoReciclado
            """)
    Optional<byte[]> getFotoReciclado(@Param("idProductoReciclado") Long idProductoReciclado);

    @Query("""
                select new mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.DatoReciclajeDTO(year(pr.momentoReciclaje),
                    month (pr.momentoReciclaje), count(pr))
                from PEntityFotoProductoReciclado fpr
                    join fpr.productoReciclado pr
                where fpr.exitoso = false
                and pr.idProductoReciclado not in (
                        select ent.idProductoReciclado
                        from PEntityValidacionReciclado ent
                    )
                group by year(pr.momentoReciclaje), month (pr.momentoReciclaje)
                order by year(pr.momentoReciclaje), month (pr.momentoReciclaje)
            """)
    List<DatoReciclajeDTO> getDatosRecicladosNoExitosos();


}
