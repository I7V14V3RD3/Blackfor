package mx.com.tecnetia.orthogonal.security.auth;

import mx.com.tecnetia.orthogonal.security.JwtDTO;
import mx.com.tecnetia.orthogonal.security.LoginUsuarioDTO;
import mx.com.tecnetia.orthogonal.dto.NuevoUsuarioArquitecturaDTO;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import mx.com.tecnetia.orthogonal.persistence.hibernate.repository.ArqUsuarioRepository;
import mx.com.tecnetia.orthogonal.security.jwt.JwtProvider;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final ArqUsuarioRepository usuarioEntityRepository;
    private final JwtProvider jwtProvider;

    @Override
    @Transactional
    public void crearNuevoUsuario(NuevoUsuarioArquitecturaDTO nuevoUsuario) {

    }

    @Override
    @Transactional(readOnly = true)
    public JwtDTO login(LoginUsuarioDTO loginUsuario) {
        var arqUsuarioEntity = this.usuarioEntityRepository.findByNick(loginUsuario.getNick())
                .orElseThrow(() -> new IllegalArgumentException("El nick especificado no existe"));

        if (Boolean.TRUE.equals(arqUsuarioEntity.getActivo()) && Boolean.TRUE.equals(!arqUsuarioEntity.getPendienteConfirmacion())) {
            Authentication authentication;
            try {
                authentication = authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(loginUsuario.getNick(), loginUsuario.getPassw()));
            } catch (AuthenticationException ex) {
                throw new IllegalArgumentException("El usuario o la contraseña proporcionados no son válidos.");
            }

            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = jwtProvider.generateToken(authentication);
            var userDetails = (UserDetails) authentication.getPrincipal();
            return new JwtDTO(jwt, userDetails.getUsername(), userDetails.getAuthorities());
        }
        throw new IllegalArgumentException("El usuario especificado no puede iniciar sesión. Antes debe confirmar su email.");
    }

}
