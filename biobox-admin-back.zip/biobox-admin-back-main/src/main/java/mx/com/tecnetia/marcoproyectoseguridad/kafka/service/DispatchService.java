package mx.com.tecnetia.marcoproyectoseguridad.kafka.service;

public interface DispatchService {
    void process(String payload);
}
