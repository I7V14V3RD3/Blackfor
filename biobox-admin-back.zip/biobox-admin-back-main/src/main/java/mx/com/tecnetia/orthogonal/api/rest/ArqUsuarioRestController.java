package mx.com.tecnetia.orthogonal.api.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import mx.com.tecnetia.orthogonal.security.JwtDTO;
import mx.com.tecnetia.orthogonal.security.LoginUsuarioDTO;
import mx.com.tecnetia.orthogonal.security.NuevoUsuarioArquitecturaDTO;
import mx.com.tecnetia.orthogonal.security.UsuarioPrincipal;
import mx.com.tecnetia.orthogonal.security.auth.AuthService;
import mx.com.tecnetia.orthogonal.security.auth.AuthenticationFacadeComponent;
import mx.com.tecnetia.orthogonal.services.UsuarioService;
import mx.com.tecnetia.orthogonal.utils.crypto.AESUtils;
import mx.com.tecnetia.orthogonal.utils.crypto.ApacheCrypto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import static java.time.format.DateTimeFormatter.BASIC_ISO_DATE;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/arq")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Gestión de Usuarios de arquitectura.", description = "Operaciones básicas con los usuarios. Servicios ortogonales.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class ArqUsuarioRestController {
    private final AuthService authService;
    private final AuthenticationFacadeComponent authenticationFacadeComponent;
    private final UsuarioService usuarioService;
    private final SpringTemplateEngine thymeleafTemplateEngine;
    private final ApacheCrypto apacheCrypto;

    @Operation(summary = "Login de la aplicación. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = JwtDTO.class)))})
    @PostMapping("/free/login")
    public ResponseEntity<JwtDTO> login(@Valid @RequestBody LoginUsuarioDTO loginUsuario) {
        log.info("Login. Usuario entrando: {}", loginUsuario.getNick());
        JwtDTO jwtDTO = authService.login(loginUsuario);
        return new ResponseEntity<>(jwtDTO, HttpStatus.OK);
    }

    @Operation(summary = "Nuevo usuario de la aplicación. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = Long.class)))})
    @PostMapping("/free/usuario")
    public ResponseEntity<Long> crearUsuario(@Valid @RequestBody NuevoUsuarioArquitecturaDTO user) {
        var ret = this.usuarioService.guardar(user);
        return new ResponseEntity<>(ret.getIdArqUsuario(), HttpStatus.OK);
    }

    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Cambiar passw. LISTO.", description = "CUALQUIER ROL. Cambia el passw del usuario logeado",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = void.class)))})
//    @PutMapping(value = "/cambiaPassw", consumes = {MediaType.APPLICATION_JSON_VALUE})
    @PatchMapping(value = "/user-passw")
    public void cambiaPassw(@RequestParam("passw") @NotEmpty @Parameter(description = "Nuevo passw.") String passw) {
        var usuarioLogeado = (UsuarioPrincipal) authenticationFacadeComponent.getAuthentication().getPrincipal();
        log.info("Email del usuario Logeado: {}", usuarioLogeado.getEmail());
        this.usuarioService.cambiaPassw(usuarioLogeado, passw);
    }

    @Operation(summary = "Prueba de retorno de plantilla Thymeleaf. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/test")
    public ResponseEntity<String> test() {
        LocalDate esteMomento = LocalDate.now();
        log.info("Fecha antes: {}", esteMomento.toString());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYYMMdd");
        String formattedString = esteMomento.format(BASIC_ISO_DATE);
        log.info("Fecha: {}", formattedString);
        log.info("Cambiado: {}", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        log.info("Cambiado: {}", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/YYYY")));//Este está mal

        var model = new HashMap<String, Object>();
        model.put("name", "Hola Pablito");
        var thymeleafContext = new Context();
        thymeleafContext.setVariables(model);
        var templateThymeleafFile = "confirmacion-email-thymeleaf.html";
        String htmlBody = thymeleafTemplateEngine.process(templateThymeleafFile, thymeleafContext);

        log.info("Test. Fin");
        return new ResponseEntity<>(htmlBody, HttpStatus.OK);
    }

    /**
     * Los métodos siguientes se pueden llamar después de encriptar de la siguiente forma en JS:
     * @param cadena
     * @return
     * <code>
     *     <!DOCTYPE html>
     * <html>
     * <body>
     *
     * <h2>JavaScript Objects</h2>
     *
     * <p id="demo"></p>
     * <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.2.0/crypto-js.min.js"></script>
     *
     * <script>
     *
     *
     * const msg = CryptoJS.enc.Utf8.parse("Pablo López Martínez 79071119065");
     *
     *
     * const key = CryptoJS.enc.Utf8.parse("NnT=]uF~9#[,7m6baq'K.+U@84k;j/z)");
     * const iv = CryptoJS.enc.Utf8.parse("M</3BYJtac]}^:K2");
     *
     *
     * var cipherText = CryptoJS.AES.encrypt(msg, key, {
     * 	iv: iv,
     *     mode: CryptoJS.mode.CBC,
     *     padding: CryptoJS.pad.Pkcs7});
     * console.log(cipherText.toString()); //Este es el valor que se envía al end-point, ya está en Base64 en este punto
     *
     *
     * </script>
     *
     * </body>
     * </html>
     * </code>
     */
    @Operation(summary = "Encripta una cadena. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/encrypt")
    public ResponseEntity<String> encrypt(@RequestParam("cadena") @NotEmpty String cadena) {
        var ret = AESUtils.staticEncrypt(cadena);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Desencripta una cadena. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/decrypt")
    public ResponseEntity<String> decrypt(@RequestParam("cadena") @NotEmpty String cadena) {
        var ret = AESUtils.staticDecrypt(cadena);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Encripta una cadena usando apache commons crypto. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/encrypt2")
    public ResponseEntity<String> encrypt2(@RequestParam("cadena") @NotEmpty String cadena) {
        var ret = this.apacheCrypto.encrypt(cadena);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Desencripta una cadena usando apache commons crypto. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/decrypt2")
    public ResponseEntity<String> decrypt2(@RequestParam("cadena") @NotEmpty String cadena) {
        var ret = this.apacheCrypto.decrypt(cadena);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Devuelve datos para encriptación. Pruebas. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/datos")
    public ResponseEntity<EncryptData> datos() {
        var key = AESUtils.generateKey(256);
        var ivParameterSpec = AESUtils.generateIv();
        var ret = new EncryptData(key, ivParameterSpec);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    public record EncryptData(SecretKey key, IvParameterSpec iv) {
    }

    @Operation(summary = "Desencripta una cadena enviada desde JS, no usa IV. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/decrypt-js")
    public ResponseEntity<String> decryptFromJS(@RequestParam("cadena") @NotEmpty String cadena) throws NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException {
        var decryptedText = AESUtils.getDecryptedTextFromWeb(cadena);
        return new ResponseEntity<>(decryptedText, HttpStatus.OK);
    }
}
