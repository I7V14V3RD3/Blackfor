package mx.com.tecnetia.marcoproyectoseguridad.validators;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = NuevoQuioscoValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface NuevoQuioscoConstraint {
    String message() default "Los parámetros del nuevo quiosco no cumplen los requisitos de creación.";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
