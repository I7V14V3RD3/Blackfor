package mx.com.tecnetia.marcoproyectoseguridad.service.interfaces;

import jakarta.validation.constraints.NotNull;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.EstadisticaReciclajesNoExitososDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ProductoParaValidarDTO;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ProductoRecicladoService {
    List<ProductoParaValidarDTO> getProductosParaValidar(@NotNull LocalDateTime fechaInicial, @NotNull LocalDateTime fechaFinal);

    Optional<byte[]> getFotoReciclado(@NotNull Long idProductoReciclado);

    EstadisticaReciclajesNoExitososDTO getDatosRecicladosNoExitosos();
}
