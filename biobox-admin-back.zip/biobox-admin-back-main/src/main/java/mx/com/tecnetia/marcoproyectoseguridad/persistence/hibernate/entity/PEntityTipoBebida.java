package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "tipo_bebida")
public class PEntityTipoBebida {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_tipo_bebida")
    private Integer idTipoBebida;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @OneToMany(mappedBy = "tipoBebidaByIdTipoBebida")
    private Collection<PEntityEnvaseBebida> envaseBebidasByIdTipoBebida;
}
