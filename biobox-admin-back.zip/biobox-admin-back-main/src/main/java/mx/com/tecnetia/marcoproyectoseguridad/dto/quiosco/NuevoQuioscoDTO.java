package mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.UUID;

/**
 * DTO for {@link mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityQuiosco}
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class NuevoQuioscoDTO implements Serializable {
    @NotBlank
    private String direccion;
    @NotBlank
    private String latitud;
    @NotBlank
    private String longitud;
    private UUID qr;
    @NotBlank
    private String ip;
    @NotNull
    @Positive(message = "La altura debe ser mayor que 0 mm")
    private Integer alturaLlenadoMm;
    @NotNull
    private Boolean tipoArduino;
    @NotBlank
    private String nombre;
    @NotBlank
    private String referencias;
    private String modelo;
    private Boolean activo;
}
