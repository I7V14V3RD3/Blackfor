package mx.com.tecnetia.orthogonal.security;


import lombok.RequiredArgsConstructor;
import mx.com.tecnetia.orthogonal.security.jwt.JwtEntryPoint;
import mx.com.tecnetia.orthogonal.security.jwt.JwtTokenFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


@Configuration
@EnableWebSecurity
//@EnableGlobalMethodSecurity(prePostEnabled = true)
@RequiredArgsConstructor
@ComponentScan(basePackages = "mx.com.tecnetia")
public class WebSecurityConfig {
    private static final String[] AUTH_WHITE_LIST = {
            "/auth/*", "/v2/*", "/v3/*",
            "/swagger-resources/*",
            "/swagger-ui.html*",
            "/webjars/*",
            "/swagger-ui/*",
            "/swagger-ui/index.html*",
            "/error"
    };

    @Autowired
    private UserDetailsServiceImpl userDetailsServiceImpl;

    @Autowired
    private JwtEntryPoint jwtEntryPoint;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Bean
    public JwtTokenFilter jwtTokenFilter() {
        return new JwtTokenFilter();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfiguration) throws Exception {
        return authConfiguration.getAuthenticationManager();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();

        authProvider.setUserDetailsService(userDetailsServiceImpl);
        authProvider.setPasswordEncoder(passwordEncoder);

        return authProvider;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.cors(Customizer.withDefaults())
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests((request -> request
                        .requestMatchers(new AntPathRequestMatcher("/**/auth*")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/v3/**")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/swagger-resources/**")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/swagger-ui/**")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/webjars/**")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/error/**")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/free/**")).permitAll()
                        .requestMatchers(new AntPathRequestMatcher("/**/swagger/**")).permitAll()
                        .anyRequest().authenticated())
                ).exceptionHandling(v -> v.authenticationEntryPoint(jwtEntryPoint))
                .sessionManagement(v -> v.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        http.authenticationProvider(authenticationProvider());

        http.securityContext(securityContext -> securityContext
                .requireExplicitSave(true)
        );

        http.addFilterBefore(jwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
