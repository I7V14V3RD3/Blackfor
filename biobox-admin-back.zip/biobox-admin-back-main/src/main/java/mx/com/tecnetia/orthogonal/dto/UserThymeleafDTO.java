package mx.com.tecnetia.orthogonal.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserThymeleafDTO {
    private String name;
}
