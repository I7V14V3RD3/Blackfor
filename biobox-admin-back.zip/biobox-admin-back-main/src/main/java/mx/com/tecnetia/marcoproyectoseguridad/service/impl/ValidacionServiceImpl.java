package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ValidaReciclajeDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.PEntityValidacionReciclado;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityFotoProductoRecicladoRepository;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityValidacionRecicladoRepository;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ValidacionService;
import mx.com.tecnetia.orthogonal.services.UsuarioService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class ValidacionServiceImpl implements ValidacionService {
    private final UsuarioService usuarioService;
    private final PEntityValidacionRecicladoRepository pEntityValidacionRecicladoRepository;
    private final PEntityFotoProductoRecicladoRepository pEntityFotoProductoRecicladoRepository;

    @Override
    @Transactional
    public void validaReciclaje(@NotNull @Valid ValidaReciclajeDTO dto) {
        if (this.pEntityFotoProductoRecicladoRepository.existsByIdProductoRecicladoAndExitoso(dto.getIdProductoReciclado(), true)) {
            throw new IllegalArgumentException("El producto que especificadp está evaluado como exitoso, no requiere validación.");
        }
        var ent = this.pEntityValidacionRecicladoRepository.findById(dto.getIdProductoReciclado())
                .orElse(new PEntityValidacionReciclado()
                        .setIdProductoReciclado(dto.getIdProductoReciclado()));
        ent.setAprobado(dto.getAprobado());
        ent.setMomentoValidacion(LocalDateTime.now());
        ent.setValidador(this.usuarioService.getIdUsuarioLogeado());
        this.pEntityValidacionRecicladoRepository.save(ent);
    }
}
