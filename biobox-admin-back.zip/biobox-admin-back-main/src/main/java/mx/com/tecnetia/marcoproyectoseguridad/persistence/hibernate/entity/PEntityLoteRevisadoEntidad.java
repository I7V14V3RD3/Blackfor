package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "lote_revisado_entidad")
public class PEntityLoteRevisadoEntidad {
    @Id
    @Column(name = "id_producto_reciclado")
    private Long idProductoReciclado;
    @Basic
    @Column(name = "id_revision_reciclaje_entidad", insertable = false, updatable = false)
    private Long idRevisionReciclajeEntidad;
    @OneToOne
    @JoinColumn(name = "id_producto_reciclado", referencedColumnName = "id_producto_reciclado", nullable = false)
    private PEntityProductoRecicladoQuiosco productoRecicladoQuioscoByIdProductoReciclado;
    @ManyToOne
    @JoinColumn(name = "id_revision_reciclaje_entidad", referencedColumnName = "id_revision_reciclaje_entidad", nullable = false)
    private PEntityRevisionReciclajeEntidad revisionReciclajeEntidadByIdRevisionReciclajeEntidad;
}
