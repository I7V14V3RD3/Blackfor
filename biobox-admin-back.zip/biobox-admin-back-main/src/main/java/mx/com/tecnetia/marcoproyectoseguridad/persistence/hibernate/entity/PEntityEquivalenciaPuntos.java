package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "equivalencia_puntos")
public class PEntityEquivalenciaPuntos {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_equivalencia_puntos")
    private Long idEquivalenciaPuntos;
    @Basic
    @Column(name = "id_programa_lealtad", insertable = false, updatable = false)
    private Long idProgramaLealtad;
    @Basic
    @Column(name = "puntos")
    private Integer puntos;
    @Basic
    @Column(name = "monto")
    private BigDecimal monto;
    @Basic
    @Column(name = "monto_unidad_canje")
    private BigDecimal montoUnidadCanje;
    @Basic
    @Column(name = "fecha_desactivacion")
    private LocalDateTime fechaDesactivacion;
    @Basic
    @Column(name = "fecha_creacion")
    private Date fechaCreacion;
    @ManyToOne
    @JoinColumn(name = "id_programa_lealtad", referencedColumnName = "id_programa_lealtad", nullable = false)
    private PEntityProgramaLealtad programaLealtadByIdProgramaLealtad;
}
