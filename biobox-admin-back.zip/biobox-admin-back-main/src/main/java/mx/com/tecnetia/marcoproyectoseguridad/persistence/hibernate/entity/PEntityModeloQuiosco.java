package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "modelo_quiosco")
public class PEntityModeloQuiosco {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_modelo_quiosco")
    private Integer idModeloQuiosco;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @OneToMany(mappedBy = "modeloQuiosco")
    private Collection<PEntityQuiosco> quioscos;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PEntityModeloQuiosco that = (PEntityModeloQuiosco) o;
        return Objects.equals(idModeloQuiosco, that.idModeloQuiosco) && Objects.equals(nombre, that.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idModeloQuiosco, nombre);
    }

}
