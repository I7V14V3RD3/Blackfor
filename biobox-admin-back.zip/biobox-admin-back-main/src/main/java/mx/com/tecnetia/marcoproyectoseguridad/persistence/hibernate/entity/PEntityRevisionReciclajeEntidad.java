package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Objects;

@Entity
@Getter
@Setter
@Table(name = "revision_reciclaje_entidad")
public class PEntityRevisionReciclajeEntidad {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_revision_reciclaje_entidad")
    private Long idRevisionReciclajeEntidad;
    @Basic
    @Column(name = "qr_generado")
    private String qrGenerado;
    @Basic
    @Column(name = "momento")
    private LocalDateTime momento;
    @OneToMany(mappedBy = "revisionReciclajeEntidadByIdRevisionReciclajeEntidad")
    private Collection<PEntityLoteRevisadoEntidad> loteRevisadoEntidadsByIdRevisionReciclajeEntidad;
}
