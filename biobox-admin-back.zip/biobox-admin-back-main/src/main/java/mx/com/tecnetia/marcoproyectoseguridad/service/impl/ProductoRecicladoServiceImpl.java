package mx.com.tecnetia.marcoproyectoseguridad.service.impl;

import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.DatoReciclajeDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.EstadisticaReciclajesNoExitososDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.productoreciclable.validacion.ProductoParaValidarDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.PEntityProductoRecicladoRepository;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.ProductoRecicladoService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Log4j2
@Validated
public class ProductoRecicladoServiceImpl implements ProductoRecicladoService {
    private final PEntityProductoRecicladoRepository pEntityProductoRecicladoRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ProductoParaValidarDTO> getProductosParaValidar(@NotNull LocalDateTime fechaInicial, @NotNull LocalDateTime fechaFinal) {
        return this.pEntityProductoRecicladoRepository.getProductosParaValidar(fechaInicial, fechaFinal);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<byte[]> getFotoReciclado(Long idProductoReciclado) {
        return this.pEntityProductoRecicladoRepository.getFotoReciclado(idProductoReciclado);
    }

    @Override
    public EstadisticaReciclajesNoExitososDTO getDatosRecicladosNoExitosos() {
        var est = this.pEntityProductoRecicladoRepository.getDatosRecicladosNoExitosos();
        var sum = est.stream()
                .map(DatoReciclajeDTO::getCantidad)
                .reduce(0L, Long::sum);
        return new EstadisticaReciclajesNoExitososDTO()
                .setEstadistica(est)
                .setCantidadReciclajesNoExitosos(sum);
    }
}
