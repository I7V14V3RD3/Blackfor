package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.ModeloQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.NuevoQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoCreadoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.quiosco.QuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.service.interfaces.GestionQuioscoService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@CrossOrigin(origins = "*", exposedHeaders = "Content-Disposition")
@RestController
@RequestMapping("/quiosco")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Gestión de los quioscos.", description = "Operaciones de gestión de los quioscos de reciclaje.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class GestionQuioscoRestController {
    private final GestionQuioscoService gestionQuioscoService;

    @Operation(summary = "Nuevo quiosco.",
            description = "Crea un nuevo quiosco.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Cadena del QR del quiosco creado.",
            content = @Content(schema = @Schema(implementation = QuioscoCreadoDTO.class)))})
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/")
    public ResponseEntity<QuioscoCreadoDTO> crearNuevoQuiosco(@RequestBody @NotNull @Valid NuevoQuioscoDTO dto) {
        var ret = this.gestionQuioscoService.nuevoQuiosco(dto);
        return new ResponseEntity<>(ret, HttpStatus.CREATED);
    }

    @Operation(summary = "Nuevo quiosco", description = "Crea un nuevo quiosco y devuelve el QR en forma de imagen",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Operación exitosa.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = Byte.class)))})})
    @PreAuthorize("isAuthenticated()")
    @PostMapping(value = "/qr", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<byte[]> crearNuevoQuioscoQR(@RequestBody @NotNull @Valid NuevoQuioscoDTO dto) {
        var httpHeaders = new HttpHeaders();
        var ret = this.gestionQuioscoService.nuevoQuioscoQR(dto);
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
        httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ret.getQr() + ".jpg");
        return ResponseEntity.ok().headers(httpHeaders).body(ret.getImage());
    }

    @Operation(summary = "Genera QR", description = "Devuelve el QR en forma de imagen del quiosco especificado",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Operación exitosa.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = Byte.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping(value = "/qr-foto", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public ResponseEntity<byte[]> generaImagenQR( @NotNull Long idQuiosco) {
        var httpHeaders = new HttpHeaders();
        var ret = this.gestionQuioscoService.generaImagenQR(idQuiosco);
        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);
        httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ret.getQr() + ".jpg");
        return ResponseEntity.ok().headers(httpHeaders).body(ret.getImage());
    }

    @Operation(summary = "Todos los quioscos", description = "Busca todos los quioscos registrados en la aplicación.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de quioscos.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = QuioscoDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/todos")
    public ResponseEntity<List<QuioscoDTO>> buscarTodosLosQuioscos() {
        var ret = this.gestionQuioscoService.getAllQuioscos();
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Quioscos por dirección similar", description = "Busca todos los quioscos con dirección similar a la especificada.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de quioscos.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = QuioscoDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/por-direccion")
    public ResponseEntity<List<QuioscoDTO>> buscarQuioscosPorDireccion(@RequestParam("direccion") @NotBlank String direccion) {
        var ret = this.gestionQuioscoService.getQuioscosByDireccionSimilar(direccion);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Editar quiosco.",
            description = "Edita las propiedades (excepto el QR) de un quiosco existente.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Quiosco editado.",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PutMapping(value = "/")
    public ResponseEntity<Void> editarQuiosco(@RequestBody @NotNull @Valid QuioscoDTO dto) {
        this.gestionQuioscoService.editarQuiosco(dto);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Operation(summary = "Editar quiosco.",
            description = "Edita las propiedades de un quiosco existente y devuelve un nuevo QR.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "201", description = "Quiosco editado.",
            content = @Content(schema = @Schema(implementation = String.class)))})
    @PreAuthorize("isAuthenticated()")
    @PutMapping(value = "/nuevo-qr")
    public ResponseEntity<String> editarQuioscoConNuevoQR(@RequestBody @NotNull @Valid QuioscoDTO dto) {
        var ret = this.gestionQuioscoService.editarQuioscoConNuevoQR(dto);
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Genera QR faltantes en la BD.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Quiosco editado.",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @PatchMapping(value = "/genera-qr")
    public ResponseEntity<Void> creaTodosQRValidos() {
        this.gestionQuioscoService.creaTodosQRValidos();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Operation(summary = "Todos los modelos de quiosco", description = "Busca todos los modelos de quiosco registrados en la aplicación.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Listado de modelos de quiosco.",
            content = {@Content(array = @ArraySchema(schema = @Schema(implementation = ModeloQuioscoDTO.class)))})})
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/modelos")
    public ResponseEntity<List<ModeloQuioscoDTO>> buscarTodosLosModelosQuiosco() {
        var ret = this.gestionQuioscoService.getAllModelosQuiosco();
        return new ResponseEntity<>(ret, HttpStatus.OK);
    }

    @Operation(summary = "Elimina un quiosco.", description = "Elimina un quiosco dado un ID",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Quiosco eliminado.",
            content = @Content(schema = @Schema(implementation = void.class)))})
    @PreAuthorize("isAuthenticated()")
    @DeleteMapping(value = "/")
    public ResponseEntity<Void> deleteQuiosco(@RequestParam("id-quiosco") Long idQuiosco) {
        this.gestionQuioscoService.deleteQuiosco(idQuiosco);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
