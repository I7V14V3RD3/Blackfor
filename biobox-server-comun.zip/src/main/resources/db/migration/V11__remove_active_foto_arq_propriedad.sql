ALTER TABLE foto_usuario
DROP COLUMN activo;