ALTER TABLE arq_aplicacion
ADD uri varchar(500),
ADD codigo varchar(100);
