ALTER TABLE arq_usuario_rol
DROP COLUMN activo;