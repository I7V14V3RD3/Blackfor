ALTER TABLE servicio_usado
ADD momento timestamp,
ADD id_programa_prontipago int4,
ADD FOREIGN KEY (id_programa_prontipago) REFERENCES programa_prontipago(id_programa_prontipago),
DROP COLUMN fecha_uso,
DROP COLUMN id_servicio;
