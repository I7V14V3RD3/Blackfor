ALTER TABLE arq_usuario
ADD lada varchar(15);