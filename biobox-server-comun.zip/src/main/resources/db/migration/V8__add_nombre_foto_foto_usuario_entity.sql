ALTER TABLE arq_propiedad
ADD nombre_foto varchar(255);
