ALTER TABLE arq_propiedad
DROP COLUMN nombre_foto;
