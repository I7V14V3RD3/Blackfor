ALTER TABLE foto_usuario
ADD nombre_foto varchar(255),
DROP COLUMN activo;
