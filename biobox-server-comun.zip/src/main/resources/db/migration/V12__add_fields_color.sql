ALTER TABLE color
ADD hexadecimal varchar(255),
ADD url_foto varchar(255),
ADD url_foto_2 varchar(255),
DROP COLUMN activo;
