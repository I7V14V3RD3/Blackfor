ALTER TABLE programa_prontipago
ADD codigo text,
ADD id_categoria_prontipago int4,
ADD vigencia_inicio timestamp,
ADD vigencia_fin timestamp,
ADD FOREIGN KEY (id_categoria_prontipago) REFERENCES categoria_prontipago(id_categoria_prontipago),
DROP COLUMN activo;
