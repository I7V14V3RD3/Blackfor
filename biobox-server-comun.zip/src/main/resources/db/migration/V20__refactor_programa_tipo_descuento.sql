ALTER TABLE programa_tipo_descuento
ADD descripcion text,
DROP COLUMN activo;
