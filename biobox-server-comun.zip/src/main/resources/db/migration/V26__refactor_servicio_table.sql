ALTER TABLE usuario_puntos
DROP COLUMN activo;
