ALTER TABLE arq_usuario
ADD id_arq_pais int4,
ADD FOREIGN KEY (id_arq_pais) REFERENCES arq_pais(id_arq_pais);
