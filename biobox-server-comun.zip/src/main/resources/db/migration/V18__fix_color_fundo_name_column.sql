ALTER TABLE categoria_prontipago RENAME color_fundo TO color_fondo
