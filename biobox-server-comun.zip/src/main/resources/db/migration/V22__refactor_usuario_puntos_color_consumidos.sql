ALTER TABLE usuario_puntos_color_consumidos
ADD id_servicio_usado int4,
ADD FOREIGN KEY (id_servicio_usado) REFERENCES servicio_usado(id_servicio_usado),
DROP COLUMN id_arq_usuario,
DROP COLUMN fecha_consumo;
