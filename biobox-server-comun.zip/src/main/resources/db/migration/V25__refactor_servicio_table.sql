ALTER TABLE servicio
ADD puntos int4,
ADD fecha_inicio timestamp,
ADD fecha_fin timestamp,
ADD id_programa_prontipago int4,
ADD FOREIGN KEY (id_programa_prontipago) REFERENCES programa_prontipago(id_programa_prontipago),
ADD id_color int4,
ADD FOREIGN KEY (id_color) REFERENCES color(id_color),
DROP COLUMN nombre,
DROP COLUMN activo,
DROP COLUMN descripcion;
