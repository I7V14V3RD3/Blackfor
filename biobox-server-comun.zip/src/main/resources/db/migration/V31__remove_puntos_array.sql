ALTER TABLE reciclaje_mexico
DROP COLUMN puntos_color_acumulado,
DROP COLUMN colors_acumulado;