ALTER TABLE arq_propiedad
ADD grupo_codigo varchar(100);