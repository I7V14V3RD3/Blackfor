ALTER TABLE arq_propiedad
ADD codigo varchar(500);