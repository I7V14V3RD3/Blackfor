ALTER TABLE usuario_puntos_color
DROP COLUMN activo;