ALTER TABLE programa_puntos_requeridos
ADD puntos_limite_inferior int4 NOT NULL,
ADD puntos_limite_superior int4 NOT NULL,
ADD puntos_coste int4 NOT NULL,
DROP COLUMN activo,
DROP COLUMN puntos;
