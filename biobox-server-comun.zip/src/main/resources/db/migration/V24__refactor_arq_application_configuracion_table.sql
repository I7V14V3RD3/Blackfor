ALTER TABLE arq_aplicacion_configuracion
ADD codigo varchar(100),
ADD id_arq_propiedad int4,
ADD FOREIGN KEY (id_arq_propiedad) REFERENCES arq_propiedad(id_arq_propiedad),
DROP COLUMN descripcion,
DROP COLUMN nombre;
