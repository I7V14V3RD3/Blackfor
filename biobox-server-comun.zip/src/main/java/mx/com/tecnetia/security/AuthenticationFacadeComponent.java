package mx.com.tecnetia.security;

import org.springframework.security.core.Authentication;

public interface AuthenticationFacadeComponent {
    Authentication getAuthentication();
}
