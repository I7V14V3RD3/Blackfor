package mx.com.tecnetia.security;

import mx.com.tecnetia.entity.ArqUsuarioEntity;
import mx.com.tecnetia.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UsuarioService usuarioService;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String nombreUsuario) throws UsernameNotFoundException {
        ArqUsuarioEntity usuario = usuarioService.getByNick(nombreUsuario).orElseThrow(()-> new IllegalArgumentException("El nick especificado no existe"));
        return UsuarioPrincipal.build(usuario);
    }
}
