package mx.com.tecnetia.security;

import mx.com.tecnetia.entity.ArqUsuarioEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.io.Serial;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class UsuarioPrincipal implements UserDetails {

    @Serial
    private static final long serialVersionUID = -7252157924247914354L;
    private final Long id;
    private final String nombre;
    private final String nombreUsuario;
    private final String email;
    private final String password;
    private final String telefono;
    private final Long idPais;
    private final Collection<? extends GrantedAuthority> authorities;

    public UsuarioPrincipal(Long id, String nombre, String nombreUsuario, String email, String password, Long idPais, String telefono, Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.nombre = nombre;
        this.nombreUsuario = nombreUsuario;
        this.email = email;
        this.password = password;
        this.idPais = idPais;
        this.telefono = telefono;
        this.authorities = authorities;
    }

    public static UsuarioPrincipal build(ArqUsuarioEntity usuario) {
        List<GrantedAuthority> authorities = usuario.getArqUsuarioRolesByIdArqUsuario().stream()
                .map(rol -> new SimpleGrantedAuthority(rol.getArqRolByIdArqRol().getNombre()))
                .collect(Collectors.toList());
//        .getArqRolAplicacionEntity().getNombre()
        return new UsuarioPrincipal(usuario.getIdArqUsuario(), usuario.getNombres(), usuario.getNick(),
                usuario.getEmail(), usuario.getPassw(), usuario.getIdArqPais(), usuario.getTelefono(), authorities);
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return nombreUsuario;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    public String getTelefono() {
        return telefono;
    }

    public Long getIdPais() {
        return this.idPais;
    }
}
