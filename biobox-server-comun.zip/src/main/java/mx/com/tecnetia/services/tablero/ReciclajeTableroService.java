package mx.com.tecnetia.services.tablero;

import mx.com.tecnetia.mensajeria.dto.EventoReciclaje;

public interface ReciclajeTableroService {
    void guardarDatos(EventoReciclaje evento);
    String getTipo();
}
