package mx.com.tecnetia.services.propriedades;

import jakarta.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import lombok.Getter;
import mx.com.tecnetia.entity.ArqPropiedadEntity;
import mx.com.tecnetia.repository.ArqPropiedadEntityRepository;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Configuration
@AllArgsConstructor
public class PropiedadComponent {

    @Getter
    private List<ArqPropiedadEntity> propiedades;
    private final ArqPropiedadEntityRepository arqPropiedadEntityRepository;

    @PostConstruct
    void init(){
        this.propiedades = this.arqPropiedadEntityRepository.findAll();
    }
}
