package mx.com.tecnetia.services;

import mx.com.tecnetia.mensajeria.dto.ActualizaPuntosEvento;

public interface UsuarioPuntosColorService {

    void guardarPuntos(ActualizaPuntosEvento evento);
}
