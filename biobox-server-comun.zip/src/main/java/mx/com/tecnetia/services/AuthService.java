package mx.com.tecnetia.services;

import mx.com.tecnetia.security.JwtDTO;
import mx.com.tecnetia.security.LoginUsuarioDTO;

public interface AuthService {
    JwtDTO login(LoginUsuarioDTO loginUsuario);
}
