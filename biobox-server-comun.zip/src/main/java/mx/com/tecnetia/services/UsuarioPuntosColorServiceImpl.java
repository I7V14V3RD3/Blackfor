package mx.com.tecnetia.services;

import lombok.AllArgsConstructor;
import mx.com.tecnetia.entity.ArqUsuarioEntity;
import mx.com.tecnetia.entity.ColorEntity;
import mx.com.tecnetia.entity.UsuarioPuntosColorEntity;
import mx.com.tecnetia.mensajeria.dto.ActualizaPuntosEvento;
import mx.com.tecnetia.repository.UsuarioPuntosColorEntityRepository;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UsuarioPuntosColorServiceImpl implements UsuarioPuntosColorService {

    private UsuarioPuntosColorEntityRepository usuarioPuntosColorEntityRepository;

    @Override
    public void guardarPuntos(ActualizaPuntosEvento actualizaPuntosEvento) {
        var usuarioPuntosColorOpt = usuarioPuntosColorEntityRepository.findByIdArqUsuario(actualizaPuntosEvento.getUsuarioPuntosColorEntities().getIdArqUsuario());
        if (usuarioPuntosColorOpt.isPresent()) {
            var usuarioPuntos = usuarioPuntosColorOpt.get();
            usuarioPuntos.setPuntos(actualizaPuntosEvento.getUsuarioPuntosColorEntities().getPuntos());
            usuarioPuntos.setColorByIdColor(new ColorEntity(actualizaPuntosEvento.getUsuarioPuntosColorEntities().getIdColor()));
            usuarioPuntosColorEntityRepository.save(usuarioPuntos);
            return;
        }
        var usuarioPuntosColor = new UsuarioPuntosColorEntity();
        usuarioPuntosColor.setArqUsuarioByIdArqUsuario(new ArqUsuarioEntity(actualizaPuntosEvento.getUsuarioPuntosColorEntities().getIdArqUsuario()));
        usuarioPuntosColor.setPuntos(actualizaPuntosEvento.getUsuarioPuntosColorEntities().getPuntos());
        usuarioPuntosColor.setColorByIdColor(new ColorEntity(actualizaPuntosEvento.getUsuarioPuntosColorEntities().getIdColor()));
        usuarioPuntosColorEntityRepository.save(usuarioPuntosColor);
    }
}
