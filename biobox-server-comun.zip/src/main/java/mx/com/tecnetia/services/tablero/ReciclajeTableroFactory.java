package mx.com.tecnetia.services.tablero;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ReciclajeTableroFactory {

    @Autowired
    private List<ReciclajeTableroService> services;

    private static final Map<String, ReciclajeTableroService> myServiceCache = new HashMap<>();

    @PostConstruct
    public void initMyServiceCache() {
        for(ReciclajeTableroService service : services) {
            myServiceCache.put(service.getTipo(), service);
        }
    }

    public static ReciclajeTableroService getService(String type) {
        ReciclajeTableroService service = myServiceCache.get(type);
        if(service == null) throw new RuntimeException("Unknown service type: " + type);
        return service;
    }
}
