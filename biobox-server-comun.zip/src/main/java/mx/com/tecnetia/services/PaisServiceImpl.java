package mx.com.tecnetia.services;

import mx.com.tecnetia.dto.PaisDTO;
import mx.com.tecnetia.repository.ArqPaisRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaisServiceImpl implements PaisService {

    private final ArqPaisRepository arqPaisRepository;

    public PaisServiceImpl(ArqPaisRepository arqPaisRepository) {
        this.arqPaisRepository = arqPaisRepository;
    }

    @Override
    public List<PaisDTO> findAllActivos() {
        var optPaises = arqPaisRepository.findAllByActivoTrue();
        return optPaises.map(arqPaisEntities -> arqPaisEntities.stream().map(pais ->
                new PaisDTO(pais.getIdArqPais(), pais.getNombre(), pais.getFlag(),
                        pais.getCodigo(), pais.getLada(), pais.getActivo())).toList()).orElseGet(List::of);
    }
}
