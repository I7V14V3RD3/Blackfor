package mx.com.tecnetia.services;

import mx.com.tecnetia.dto.MensajeDTO;

public interface VerificacionEmailService {
    MensajeDTO<?> enviarLinkVerificacion(String email);
    String validarLinkVerificacion(String token);
    MensajeDTO<?> enviarOTP(String email);
    MensajeDTO<?> validarOTP(String email, String codigo);
    MensajeDTO<?> estatusVerificacion(String email);
}
