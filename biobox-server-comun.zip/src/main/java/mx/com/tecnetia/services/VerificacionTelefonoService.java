package mx.com.tecnetia.services;

import mx.com.tecnetia.dto.MensajeDTO;

public interface VerificacionTelefonoService {

    MensajeDTO<?> enviarOTPporSMS(String telefono, String lada);
    MensajeDTO<?> validarOTPporSMS(String telefono, String codigo);
    MensajeDTO<?> estatusVerificacion(String telefono);
}
