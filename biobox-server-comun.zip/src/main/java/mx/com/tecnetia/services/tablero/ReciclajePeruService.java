package mx.com.tecnetia.services.tablero;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.entity.tablero.ReciclajePeru;
import mx.com.tecnetia.mensajeria.dto.EventoReciclaje;
import mx.com.tecnetia.repository.UsuarioPuntosColorEntityRepository;
import mx.com.tecnetia.repository.tablero.ReciclajePeruRepository;
import mx.com.tecnetia.services.UsuarioService;
import org.springframework.stereotype.Service;

@Service

@AllArgsConstructor
@Log4j2
public class ReciclajePeruService implements ReciclajeTableroService {

    private final ReciclajePeruRepository reciclajePeruRepository;
    private final UsuarioService usuarioService;
    private final UsuarioPuntosColorEntityRepository usuarioPuntosColorEntityRepository;

    @Override
    public void guardarDatos(EventoReciclaje evento) {
        reciclajePeruRepository.save(eventToEntity(evento));
    }

    @Override
    public String getTipo() {
        return "PE";
    }

    private ReciclajePeru eventToEntity(EventoReciclaje evento) {
        var idUsuario = evento.getProductoReciclado().getArqUsuarioByIdArqUsuario().getIdArqUsuario();
        log.info("Guardando tablero para el usuario: {}", idUsuario);
        var usuario = usuarioService.getByIdArqUsuario(Long.valueOf(idUsuario)).orElseThrow(() -> new IllegalArgumentException("No existe el usuario especificado."));
        return ReciclajePeru.builder()
                .momentoReciclaje(evento.getProductoReciclado().getMomentoReciclaje())
                .idArqUsuario(evento.getProductoReciclado().getArqUsuarioByIdArqUsuario().getIdArqUsuario())
                .nombreUsuario(usuario.getNombres())
                .apellidoPaternoUsuario(usuario.getApellidoPaterno())
                .apellidoMaternoUsuario(usuario.getApellidoMaterno())
                .emailUsuario(usuario.getEmail())
                .telefonoUsuario(usuario.getTelefono())
                .fechaRegistroUsuario(usuario.getFechaRegistro())
                .idProductoReciclabe(evento.getProductoReciclado().getIdProductoReciclable())
                .skuProductoReciclable(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getSku())
                .barcodeProductoReciclable(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getBarCode())
                .idMaterial(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getIdMaterial())
                .material(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getMaterialByIdMaterial().getNombre())
                .idSubMarca(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getSubMarcaByIdSubMarca().getIdSubMarca())
                .subMarca(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getSubMarcaByIdSubMarca().getNombre())
                .idMarca(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getSubMarcaByIdSubMarca().getMarcaByIdMarca().getIdMarca())
                .marca(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getSubMarcaByIdSubMarca().getMarcaByIdMarca().getNombre())
                .idCapacidad(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getCapacidadByIdCapacidad().getIdCapacidad())
                .capacidad(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getCapacidadByIdCapacidad().getCantidad())
                .idUnidadeDeMedida(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getCapacidadByIdCapacidad().getUnidadMedidaByIdUnidadMedida().getIdUnidadMedida())
                .unidadeDeMedida(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getCapacidadByIdCapacidad().getUnidadMedidaByIdUnidadMedida().getNombre())
                .unidadeDeMedidaSigla(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getCapacidadByIdCapacidad().getUnidadMedidaByIdUnidadMedida().getSiglas())
                .pesoMinimo(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getPesoMinimo())
                .pesoMaximo(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getPesoMaximo())
                .idFabricante(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getFabricante().getIdFabricante())
                .fabricante(evento.getProductoReciclado().getProductoReciclableByIdProductoReciclable().getFabricante().getNombre())
                .totalPuntosColorAcumulado(evento.getProductoReciclado().getUsuarioPuntosColorAcumulados().stream().reduce(0, (partialAgeResult, user) -> partialAgeResult + user.getPuntos(), Integer::sum))
                .direccionQuiosco(evento.getQuiosco().getDireccion())
                .latitudQuiosco(evento.getQuiosco().getLatitud())
                .longitudQuiosco(evento.getQuiosco().getLongitud())
                .ipQuiosco(evento.getQuiosco().getIp())
                .qrQuiosco(evento.getQuiosco().getQr())
                .alturaLlenadoMm(evento.getQuiosco().getAlturaLlenadoMm())
                .quiscoArduino(evento.getQuiosco().getTipoArduino())
                .quiscoNombre(evento.getQuiosco().getNombre())
                .reciclajeExitosa(evento.getProductoReciclado().getExitoso())
                .build();
    }
}
