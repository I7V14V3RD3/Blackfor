package mx.com.tecnetia.services;

import mx.com.tecnetia.dto.PaisDTO;

import java.util.List;

public interface PaisService {
    List<PaisDTO> findAllActivos();
}
