package mx.com.tecnetia.services;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.dto.MensajeDTO;
import mx.com.tecnetia.dto.SmsDTO;
import mx.com.tecnetia.entity.ArqUsuarioEntity;
import mx.com.tecnetia.repository.ArqUsuarioRepository;
import mx.com.tecnetia.services.sms.TwilioSMSService;
import mx.com.tecnetia.util.EstatusProcesoEnum;
import mx.com.tecnetia.util.EstatusVerificacionEnum;
import mx.com.tecnetia.util.FormatosUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

@Service
@RequiredArgsConstructor
@Log4j2
public class VerificacionTelefonoServiceImpl implements VerificacionTelefonoService {

    private final TwilioSMSService twilioSMSService;
    private final ArqUsuarioRepository arqUsuarioRepository;
    private static Map<String, String> otpsOfPhone = new HashMap<String, String>();

    @Override
    public MensajeDTO<?> enviarOTPporSMS(String telefono, String lada) {
        telefono = telefono.replace(" ", "");
        lada = lada.replace(" ", "");
        log.info("enviarOTPporSMS: " + lada + telefono);

        if (!FormatosUtil.numeroTelefonoValido(telefono)) {
            throw new IllegalArgumentException("El número no cumple la cantidad de dígitos.");
        }

        String otp = this.getOTP(telefono);
        log.info("El OTP de {} es {}", "+" + lada + telefono, otp);
        String mensaje = "Su código de verificación de BioBox es: " + otp;
        SmsDTO sms = new SmsDTO("+" + lada + telefono, mensaje);
        String response = twilioSMSService.send(sms);

        if (response != null) {
            log.info("El código de verificación fue enviado correctamente");
            return new MensajeDTO<>(EstatusProcesoEnum.EXITOSO.getValue(), "Código enviado", otp);
        } else {
            log.info("No se envió el código de verificación");
            throw new IllegalArgumentException("Error al enviar código");
        }
    }

    @Override
    public MensajeDTO<?> validarOTPporSMS(String telefono, String codigo) {
        telefono = telefono.replace(" ", "");
        log.info("validarOTP: {} - {}", telefono, codigo);

        if (!FormatosUtil.numeroTelefonoValido(telefono)) {
            throw new IllegalArgumentException("El número no cumple la cantidad de dígitos.");
        }

        Optional<ArqUsuarioEntity> usuario = this.arqUsuarioRepository.findByTelefono(telefono);
        boolean valido = codigo.equals(otpsOfPhone.get(telefono.replace(" ", ""))) ? true : false;

        if (valido) {
            if (usuario.isPresent()) {
                usuario.get().setTelefonoValidado(true);
                this.arqUsuarioRepository.save(usuario.get());
            }
            otpsOfPhone.remove(telefono);
            log.info("El telefono fue verificado correctamente {}", telefono);
            return new MensajeDTO<>(EstatusProcesoEnum.EXITOSO.getValue(), "Tu teléfono fue verificado");
        } else {
            log.info("El telefono no fue verificado correctamente {}", telefono);
            throw new IllegalArgumentException("El código es inválido");
        }
    }

    @Override
    @Transactional
    public MensajeDTO<?> estatusVerificacion(String telefono) {
        telefono = telefono.replace(" ", "");
        log.info("estatusDeVerificacion: {}", telefono);

        if (!FormatosUtil.numeroTelefonoValido(telefono)) {
            throw new IllegalArgumentException("El número no cumple con el formato de 10 digitos");
        }

        Optional<ArqUsuarioEntity> usuario = this.arqUsuarioRepository.findByTelefono(telefono);

        if (usuario.isPresent()) {
            if (usuario.get().getTelefonoValidado()) {
                log.info("El numero de telefono ya fue verificado");
                return new MensajeDTO<>(EstatusVerificacionEnum.VERIFICADO.getValue(), "Tu número de teléfono ya fue verificado.");
            } else {
                log.info("El telefono no esta verificado");
                return new MensajeDTO<>(EstatusVerificacionEnum.NO_VERIFICADO.getValue(), "Verifica tu número de teléfono.");
            }
        } else {
            log.info("El telefono no fue encontrado");
            throw new IllegalArgumentException("No se encontró el número de teléfono.");
        }
    }

    private String getOTP(String telefono) {
        telefono = telefono.replace(" ", "");
        String otp = otpsOfPhone.get(telefono);

        if (otp == null) {
            otp = String.format("%02d", new Random().nextInt(900000) + 100000);
            otpsOfPhone.put(telefono, otp);
        }
        //otpsOfPhone.forEach((key, value) -> System.out.println(key + " " + value));
        return otp;
    }
}
