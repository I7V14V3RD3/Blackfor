package mx.com.tecnetia.services;

import mx.com.tecnetia.dto.MensajeDTO;
import mx.com.tecnetia.entity.ArqUsuarioEntity;
import mx.com.tecnetia.security.EditaUsuarioArquitecturaDTO;
import mx.com.tecnetia.security.EstatusUsuarioDTO;
import mx.com.tecnetia.security.NuevoUsuarioArquitecturaDTO;

import java.util.Optional;

public interface UsuarioService {

    ArqUsuarioEntity getUsuarioLogueado();

    Optional<ArqUsuarioEntity> getByNick(String nu);

    MensajeDTO crearUsuario(NuevoUsuarioArquitecturaDTO nuevoUsuario, byte[] foto, String nombreFoto);

    MensajeDTO editarUsuario(EditaUsuarioArquitecturaDTO datos);

    MensajeDTO editarContrasenia(String correo, String passw);

    void editarContraseniaPendienteConfirmacion(String correo, String contrasenia);

    void recuperarContrasenia(String email);

    void desactivarUsuario(String correo);
    EstatusUsuarioDTO existeUsuario(String nick);
    boolean registroConcluido(ArqUsuarioEntity usuario);

    Optional<ArqUsuarioEntity> getByIdArqUsuario(Long idArqUsuario);
}
