package mx.com.tecnetia.repository;

import mx.com.tecnetia.dto.PuntosColorDTO;
import mx.com.tecnetia.entity.UsuarioPuntosColorConsumidosEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioPuntosColorConsumidosEntityRepository extends JpaRepository<UsuarioPuntosColorConsumidosEntity, Long> {

    @Query("""
            select new mx.com.tecnetia.dto.PuntosColorDTO
            (c.idColor,c.nombre, c.hexadecimal, ent.puntos, c.urlFoto, c.urlFoto2)
            from UsuarioPuntosColorConsumidosEntity ent join ent.colorByIdColor c
            where ent.idServicioUsado = :idServicioUsado order by c.nombre asc
            """)
    List<PuntosColorDTO> getPuntosByCanje(@Param("idServicioUsado") Long idServicioUsado);
}
