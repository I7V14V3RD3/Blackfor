package mx.com.tecnetia.repository.tablero;

import mx.com.tecnetia.entity.tablero.ReciclajePeru;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReciclajePeruRepository  extends JpaRepository<ReciclajePeru, Long> {
}
