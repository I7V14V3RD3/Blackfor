package mx.com.tecnetia.repository;

import mx.com.tecnetia.entity.ArqUsuarioRolEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArqUsuarioRolAplicacionEntityRepository extends JpaRepository<ArqUsuarioRolEntity, Long> {
}
