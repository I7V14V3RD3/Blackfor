package mx.com.tecnetia.repository;

import mx.com.tecnetia.entity.ColorEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ColorEntityRepository extends JpaRepository<ColorEntity, Integer> {
}
