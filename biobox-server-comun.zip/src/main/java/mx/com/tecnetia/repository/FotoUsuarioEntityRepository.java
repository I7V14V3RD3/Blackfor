package mx.com.tecnetia.repository;

import mx.com.tecnetia.entity.FotoUsuarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FotoUsuarioEntityRepository extends JpaRepository<FotoUsuarioEntity, Long> {

    FotoUsuarioEntity findByIdArqUsuario(Long idArqUsuario);
}
