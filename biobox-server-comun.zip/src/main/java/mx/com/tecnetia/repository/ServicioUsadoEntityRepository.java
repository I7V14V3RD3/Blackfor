package mx.com.tecnetia.repository;

import mx.com.tecnetia.entity.ServicioUsadoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ServicioUsadoEntityRepository extends JpaRepository<ServicioUsadoEntity, Long> {
}
