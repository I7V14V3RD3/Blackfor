package mx.com.tecnetia.repository;

import mx.com.tecnetia.entity.ArqPaisEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ArqPaisRepository extends JpaRepository<ArqPaisEntity, Long> {

    Optional<List<ArqPaisEntity>>  findAllByActivoTrue();
}
