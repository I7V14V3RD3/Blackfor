package mx.com.tecnetia.repository.mapper;

import mx.com.tecnetia.dto.DiaReciclajeBloqueadoDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DiaReciclajeBloqueadoRowMapper implements RowMapper<DiaReciclajeBloqueadoDTO>  {
    @Override
    public DiaReciclajeBloqueadoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        var ent = new DiaReciclajeBloqueadoDTO(
                rs.getDate("fecha"),
                rs.getInt("cant")
        );

        return ent;
    }
}
