package mx.com.tecnetia.repository;

import mx.com.tecnetia.dto.RolDTO;
import mx.com.tecnetia.entity.ArqRolEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ArqRolAplicacionRepository extends JpaRepository<ArqRolEntity, Long> {
    Optional<ArqRolEntity> findByNombre(String nombre);

    @Query("""
            select new mx.com.tecnetia.dto.RolDTO(ent.idArqRol, ent.nombre, ent.descripcion)
            from ArqRolEntity ent
            """)
    List<RolDTO> getAllRolesDTO();
}
