package mx.com.tecnetia.repository.tablero;

import mx.com.tecnetia.entity.tablero.ReciclajeMexico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReciclajeMexicoRepository extends JpaRepository<ReciclajeMexico, Long> {
}
