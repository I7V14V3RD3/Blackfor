package mx.com.tecnetia.repository;

import mx.com.tecnetia.entity.ProgramaProntipagoEntity;
import mx.com.tecnetia.entity.ProgramaPuntosRequeridosEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProgramaProntipagoEntityRepository extends JpaRepository<ProgramaProntipagoEntity, Long> {
    Optional<ProgramaProntipagoEntity> findByPuntosRequeridos(ProgramaPuntosRequeridosEntity puntosRequeridos);
}
