package mx.com.tecnetia.mensajeria.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UnidadMedida {

    private Integer idUnidadMedida;
    private String nombre;
    private String siglas;
}
