package mx.com.tecnetia.mensajeria.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import mx.com.tecnetia.mensajeria.dto.EventoReciclaje;
import mx.com.tecnetia.services.tablero.ReciclajeTableroFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class EventoReciclajeConsumer {

    @RabbitListener(queues = "${reciclaje.event.queue}")
    public void receive(String message) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            var evento = mapper.readValue(message, EventoReciclaje.class);
            var service = ReciclajeTableroFactory.getService(evento.getPais());
            service.guardarDatos(evento);
        } catch (Exception ex) {
            log.error("Error al guardar evento de reciclaje {} ", ex.getMessage());
        }
    }
}
