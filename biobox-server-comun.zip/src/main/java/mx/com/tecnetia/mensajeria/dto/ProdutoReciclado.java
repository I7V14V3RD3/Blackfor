package mx.com.tecnetia.mensajeria.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProdutoReciclado {
    private Long idProductoReciclado;
    private Timestamp momentoReciclaje;
    private Integer idProductoReciclable;
    private Integer idArqUsuario;
    private Boolean exitoso;
    private ProductoReciclable productoReciclableByIdProductoReciclable;
    private Usuario arqUsuarioByIdArqUsuario;
    private List<UsuarioPuntosColorAcumulados> usuarioPuntosColorAcumulados;
}
