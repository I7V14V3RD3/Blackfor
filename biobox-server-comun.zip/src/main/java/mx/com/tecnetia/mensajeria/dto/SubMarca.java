package mx.com.tecnetia.mensajeria.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubMarca {

    private Integer idSubMarca;
    private String nombre;
    private Integer idMarca;
    private Marca marcaByIdMarca;
}
