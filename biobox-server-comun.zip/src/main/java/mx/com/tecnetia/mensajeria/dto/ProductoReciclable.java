package mx.com.tecnetia.mensajeria.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductoReciclable {
    private Integer idProductoReciclable;
    private String sku;
    private String barCode;
    private Integer idMaterial;
    private Integer idSubMarca;
    private Integer idFabricante;
    private Integer idCapacidad;
    private Material materialByIdMaterial;
    private SubMarca subMarcaByIdSubMarca;
    private Capacidad capacidadByIdCapacidad;
    private Double pesoMinimo;
    private Double pesoMaximo;
    private Fabricante fabricante;
}
