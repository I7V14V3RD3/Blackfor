package mx.com.tecnetia.mensajeria.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import mx.com.tecnetia.dto.UsuarioPuntosColorDTO;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class ActualizaPuntosEvento {

    private UsuarioPuntosColorDTO usuarioPuntosColorEntities;
}
