package mx.com.tecnetia.util;

import mx.com.tecnetia.enums.TipoDescuentoEnum;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

public class DescuentosUtil {

    public static String formatoValor(Long idTipoDescuento, BigDecimal valorN, BigDecimal valorX) {
        NumberFormat formatoValorDescuento = null;
        String descuento = "";

        if (Objects.equals(idTipoDescuento, TipoDescuentoEnum.PORCENTAJE.getTipoDescuento())) {
            formatoValorDescuento = NumberFormat.getPercentInstance();
            descuento = formatoValorDescuento.format(valorN.divide(new BigDecimal(100)));
        } else if(Objects.equals(idTipoDescuento, TipoDescuentoEnum.MONTO.getTipoDescuento())) {
            formatoValorDescuento = NumberFormat.getCurrencyInstance(new Locale("es","MX"));
            descuento = formatoValorDescuento.format(valorN);
        } else if(Objects.equals(idTipoDescuento, TipoDescuentoEnum.PRODUCTO_GRATIS.getTipoDescuento())){
            descuento = valorN.toString();
        } else if(Objects.equals(idTipoDescuento, TipoDescuentoEnum.N_POR_X_PRECIO.getTipoDescuento())) {
            descuento = valorN.toString() + "x" + valorX.toString();
        } else {
            formatoValorDescuento = NumberFormat.getNumberInstance();
            descuento = formatoValorDescuento.format(valorN);
        }
        return descuento;
    }
}
