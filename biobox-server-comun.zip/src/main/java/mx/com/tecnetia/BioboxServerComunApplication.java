package mx.com.tecnetia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class BioboxServerComunApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(BioboxServerComunApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(BioboxServerComunApplication.class);
	}
}
