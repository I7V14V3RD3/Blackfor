package mx.com.tecnetia.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "programa_codigos_descuento", schema = "public", catalog = "BIOBOX")
@Getter
@Setter
public class ProgramaCodigosDescuentoEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_programa_codigos_descuento")
    private Long idProgramaCodigosDescuento;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_programa_puntos_requeridos", referencedColumnName = "id_programa_puntos_requeridos", nullable = false)
    private ProgramaPuntosRequeridosEntity programaPuntosRequeridos;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_programa_tipo_descuento", referencedColumnName = "id_programa_tipo_descuento", nullable = false)
    private ProgramaTipoDescuentoEntity programaTipoDescuento;

    @Basic
    @Column(name = "codigo")
    private String codigo;

    @Basic
    @Column(name = "fecha_utilizado")
    private Timestamp fechaUtilizado;

    @Basic
    @Column(name = "id_arq_usuario")
    private Long idArqUsuario;

    @Basic
    @Column(name = "imagen")
    private String imagen;

    @Basic
    @Column(name = "valor_n", insertable = false, updatable = false)
    private BigDecimal valorN;

    @Basic
    @Column(name = "valor_x", insertable = false, updatable = false)
    private BigDecimal valorX;
}
