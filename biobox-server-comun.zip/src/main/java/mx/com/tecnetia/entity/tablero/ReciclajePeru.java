package mx.com.tecnetia.entity.tablero;

import jakarta.persistence.*;
import lombok.Builder;

import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "reciclaje_peru")
@Builder
public class ReciclajePeru {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_reciclaje_mexico", nullable = false)
    private Long idReciclajeMexico;

    @Column(name = "momento_reciclaje")
    @Temporal(TemporalType.DATE)
    private Date momentoReciclaje;

    @Column(name = "id_arq_usuario")
    private Integer idArqUsuario;

    @Column(name = "nombre_usuario")
    private String nombreUsuario;

    @Column(name = "apellido_paterno_usuario")
    private String apellidoPaternoUsuario;

    @Column(name = "apellido_materno_usuario")
    private String apellidoMaternoUsuario;

    @Column(name = "email_usuario")
    private String emailUsuario;

    @Column(name = "telefono_usuario")
    private String telefonoUsuario;

    @Column(name = "fecha_registro_usuario")
    @Temporal(TemporalType.DATE)
    private Date fechaRegistroUsuario;

    @Column(name = "id_producto_reciclabe")
    private Integer idProductoReciclabe;

    @Column(name = "sku_producto_reciclable")
    private String skuProductoReciclable;

    @Column(name = "barcode_producto_reciclable")
    private String barcodeProductoReciclable;

    @Column(name = "id_material")
    private Integer idMaterial;

    @Column(name = "material")
    private String material;

    @Column(name = "id_sub_marca")
    private Integer idSubMarca;

    @Column(name = "sub_marca")
    private String subMarca;

    @Column(name = "id_marca")
    private Integer idMarca;

    @Column(name = "marca")
    private String marca;

    @Column(name = "id_capacidad")
    private Integer idCapacidad;

    @Column(name = "capacidad")
    private Double capacidad;

    @Column(name = "id_unidade_de_medida")
    private Integer idUnidadeDeMedida;

    @Column(name = "unidade_de_medida")
    private String unidadeDeMedida;

    @Column(name = "unidade_de_medida_sigla")
    private String unidadeDeMedidaSigla;

    @Column(name = "peso_minimo")
    private Double pesoMinimo;

    @Column(name = "peso_maximo")
    private Double pesoMaximo;

    @Column(name = "id_fabricante")
    private Integer idFabricante;

    @Column(name = "fabricante")
    private String fabricante;

    @Column(name = "total_puntos_color_accumulado")
    private Integer totalPuntosColorAcumulado;

    @Column(name = "direccion_quiosco")
    private String direccionQuiosco;

    @Column(name = "latitud_quiosco")
    private String latitudQuiosco;

    @Column(name = "longitud_quiosco")
    private String longitudQuiosco;

    @Column(name = "ip_quiosco")
    private String ipQuiosco;

    @Column(name = "qr_quiosco")
    private UUID qrQuiosco;

    @Column(name = "altura_llenado_mm")
    private Integer alturaLlenadoMm;

    @Column(name = "quisco_arduino")
    private Boolean quiscoArduino;

    @Column(name = "quisco_nombre")
    private String quiscoNombre;

    @Column(name = "reciclaje_exitosa")
    private Boolean reciclajeExitosa;

    // Getters and Setters

    public Long getIdReciclajeMexico() {
        return idReciclajeMexico;
    }

    public void setIdReciclajeMexico(Long idReciclajeMexico) {
        this.idReciclajeMexico = idReciclajeMexico;
    }

    public Date getMomentoReciclaje() {
        return momentoReciclaje;
    }

    public void setMomentoReciclaje(Date momentoReciclaje) {
        this.momentoReciclaje = momentoReciclaje;
    }

    public Integer getIdArqUsuario() {
        return idArqUsuario;
    }

    public void setIdArqUsuario(Integer idArqUsuario) {
        this.idArqUsuario = idArqUsuario;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoPaternoUsuario() {
        return apellidoPaternoUsuario;
    }

    public void setApellidoPaternoUsuario(String apellidoPaternoUsuario) {
        this.apellidoPaternoUsuario = apellidoPaternoUsuario;
    }

    public String getApellidoMaternoUsuario() {
        return apellidoMaternoUsuario;
    }

    public void setApellidoMaternoUsuario(String apellidoMaternoUsuario) {
        this.apellidoMaternoUsuario = apellidoMaternoUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }

    public String getTelefonoUsuario() {
        return telefonoUsuario;
    }

    public void setTelefonoUsuario(String telefonoUsuario) {
        this.telefonoUsuario = telefonoUsuario;
    }

    public Date getFechaRegistroUsuario() {
        return fechaRegistroUsuario;
    }

    public void setFechaRegistroUsuario(Date fechaRegistroUsuario) {
        this.fechaRegistroUsuario = fechaRegistroUsuario;
    }

    public Integer getIdProductoReciclabe() {
        return idProductoReciclabe;
    }

    public void setIdProductoReciclabe(Integer idProductoReciclabe) {
        this.idProductoReciclabe = idProductoReciclabe;
    }

    public String getSkuProductoReciclable() {
        return skuProductoReciclable;
    }

    public void setSkuProductoReciclable(String skuProductoReciclable) {
        this.skuProductoReciclable = skuProductoReciclable;
    }

    public String getBarcodeProductoReciclable() {
        return barcodeProductoReciclable;
    }

    public void setBarcodeProductoReciclable(String barcodeProductoReciclable) {
        this.barcodeProductoReciclable = barcodeProductoReciclable;
    }

    public Integer getIdMaterial() {
        return idMaterial;
    }

    public void setIdMaterial(Integer idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public Integer getIdSubMarca() {
        return idSubMarca;
    }

    public void setIdSubMarca(Integer idSubMarca) {
        this.idSubMarca = idSubMarca;
    }

    public String getSubMarca() {
        return subMarca;
    }

    public void setSubMarca(String subMarca) {
        this.subMarca = subMarca;
    }

    public Integer getIdMarca() {
        return idMarca;
    }

    public void setIdMarca(Integer idMarca) {
        this.idMarca = idMarca;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Integer getIdCapacidad() {
        return idCapacidad;
    }

    public void setIdCapacidad(Integer idCapacidad) {
        this.idCapacidad = idCapacidad;
    }

    public Double getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Double capacidad) {
        this.capacidad = capacidad;
    }

    public Integer getIdUnidadeDeMedida() {
        return idUnidadeDeMedida;
    }

    public void setIdUnidadeDeMedida(Integer idUnidadeDeMedida) {
        this.idUnidadeDeMedida = idUnidadeDeMedida;
    }

    public String getUnidadeDeMedida() {
        return unidadeDeMedida;
    }

    public void setUnidadeDeMedida(String unidadeDeMedida) {
        this.unidadeDeMedida = unidadeDeMedida;
    }

    public String getUnidadeDeMedidaSigla() {
        return unidadeDeMedidaSigla;
    }

    public void setUnidadeDeMedidaSigla(String unidadeDeMedidaSigla) {
        this.unidadeDeMedidaSigla = unidadeDeMedidaSigla;
    }

    public Double getPesoMinimo() {
        return pesoMinimo;
    }

    public void setPesoMinimo(Double pesoMinimo) {
        this.pesoMinimo = pesoMinimo;
    }

    public Double getPesoMaximo() {
        return pesoMaximo;
    }

    public void setPesoMaximo(Double pesoMaximo) {
        this.pesoMaximo = pesoMaximo;
    }

    public Integer getIdFabricante() {
        return idFabricante;
    }

    public void setIdFabricante(Integer idFabricante) {
        this.idFabricante = idFabricante;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public Integer getTotalPuntosColorAcumulado() {
        return totalPuntosColorAcumulado;
    }

    public void setTotalPuntosColorAcumulado(Integer totalPuntosColorAcumulado) {
        this.totalPuntosColorAcumulado = totalPuntosColorAcumulado;
    }

    public String getDireccionQuiosco() {
        return direccionQuiosco;
    }

    public void setDireccionQuiosco(String direccionQuiosco) {
        this.direccionQuiosco = direccionQuiosco;
    }

    public String getLatitudQuiosco() {
        return latitudQuiosco;
    }

    public void setLatitudQuiosco(String latitudQuiosco) {
        this.latitudQuiosco = latitudQuiosco;
    }

    public String getLongitudQuiosco() {
        return longitudQuiosco;
    }

    public void setLongitudQuiosco(String longitudQuiosco) {
        this.longitudQuiosco = longitudQuiosco;
    }

    public String getIpQuiosco() {
        return ipQuiosco;
    }

    public void setIpQuiosco(String ipQuiosco) {
        this.ipQuiosco = ipQuiosco;
    }

    public UUID getQrQuiosco() {
        return qrQuiosco;
    }

    public void setQrQuiosco(UUID qrQuiosco) {
        this.qrQuiosco = qrQuiosco;
    }

    public Integer getAlturaLlenadoMm() {
        return alturaLlenadoMm;
    }

    public void setAlturaLlenadoMm(Integer alturaLlenadoMm) {
        this.alturaLlenadoMm = alturaLlenadoMm;
    }

    public Boolean getQuioscoArduino() {
        return quiscoArduino;
    }

    public void setQuioscoArduino(Boolean quiscoArduino) {
        this.quiscoArduino = quiscoArduino;
    }

    public String getQuioscoNombre() {
        return quiscoNombre;
    }

    public void setQuioscoNombre(String quiscoNombre) {
        this.quiscoNombre = quiscoNombre;
    }

    public Boolean getReciclajeExitosa() {
        return reciclajeExitosa;
    }

    public void setReciclajeExitosa(Boolean reciclajeExitosa) {
        this.reciclajeExitosa = reciclajeExitosa;
    }
}
