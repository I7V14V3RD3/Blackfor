package mx.com.tecnetia.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "usuario_puntos", schema = "public", catalog = "BIOBOX")
@Getter
@Setter
public class UsuarioPuntosEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_usuario_puntos")
    private Long idUsuarioPuntos;
    @Basic
    @Column(name = "id_arq_usuario", insertable = false, updatable = false)
    private Long idArqUsuario;
    @Basic
    @Column(name = "puntos")
    private Integer puntos;
    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "id_arq_usuario")
    private ArqUsuarioEntity arqUsuarioEntity;
}
