package mx.com.tecnetia.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "arq_pais")
@Getter
@Setter
public class ArqPaisEntity {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_arq_pais", nullable = false)
    private Long idArqPais;

    @Basic
    @Column(name = "nombre", nullable = true, length = 200)
    private String nombre;

    @Basic
    @Column(name = "codigo", nullable = true, length = 50)
    private String codigo;

    @Basic
    @Column(name = "flag", nullable = false)
    private String flag;

    @Basic
    @Column(name = "lada", nullable = false)
    private String lada;

    @Basic
    @Column(name = "activo", nullable = false)
    private Boolean activo;
}
