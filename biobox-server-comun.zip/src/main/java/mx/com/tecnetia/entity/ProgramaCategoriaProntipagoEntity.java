package mx.com.tecnetia.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "categoria_prontipago", schema = "public", catalog = "BIOBOX")
@Getter
@Setter
public class ProgramaCategoriaProntipagoEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id_categoria_prontipago")
    private Long idCategoriaProntipago;
    @Basic
    @Column(name = "nombre")
    private String nombre;
    @Basic
    @Column(name = "descripcion")
    private String descripcion;
    @Basic
    @Column(name = "contacto")
    private String contacto;
    @Basic
    @Column(name = "url")
    private String url;
    @Basic
    @Column(name = "color_fondo")
    private String colorFondo;
    @Basic
    @Column(name = "tipo_programa")
    private String tipoPrograma;
    @Basic
    @Column(name = "url_logo")
    private String urlLogo;
    @Basic
    @Column(name = "url_logo_2")
    private String urlLogo2;
    @Basic
    @Column(name = "url_portal")
    private String urlPortal;
    @Basic
    @Column(name = "canje_unico")
    private boolean canjeUnico;
    @Basic
    @Column(name = "vigencia_inicio")
    private Timestamp vigenciaInicio;
    @Basic
    @Column(name = "vigencia_fin")
    private Timestamp vigenciaFin;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "categoriaProntipago")
    private List<ProgramaProntipagoEntity> programasProntipagos;
}
