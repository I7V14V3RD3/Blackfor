package mx.com.tecnetia.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Data
@NoArgsConstructor
@Schema(description = "DTO de reciclajes fallidos por dia.")
public class DiaReciclajeBloqueadoDTO {
    private Date fecha;
    private Integer reciclajesFallidos;

    public DiaReciclajeBloqueadoDTO(Date fecha, Integer reciclajesFallidos) {
        this.fecha = fecha;
        this.reciclajesFallidos = reciclajesFallidos;
    }
}
