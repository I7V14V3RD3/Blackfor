package mx.com.tecnetia.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO usuario puntos color.")
public class ProductoReciclableDTO {
    private Long idProductoReciclableColorPuntos;
    private Integer idColor;
    private Long idProductoReciclable;
    private Integer puntos;
    private Timestamp fechaInicio;
    private Date fechaFin;
}
