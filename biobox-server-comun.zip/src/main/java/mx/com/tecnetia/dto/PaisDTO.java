package mx.com.tecnetia.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO lada.")
public class PaisDTO {
    private Long id;
    private String nombre;
    private String flag;
    private String codigo;
    private String lada;
    private Boolean activo;
}
