package mx.com.tecnetia.orthogonal.utils.plc;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;


@Service
@RequiredArgsConstructor
@Log4j2
public class PlcSocketClientService {

    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    public void startConnection(String ip, int port) {
        try {
            clientSocket = new Socket(ip, port);
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (IOException e) {
            log.error(e);
            throw new RuntimeException(e);
        }
    }

    public String sendMessage(String msg) {
        out.println(msg);
        String resp = null;
        try {
            resp = in.readLine();
        } catch (IOException e) {
            log.error(e);
            //throw new RuntimeException(e);
        }
        return resp;
    }

    public void stopConnection() {
        try {
            in.close();
        } catch (IOException e) {
            log.error(e);
        }
        try {
            out.close();
        }catch (Exception e){
            log.error(e);
        }
        try {
            clientSocket.close();
        } catch (IOException e) {
            log.error(e);
        }
    }

}
