package mx.com.tecnetia.orthogonal.services;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Log4j2
public class NotificacionesServiceImpl implements NotificacionesService {
    //private final TokenCelEntityRepository tokenCelEntityRepository;

    /*@Override
    @Transactional
    public void guardarToken(Long idUsuario, String token) {
            Optional<TokenCelEntity> tokenCelOpt = this.tokenCelEntityRepository.findById(idUsuario);
            TokenCelEntity tokenEntity;
            if(tokenCelOpt.isPresent()){
                tokenEntity = tokenCelOpt.get();
            }else {
                tokenEntity = new TokenCelEntity();
                tokenEntity.setIdArqUsuario(idUsuario);
            }
            tokenEntity.setToken(token);
            tokenEntity.setAlta(Timestamp.valueOf(LocalDateTime.now()));
            this.tokenCelEntityRepository.save(tokenEntity);
    }*/

}
