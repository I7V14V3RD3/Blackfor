package mx.com.tecnetia.marcoproyectoseguridad;

import com.fazecast.jSerialComm.SerialPort;

public class ArduinoParalelo {
    public static void main(String[] args) {
        SerialPort serialPort = null;
        SerialPort[] puertosDisponibles = SerialPort.getCommPorts();
        //SerialPort serialPort = null;
        // use the for loop to print the available serial ports
        for (SerialPort serialPortTmp : puertosDisponibles) {
            if (serialPortTmp.toString().indexOf("Arduino") > -1) {
                /* Puerto Serial encontrado*/
                serialPortTmp.openPort();
                serialPort = serialPortTmp;
            }
        }


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        SerialPort finalSerialPort = serialPort;

        byte[] writeByte = new byte[1];
        writeByte[0] = (byte) 108; //Código ASCII
        int bytesTxed = 0;

        bytesTxed = serialPort.writeBytes(writeByte, 1);


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


    }
}
