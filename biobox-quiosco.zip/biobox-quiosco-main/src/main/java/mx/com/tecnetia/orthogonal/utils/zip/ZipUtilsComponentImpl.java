package mx.com.tecnetia.orthogonal.utils.zip;


import com.opencsv.ICSVWriter;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.dto.csv.CsvBean;
import mx.com.tecnetia.orthogonal.utils.csv.CsvHelpers;
import mx.com.tecnetia.orthogonal.utils.csv.CsvTransferGeneric;
import mx.com.tecnetia.orthogonal.utils.csv.CsvUtilsComponent;
import org.springframework.stereotype.Component;
//import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Component
@Log4j2
public class ZipUtilsComponentImpl implements ZipUtilsComponent {

    @Override
    //@Transactional(readOnly = true)
    public void descomprimirArchivo(String ficheroZip, String directorioSalida) {
        final int TAM_BUFFER = 4096;
        byte[] buffer = new byte[TAM_BUFFER];

        ZipInputStream flujo = null;
        try {
            flujo = new ZipInputStream(new BufferedInputStream(
                    new FileInputStream(ficheroZip)));
            ZipEntry entrada;
            while ((entrada = flujo.getNextEntry()) != null) {
                String nombreSalida = directorioSalida + File.separator
                        + entrada.getName();
                if (entrada.isDirectory()) {
                    File directorio = new File(nombreSalida);
                    directorio.mkdir();
                } else {
                    BufferedOutputStream salida = null;
                    try {
                        int leido;
                        salida = new BufferedOutputStream(
                                new FileOutputStream(nombreSalida), TAM_BUFFER);
                        while ((leido = flujo.read(buffer, 0, TAM_BUFFER)) != -1) {
                            salida.write(buffer, 0, leido);
                        }
                    } finally {
                        if (salida != null) {
                            salida.close();
                        }
                    }
                }
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException("No se puede descomprimir el archivo.");
        } finally {
            if (flujo != null) {
                try {
                    flujo.close();
                }catch (IOException ex){
                }
            }

        }
    }
}
