package mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO de un producto a reciclar en un quiosco específico.")
public class ReciclarEnQuioscoDTO {
    @NotNull
    private Long idProducto;
    @NotNull
    private Long idQuiosco;
    @NotNull
    private Long idUsuario;
    private boolean moverCharolaALaDerecha;
    @NotNull
    private int tipoPic;
    @NotBlank(message = "Falta el bar code")
    private String barCode;
}
