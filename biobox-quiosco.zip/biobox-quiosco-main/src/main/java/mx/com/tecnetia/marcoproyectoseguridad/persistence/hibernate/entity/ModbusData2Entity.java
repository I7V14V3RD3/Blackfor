package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity;

//import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

//@Entity
//@Table(name = "modbus_data_2", schema = "public", catalog = "maquina_biobox")
@Getter
@Setter
public class ModbusData2Entity {
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    //@Id
    //@Column(name = "REC_ID")
    private Integer recId;
    //@Basic
    //@Column(name = "TIMESTAMP")
    private Timestamp timestamp;
    //@Basic
    //@Column(name = "ITEM1")
    private String item1;
    //@Basic
    //@Column(name = "ITEM2")
    private String item2;
 }
