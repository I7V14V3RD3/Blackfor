package mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO del inicio del reciclaje para abrir quiosco.")
public class AbrirQuioscoDTO implements Serializable {
    private int tipoPic;
    private Long quioscoId;
    private Long usuarioId;
}
