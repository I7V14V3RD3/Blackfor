package mx.com.tecnetia.marcoproyectoseguridad;

public class Ejecutor {

    public static void main(String[] args) {
        ArduinoTest tt = new ArduinoTest();
        tt.metodo1();
        tt.metodo2();
    }
}
