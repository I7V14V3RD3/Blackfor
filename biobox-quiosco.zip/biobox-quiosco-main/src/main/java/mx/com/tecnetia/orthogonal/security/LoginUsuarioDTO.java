package mx.com.tecnetia.orthogonal.security;

import jakarta.validation.constraints.NotBlank;

import lombok.Data;

import java.io.Serializable;

@Data
public class LoginUsuarioDTO implements Serializable {
    private String nick;
    private String passw;

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getPassw() {
        return passw;
    }

    public void setPassw(String passw) {
        this.passw = passw;
    }
}
