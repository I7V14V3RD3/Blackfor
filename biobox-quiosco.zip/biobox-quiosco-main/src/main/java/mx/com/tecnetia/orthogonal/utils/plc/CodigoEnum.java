package mx.com.tecnetia.orthogonal.utils.plc;

public enum CodigoEnum {
    /*   DOCUMENTACIÓN DEL ARDUINO DESDE IDE (CODIGO FUENTE ORIGINAL)
            case 1: Serial.println("Gira Derecha Motor 1. Abre puerta.");
            case 2: Serial.println("Gira Izquierda Motor 1. Cierra puerta.");
            case 3: Serial.println("Gira Derecha Motor 2. Gira charola.");
            case 4: Serial.println("Gira Izquierda Motor 2. Gira charola.");
            case 5: Serial.println("Prende led Rojo");
            case 6: Serial.println("Prende led Verde");
            case 7: Serial.print("Prende led Azul");
            case 8: Serial.println("Apagar led");
            case 9: Serial.println("Midiendo llenado de contenedor");
            case 10: Serial.println("Reiniciar y probar sensores");
            case 11: Serial.println("Detecta obstaculo");
            case 10: Serial.println("Prende led blanco para foto (flash)");

            SE DEBEN CONVERITIR A CODIGOS ASCII
        */

    MEDIR_NIVEL_DEPOSITO(new String[]{"3A","30","32","30","36","31","31","30","30","30","30","30","31","45","36","0D","0A"}),
    CICLO_RECICLAJE_COMPLETO(new String[]{"3A","30","32","30","36","31","31","30","30","30","30","30","31","45","36","0D","0A"}),
    MEDIR_PESO(new String[]{"3A","30","32","30","33","31","31","30","34","30","30","30","31","45","35","0D","0A"});

    private String[] codigo;

    CodigoEnum(String[] codigo){
        this.codigo = codigo;
    }
    public String[] getCodigo() {
        return codigo;
    }

    public void setCodigo(String[] codigo) {
        this.codigo = codigo;
    }

}
