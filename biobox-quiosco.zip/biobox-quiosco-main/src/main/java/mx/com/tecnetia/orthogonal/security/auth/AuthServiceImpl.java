package mx.com.tecnetia.orthogonal.security.auth;

import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.security.JwtDTO;
import mx.com.tecnetia.orthogonal.security.LoginUsuarioDTO;
import mx.com.tecnetia.orthogonal.dto.NuevoUsuarioArquitecturaDTO;
import org.springframework.core.env.Environment;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import mx.com.tecnetia.orthogonal.security.jwt.JwtProvider;

import java.util.Iterator;

@Service
@RequiredArgsConstructor
@Log4j2
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    //private final ArqUsuarioRepository usuarioEntityRepository;
    private final JwtProvider jwtProvider;
    //private final UsuarioPuntosColorEntityRepository usuarioPuntosColorEntityRepository;
    //private final ArqPropiedadEntityRepository arqPropiedadEntityRepository;
    private final Environment environment;

    @Override
    //@Transactional
    public void crearNuevoUsuario(NuevoUsuarioArquitecturaDTO nuevoUsuario) {

    }

    @Override
   // @Transactional(readOnly = true)
    public JwtDTO login(LoginUsuarioDTO loginUsuario) {
        String saleAgent = environment.getProperty("stc.contract.data.sale.agent");
        String serialNumber = environment.getProperty("stc.contract.serial.number");
        String saleDate = environment.getProperty("stc.contract.sale.date");
        String linkAyuda = environment.getProperty("link.ayuda");
        String linkMasInfo = environment.getProperty("link.mas.info");
        String linkAvisoPrivacidad = environment.getProperty("link.aviso.privacidad");

        /*var arqUsuarioEntity = this.usuarioEntityRepository.findByNick(loginUsuario.getNick().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("El correo electrónico no existe"));
        if (Boolean.TRUE.equals(arqUsuarioEntity.getActivo()) && Boolean.TRUE.equals(!arqUsuarioEntity.getPendienteConfirmacion())) {
            Authentication authentication;
            try {
                authentication = authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(loginUsuario.getNick(), loginUsuario.getPassw()));
            } catch (AuthenticationException ex) {
                throw new IllegalArgumentException("El usuario o la contraseña proporcionados no son válidos.");
            }

            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = jwtProvider.generateToken(authentication);
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            String rol = "";
            if(!arqUsuarioEntity.getArqUsuarioRolesByIdArqUsuario().isEmpty()) {
                Iterator<ArqUsuarioRolEntity> rolEntityIt = arqUsuarioEntity.getArqUsuarioRolesByIdArqUsuario().iterator();
                rol = rolEntityIt.hasNext() ? rolEntityIt.next().getArqRolByIdArqRol().getNombre() : "";
            }

            return new JwtDTO(jwt, userDetails.getUsername(), arqUsuarioEntity.getNombres(), arqUsuarioEntity.getApellidoPaterno(),
                    arqUsuarioEntity.getApellidoMaterno(), arqUsuarioEntity.getEmail(), rol , arqUsuarioEntity.getTelefono(),
                    arqUsuarioEntity.getFotoUsuarioEntity().getFoto(),
                    null);
        }*/
        throw new IllegalArgumentException("El usuario especificado no puede iniciar sesión. Antes debe confirmar su email.");
    }

}
