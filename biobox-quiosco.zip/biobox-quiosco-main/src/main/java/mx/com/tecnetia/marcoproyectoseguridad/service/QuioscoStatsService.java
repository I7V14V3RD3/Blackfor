package mx.com.tecnetia.marcoproyectoseguridad.service;


import mx.com.tecnetia.marcoproyectoseguridad.dto.quioscostats.QuioscoOnDTO;

public interface QuioscoStatsService {
    QuioscoOnDTO getDataOn();
}
