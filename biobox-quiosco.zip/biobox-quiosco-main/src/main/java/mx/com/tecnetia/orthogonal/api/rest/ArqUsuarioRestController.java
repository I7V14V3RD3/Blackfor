package mx.com.tecnetia.orthogonal.api.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import mx.com.tecnetia.orthogonal.security.JwtDTO;
import mx.com.tecnetia.orthogonal.security.LoginUsuarioDTO;
import mx.com.tecnetia.orthogonal.security.NuevoUsuarioArquitecturaDTO;
import mx.com.tecnetia.orthogonal.security.UsuarioPrincipal;
import mx.com.tecnetia.orthogonal.security.auth.AuthService;
import mx.com.tecnetia.orthogonal.security.auth.AuthenticationFacadeComponent;
import mx.com.tecnetia.orthogonal.services.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.HexFormat;

import static java.time.format.DateTimeFormatter.BASIC_ISO_DATE;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/arq")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Gestión de Usuarios de arquitectura.", description = "Operaciones básicas con los usuarios. Servicios ortogonales.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.", content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class ArqUsuarioRestController {

    private final AuthService authService;
    private final AuthenticationFacadeComponent authenticationFacadeComponent;
    private final UsuarioService usuarioService;
    private final SpringTemplateEngine thymeleafTemplateEngine;

    @Operation(summary = "Login de la aplicación. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = JwtDTO.class)))})
    @PostMapping("/free/login")
    public ResponseEntity<JwtDTO> login(@Valid @RequestBody LoginUsuarioDTO loginUsuario) {
        log.info("Login. Usuario entrando: {}", loginUsuario.getNick());
        JwtDTO jwtDTO = authService.login(loginUsuario);
        return new ResponseEntity<>(jwtDTO, HttpStatus.OK);
    }

    /*@Operation(summary = "Nuevo usuario de la aplicación. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = Long.class)))})
    @PostMapping("/free/usuario")
    public ResponseEntity<Long> crearUsuario(@Valid @RequestBody NuevoUsuarioArquitecturaDTO user, @RequestPart(name = "file") MultipartFile file) {
        try {

            var ret = this.usuarioService.guardar(user, file.getBytes(), file.getOriginalFilename());
            return new ResponseEntity<>(ret.getIdArqUsuario(), HttpStatus.OK);
        } catch (IOException ex) {
            throw new IllegalArgumentException("No se puede leer el archivo TXT.");
        }
    }*/

    /*@Operation(summary = "Nuevo usuario de la aplicación. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = Long.class)))})
    @PostMapping("/free/usuario")
    public ResponseEntity<Long> crearUsuario(@Valid @RequestBody NuevoUsuarioArquitecturaDTO user) {
        byte[] foto = HexFormat.of().parseHex("e04fd020ea3a6910a2d808002b30309d");
        //var ret = this.usuarioService.guardar(user, foto, "Prueba");
       // return new ResponseEntity<>(ret.getIdArqUsuario(), HttpStatus.OK);
    }

    @PreAuthorize("isAuthenticated()")
    @Operation(summary = "Cambiar passw. LISTO.", description = "CUALQUIER ROL. Cambia el passw del usuario logeado",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = void.class)))})
    @PatchMapping(value = "/user-passw")
    public void cambiaPassw(@RequestParam("passw") @NotEmpty @Parameter(description = "Nuevo passw.") String passw) {
        var usuarioLogeado = (UsuarioPrincipal) authenticationFacadeComponent.getAuthentication().getPrincipal();
        log.info("Email del usuario Logeado: {}", usuarioLogeado.getEmail());
        this.usuarioService.cambiaPassw(usuarioLogeado, passw);
    }

    @Operation(summary = "Recuperar passw. LISTO.", description = "CUALQUIER ROL. Recupera el password de cualquier usuario registrado. Lo manda por correo.",
            security = {@SecurityRequirement(name = "security_auth")})
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = void.class)))})
    @PatchMapping(value = "/user-passw-retrieve")
    public void recuperaPassw(@RequestParam("usr") @NotEmpty @Parameter(description = "Usuario a recuperar.") String user) {
        log.info("Email del usuario a recuperar: {}", user);
        this.usuarioService.recuperaPassw(user);
    }

    @Operation(summary = "Prueba de retorno de plantilla Thymeleaf. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema = @Schema(implementation = String.class)))})
    @GetMapping("/free/test")
    public ResponseEntity<String> test() {
        LocalDate esteMomento = LocalDate.now();
        log.info("Fecha antes: {}", esteMomento.toString());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYYMMdd");
        String formattedString = esteMomento.format(BASIC_ISO_DATE);
        log.info("Fecha: {}", formattedString);
        log.info("Cambiado: {}", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        log.info("Cambiado: {}", LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/YYYY")));//Este está mal

        var model = new HashMap<String, Object>();
        model.put("name", "Hola Pablito");
        var thymeleafContext = new Context();
        thymeleafContext.setVariables(model);
        var templateThymeleafFile = "confirmacion-email-thymeleaf.html";
        String htmlBody = thymeleafTemplateEngine.process(templateThymeleafFile, thymeleafContext);

        log.info("Test. Fin");
        return new ResponseEntity<>(htmlBody, HttpStatus.OK);
    }*/
}
