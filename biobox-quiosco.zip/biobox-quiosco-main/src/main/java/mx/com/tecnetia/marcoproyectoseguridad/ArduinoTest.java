package mx.com.tecnetia.marcoproyectoseguridad;

import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;

public class ArduinoTest {
    SerialPort serialPort = null;
    public void metodo1(){

        SerialPort[] puertosDisponibles = SerialPort.getCommPorts();
        //SerialPort serialPort = null;
        // use the for loop to print the available serial ports
        for (SerialPort serialPortTmp : puertosDisponibles) {
            if (serialPortTmp.toString().indexOf("Arduino") > -1) {
                /* Puerto Serial encontrado*/
                serialPortTmp.openPort();
                serialPort = serialPortTmp;
            }
        }

        SerialPort finalSerialPort = serialPort;
        serialPort.addDataListener(new SerialPortDataListener() {
            @Override
            public int getListeningEvents() {
                return SerialPort.LISTENING_EVENT_DATA_AVAILABLE;
            }
            @Override
            public void serialEvent(SerialPortEvent event) {
                if (event.getEventType() != SerialPort.LISTENING_EVENT_DATA_AVAILABLE)
                    return;
                byte[] newData = new byte[finalSerialPort.bytesAvailable()];
                int numRead = finalSerialPort.readBytes(newData, newData.length);
                //System.out.println("Llegó "+ new String(newData));
                System.out.println(new String(newData));
            }
        });

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public void metodo2(){
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        SerialPort finalSerialPort = serialPort;

        byte[] writeByte = new byte[2];
        writeByte[0] = (byte) 49; //Código ASCII
        writeByte[1] = (byte) 50; //Código ASCII
        int bytesTxed = 0;

        bytesTxed = serialPort.writeBytes(writeByte, 2  );


        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

}
