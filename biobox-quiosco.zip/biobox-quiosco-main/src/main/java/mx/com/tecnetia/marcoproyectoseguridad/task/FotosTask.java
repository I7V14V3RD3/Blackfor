package mx.com.tecnetia.marcoproyectoseguridad.task;

import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.utils.ftp.FtpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.FileSystemUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

@Component
@Log4j2
public class FotosTask {

    @Autowired
    private FtpService ftpService;

    @Value("${dir.fotos}")
    private String directorioFotos;

    @Value("${ftp.dir}")
    private String ftpDir;


    @Scheduled(cron = "0 30 1 * * *", zone = "GMT-6")
    public void enviarFotos() {
        DateTimeFormatter formater = DateTimeFormatter.ofPattern("ddMMyyyy");
        LocalDate fecha = LocalDate.now(ZoneId.of("GMT-6")).minusDays(1); // carpetas del dia anterior
        AtomicBoolean hasError = new AtomicBoolean(false);
        Path path = Paths.get(directorioFotos + "/" + fecha.format(formater));
        if (!Files.exists(path)) {
            log.warn("No se pudieron enviar los archivos. Carpeta {} no existe.", path.getFileName());
            return;
        }
        // Envia fotos del dia anterior
        try (Stream<Path> stream = Files.list(path)) {
            log.info("Enviando fotos");
            stream.forEach( file -> {
                try {
                    String quioscoId = file.getFileName().toString().split("-")[0];
                    boolean isUploadSuccess = this.ftpService.uploadFile(file.toFile(), ftpDir + "/quiosco_" + quioscoId + "/" + file.getFileName());
                    if (!isUploadSuccess) {
                        hasError.set(true);
                    }
                } catch (Exception e) {
                    log.error("Error al enviar archivos: {}", e.getMessage());
                    throw new RuntimeException(e);
                }
            });
            if (!hasError.get()) {
                log.info("Borrando carpeta: {}", path.getFileName());
                FileSystemUtils.deleteRecursively(path);
                log.info("Se borro las carpetas de forma exitosa");
            }
        } catch (IOException e) {
            log.error("Error al enviar fotos: {}", e.getMessage());
        }
    }
}
