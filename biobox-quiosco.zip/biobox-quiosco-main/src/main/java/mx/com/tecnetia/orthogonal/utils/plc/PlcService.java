package mx.com.tecnetia.orthogonal.utils.plc;

import com.fazecast.jSerialComm.SerialPort;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.NotificaTerminoReciclajeDTO;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.ModbusData2Entity;
import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository.ModbusData2EntityRepository;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;

@Service
@RequiredArgsConstructor
@Log4j2
public class PlcService {
    private SerialPort serialPort;
    private String lastValue;
    private int estatusMaquina;
    private final PlcSocketClientService client;
    private final Environment environment;

    //private final ModbusData2EntityRepository modbusData2EntityRepository;

    /*@PostConstruct
    void onInit(){
        this.client.startConnection("localhost", 8081);
    }*/

    public void abrirConexion() {
        boolean intentarConexion = this.serialPort == null ? true : (this.serialPort.isOpen() ? false : true);
        if(intentarConexion) {
            SerialPort[] puertosDisponibles = SerialPort.getCommPorts();
            // use the for loop to print the available serial ports
            for (SerialPort serialPortTmp : puertosDisponibles) {
                if (serialPortTmp.toString().indexOf("CP2102") > -1) {
                    /* Puerto Serial encontrado*/
                        serialPortTmp.openPort();
                        this.serialPort = serialPortTmp;
                }
            }

            this.serialPort.setBaudRate(9600);
            this.serialPort.setNumDataBits(7);
            this.serialPort.setNumStopBits(1);
            this.serialPort.setParity(SerialPort.EVEN_PARITY);
            this.serialPort.setComPortTimeouts(SerialPort.TIMEOUT_NONBLOCKING,1,2);

            SerialPort finalSerialPort = this.serialPort;
        }
    }

    public void cerrarConexion() {
        try {
            if (this.serialPort.isOpen()) //Check whether port open/not
                this.serialPort.closePort(); //Close the port
        } catch (Exception e) {

        }
    }

    public void enviarMensaje(String[] mensaje, int sleepMsAfter) {

        byte[] writeByte = new byte[17];

        int i=0;
        for(String msgStr : mensaje){
            writeByte[i] = (byte)Integer.parseInt(msgStr,16);
            i++;
        }

        int bytesTxed = 0;

        bytesTxed = this.serialPort.writeBytes(writeByte, writeByte.length);
        try {
            Thread.sleep(sleepMsAfter);
        } catch (InterruptedException e) {

        }
    }

    public String getUltimoLog() {

        String ultimoLog =new String();

        /*ModbusData2Entity modbusData2Entity = this.modbusData2EntityRepository.findFirstByOrderByRecIdDesc();

        if(modbusData2Entity!=null){
            ultimoLog = modbusData2Entity.getItem1();
        }*/

        return ultimoLog;
    }

    public Integer getUltimoPeso(){

        String response = this.client.sendMessage("A");
        Integer peso = 0;
        try{
            peso = Integer.parseInt(response);
        }catch(Exception e){
            log.error(e);
            peso = 0;
        }

        return peso;
    }

    public Integer getPesoProducto(){

      Integer peso = 0;

        String urlEndpoint = environment.getProperty("plc.url.service.obtener.peso");
        var restTemplate = new RestTemplate();
        var headers = new HttpHeaders();
        //headers.setContentType(MediaType.APPLICATION_JSON);
        //headers.set("Authorization", "Bearer "+token);

        //var notificaTerminoReciclajeDTO = new NotificaTerminoReciclajeDTO();
        //notificaTerminoReciclajeDTO.setIdUsuario(idUsuario);
        //var requestEntity = new HttpEntity<>(notificaTerminoReciclajeDTO, headers);
        log.info("Se llamará a obtener el peso");
        String pesoStr = restTemplate.getForObject(urlEndpoint, String.class);
        log.info("Se obtuvo el peso: "+pesoStr);
        peso = Integer.parseInt(pesoStr);
        log.info("Se obtuvo el peso Int: "+peso);

        return peso;
    }

    public void abrirQuiosco() {
        String urlEndpoint = environment.getProperty("plc.url.service.quiosco.abrir");
        var restTemplate = new RestTemplate();
        log.info("Se llamará abrir quiosco PLC");
        restTemplate.getForObject(urlEndpoint, String.class);
        log.info("Se finalizo abrir quiosco PLC: ");
    }

    public Integer cerrarQuiosco() {
        String urlEndpoint = environment.getProperty("plc.url.service.quiosco.cerrar");
        var restTemplate = new RestTemplate();
        log.info("Se llamará cerrar quiosco PLC");
        var respuesta = restTemplate.getForObject(urlEndpoint, String.class);
        log.info("Se finalizo cerrar quiosco PLC: ");
        return Integer.parseInt(respuesta);
    }

    public byte[] leerMensaje(String[] mensaje, int sleepMsAfter) {

        byte[] readByte = new byte[17];
        byte[] writeByte = new byte[17];

        int i=0;
        for(String msgStr : mensaje){
            writeByte[i] = (byte)Integer.parseInt(msgStr,16);
            i++;
        }

        int bytesTxed = 0;

        bytesTxed = this.serialPort.writeBytes(writeByte, writeByte.length);
        try {
            Thread.sleep(sleepMsAfter);
        } catch (InterruptedException e) {

        }

        int bytesReaded = 0;

        bytesReaded = this.serialPort.readBytes(readByte, readByte.length);
        try {
            Thread.sleep(sleepMsAfter);
        } catch (InterruptedException e) {

        }

        log.info("Bytes leídos PLC ("+bytesReaded+")");
        for(byte b : readByte ){
            log.info(b+",");
        }

        try {
            log.info(new String(readByte, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            log.error("No se pudo convertir el byte a String: "+e.getMessage());
        }

        return readByte;
    }

    public SerialPort getSerialPort() {
        return this.serialPort;
    }

    public void setSerialPort(SerialPort serialPort) {
        this.serialPort = serialPort;
    }

    public String getLastValue() {
        return this.lastValue;
    }

    public void setLastValue(String lastValue) {
        this.lastValue = lastValue;
    }

    public int getEstatusMaquina() {
        return estatusMaquina;
    }

    public void setEstatusMaquina(int estatusMaquina) {
        this.estatusMaquina = estatusMaquina;
    }

}
