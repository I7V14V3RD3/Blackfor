package mx.com.tecnetia.marcoproyectoseguridad.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.Synchronized;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.AbrirQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.CerrarQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.ReciclarEnQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.ReciclarEnQuioscoV2DTO;
import mx.com.tecnetia.marcoproyectoseguridad.service.ReciclajeService;
import mx.com.tecnetia.orthogonal.dto.IllegalArgumentExceptionDTO;
import mx.com.tecnetia.orthogonal.dto.UnAuthorizedDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/reciclaje")
@Validated
@RequiredArgsConstructor
@Log4j2
@Tag(name = "Proceso de Reciclaje.", description = "Servicios para todo el proceso de reciclaje BioBox en una máquina.")
@ApiResponses(value = {
        @ApiResponse(responseCode = "400", description = "Fallo en el parámetro de entrada.",
                content = @Content(schema = @Schema(implementation = IllegalArgumentExceptionDTO.class))),
        @ApiResponse(responseCode = "401", description = "No autorizado.", content = @Content(schema = @Schema(implementation = UnAuthorizedDTO.class)))})
public class ReciclajeController {
    private final ReciclajeService reciclajeService;

    @Operation(summary = "Realiza el proceso de reciclaje en la máquina. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/free/recicla-producto")
    @Synchronized
    public ResponseEntity<Void> reciclaProducto(@Valid @RequestBody ReciclarEnQuioscoDTO reciclarEnQuioscoDTO) {
        log.info("/free/recicla-producto. Edgar: dime si ves este primer mensaje");
        log.info("Llega esto: {}", reciclarEnQuioscoDTO);
        this.reciclajeService.reciclaProducto(reciclarEnQuioscoDTO);
        log.info("/free/recicla-producto. Edgar: dime si ves este segundo mensaje");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Operation(summary = "Realiza el proceso de reciclaje en la máquina. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/v2/free/recicla-producto")
    @Synchronized
    public ResponseEntity<Void> reciclaProductoV2(@Valid @RequestBody ReciclarEnQuioscoV2DTO reciclarEnQuioscoV2DTO) {
        log.info("/v2/free/recicla-producto. Edgar: dime si ves este primer mensaje");
        log.info("Llega esto v2: {}", reciclarEnQuioscoV2DTO);
        this.reciclajeService.reciclaProductoV2(reciclarEnQuioscoV2DTO);
        log.info("v2/free/recicla-producto. Edgar: dime si ves este segundo mensaje");
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Operation(summary = "Reinicia los sensores y puertas de la máquina. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/free/reinicia-maquina")
    public ResponseEntity<Void> reiniciaMaquina() {
        this.reciclajeService.reiniciaMaquina();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Operation(summary = "Lectura del peso con PLC. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/free/leer-peso-plc")
    public ResponseEntity<Integer> leerPesoPlc() {
        Integer peso = this.reciclajeService.plcLeerPeso();
        return new ResponseEntity<Integer>(peso, HttpStatus.OK);
    }

    @Operation(summary = "Valida el nivel de llenado de la maquina. LISTO.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/free/nivel-llenado-maquina")
    public ResponseEntity<Integer> llenadoMaquina() {
        Integer llenado = this.reciclajeService.validaLlenado();
        return new ResponseEntity<Integer>(llenado, HttpStatus.OK);
    }

    @Operation(summary = "Cerra un quisco.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/free/cerrar-quiosco")
    public ResponseEntity<Void> cerrarQuiosco(@Valid @RequestBody CerrarQuioscoDTO cerrarQuioscoDTO) {
        this.reciclajeService.cerrarQuiosco(cerrarQuioscoDTO.getUsuarioId(), cerrarQuioscoDTO.getQuioscoId(), cerrarQuioscoDTO.getTipoPic());
        return new ResponseEntity<Void>(HttpStatus.OK);
    }

    @Operation(summary = "Abre un quisco.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Operación exitosa.", content = @Content(schema =
            @Schema(implementation = void.class)))})
    @PostMapping(value = "/free/abrir-quiosco")
    public ResponseEntity<Void> abrirQuiosco(@Valid @RequestBody AbrirQuioscoDTO abrirQuioscoDTO) {
        this.reciclajeService.abrirQuiosco(abrirQuioscoDTO.getUsuarioId(), abrirQuioscoDTO.getQuioscoId(), abrirQuioscoDTO.getTipoPic());
        return new ResponseEntity<Void>(HttpStatus.OK);
    }
}
