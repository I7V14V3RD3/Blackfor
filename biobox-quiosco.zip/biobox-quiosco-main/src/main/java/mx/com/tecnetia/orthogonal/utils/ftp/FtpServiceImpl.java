package mx.com.tecnetia.orthogonal.utils.ftp;

import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;

@Service
@Log4j2
public class FtpServiceImpl implements FtpService {

    @Autowired
    @Qualifier("sFtpClientImpl")
    private FtpClient client;

    @Override
    public boolean uploadFile(File file, String path) throws Exception {
        try {
            log.info("Creando connexion ftp...");
            this.client.open();
            log.info("Connexion con ftp creada");
            return this.client.putFileToPath(file, path);
        } catch (IOException e) {
            log.error("No se pudo enviar los archivos ao ftp: {}", e.getMessage());
            return false;
        } finally {
            this.client.close();
            log.info("Connexion ftp cerrada");
        }
    }
}
