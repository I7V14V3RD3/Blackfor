package mx.com.tecnetia.orthogonal.security;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import org.springframework.security.core.GrantedAuthority;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@Schema(description = "DTO para el login del usuario. Dependiendo del tipo de usuario, el campo correspondiente contendrá la información del usuario que se logea.")
public class JwtDTO implements Serializable {
    private String token;
    private String bearer = "Bearer";
    private String nick;
    private String nombre;
    private String apPaterno;
    private String apMaterno;
    private String email;
    private String rol;
    private String telefono;
    private byte[] imagen;
    private Object[] authorities;


    public JwtDTO(){

    }

    public JwtDTO(String token, String nick, String nombre, String apPaterno, String apMaterno, String email, String rol,
                  String telefono,
                  byte[] imagen, Object[] authorities) {
        this.token = token;
        this.nick = nick;
        this.authorities = authorities;
        this.nombre = nombre;
        this.imagen = imagen;
        this.apPaterno = apPaterno;
        this.apMaterno = apMaterno;
        this.email = email;
        this.rol = rol;
        this.telefono = telefono;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getBearer() {
        return bearer;
    }

    public void setBearer(String bearer) {
        this.bearer = bearer;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPaterno() {
        return apPaterno;
    }

    public void setApPaterno(String apPaterno) {
        this.apPaterno = apPaterno;
    }

    public String getApMaterno() {
        return apMaterno;
    }

    public void setApMaterno(String apMaterno) {
        this.apMaterno = apMaterno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    public Object[] getAuthorities() {
        return authorities;
    }

    public void setAuthorities(Object[] authorities) {
        this.authorities = authorities;
    }
}
