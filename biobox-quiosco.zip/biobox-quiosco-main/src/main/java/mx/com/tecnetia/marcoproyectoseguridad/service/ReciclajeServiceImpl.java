package mx.com.tecnetia.marcoproyectoseguridad.service;

import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.marcoproyectoseguridad.dto.catalogo.MensajeDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.*;
import mx.com.tecnetia.marcoproyectoseguridad.util.CodigoRespuestaMaquinaEnum;
import mx.com.tecnetia.orthogonal.security.JwtDTO;
import mx.com.tecnetia.orthogonal.security.LoginUsuarioDTO;
import mx.com.tecnetia.orthogonal.utils.TipoPicEnum;
import mx.com.tecnetia.orthogonal.utils.arduino.ArduinoService;
import mx.com.tecnetia.orthogonal.utils.arduino.CodigoEnum;
import mx.com.tecnetia.orthogonal.utils.foto.FotoService;
import mx.com.tecnetia.orthogonal.utils.plc.PlcService;
import org.bytedeco.javacv.FrameGrabber;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
@Log4j2
public class ReciclajeServiceImpl implements ReciclajeService {

    private final ArduinoService arduinoService;
    private final FotoService fotoService;
    private final Environment environment;
    private final PlcService plcService;
    private ReciclarEnQuioscoV2DTO reciclajeInfoPlc;

    private Future<?> cerrarQuioscoTask;

    private void moverPuerta(boolean abrir) {

        String noHaCerradoPuertaStr = "";
        boolean hayObstaculo = false;
        boolean noHaCerradoPuerta = true;
        int cont = 0;

        do {


            if (!abrir) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {

                }

                do {
                    this.arduinoService.enviarMensaje(CodigoEnum.DETECTAR_OBSTACULO_1.getCodigo(), 1000, CodigoEnum.DETECTAR_OBSTACULO_2.getCodigo());

                    if (hayObstaculo) {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {

                        }
                    }
                } while (hayObstaculo);
            }

            if (abrir) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {

                }
                this.arduinoService.enviarMensaje(CodigoEnum.ABRIR_PUERTA_A_LA_IZQUIERDA.getCodigo(), 1000, null);

            } else {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {

                }
                this.arduinoService.enviarMensaje(CodigoEnum.CERRAR_PUERTA_A_LA_DERECHA.getCodigo(), 2000, null);
                this.arduinoService.enviarMensaje(CodigoEnum.VALIDAR_PUERTA_CERRADA_1.getCodigo(), 1000, CodigoEnum.VALIDAR_PUERTA_CERRADA_2.getCodigo());

                noHaCerradoPuertaStr = this.arduinoService.getCerradoPuerta();
                noHaCerradoPuerta = noHaCerradoPuertaStr == null ? true : (noHaCerradoPuertaStr.equals("") ? true : Integer.parseInt(noHaCerradoPuertaStr) == 1);
            }
        } while (noHaCerradoPuerta && !abrir);
    }

    @Override
    public Integer plcLeerPeso() {
        log.info("LLAMANDO LEER EL PESO DEL PLC");

        return this.plcService.getPesoProducto();
    }



    @Override
    public Integer validaLlenado() {
        Integer distancia = 0;
        log.info("LLAMANDO CON");

        this.arduinoService.abrirConexion();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {

        }
        log.info("LLAMANDO CON FIN");
        try {
            /* SE REINICIAN LOS SENSORES Y MOTORES */
            this.arduinoService.enviarMensaje(CodigoEnum.MEDIR_NIVEL_DEPOSITO.getCodigo(), 1000, null);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {

            }

            String nivelStr = this.arduinoService.getLastValue("Distancia");
            distancia = nivelStr == null ? 0 : (nivelStr.equals("") ? 0 : Integer.parseInt(nivelStr));
        } catch (Exception e) {
            log.error("Error al detectar nivel de deposito: {}", e.getMessage());
        } finally {
            log.info("Cierra arduino");
            this.arduinoService.cerrarConexion();
        }

        return distancia;
    }

    @Override
    public void reiniciaMaquina() {
        this.arduinoService.abrirConexion();
        try {
            /* SE REINICIAN LOS SENSORES Y MOTORES */
            this.arduinoService.enviarMensaje(CodigoEnum.REINICIAR_MAQUINA_1.getCodigo(), 25000, CodigoEnum.REINICIAR_MAQUINA_2.getCodigo());
        } catch (Exception e) {
            log.error("Error al realizar el reciclaje en la máquina: {}", e.getMessage());
        } finally {
            log.info("Cierra arduino");
            this.arduinoService.cerrarConexion();
        }
    }

    public JwtDTO servicioLoginServer() {
        JwtDTO responseEntity = null;
        try {
            String urlEndpoint = environment.getProperty("server.url.service.login");
            String user = environment.getProperty("server.url.service.usr");
            String pwd = environment.getProperty("server.url.service.pwd");
            var restTemplate = new RestTemplate();
            var headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");

            var loginDTO = new LoginUsuarioDTO();
            loginDTO.setNick(user);
            loginDTO.setPassw(pwd);
            var requestEntity = new HttpEntity<>(loginDTO, headers);
            responseEntity = restTemplate.postForObject(urlEndpoint, requestEntity, JwtDTO.class);
        } catch (RestClientException e) {
            log.error("Error al logearse en el servidor: {}", e.getMessage());
            return null;
        }

        return responseEntity == null ? null : responseEntity;
    }

    public boolean servicioValidaFoto(Long idProducto, String foto, String token) {

        try {
            String urlEndpoint = environment.getProperty("server.url.service.valida.producto");
            var restTemplate = new RestTemplate();
            var headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            headers.set("Authorization", "Bearer " + token);

            var reciclaProductoDTO = new ReciclaProductoDTO();
            reciclaProductoDTO.setPrd(idProducto);
            reciclaProductoDTO.setFoto(foto);
            var requestEntity = new HttpEntity<>(reciclaProductoDTO, headers);
            MensajeDTO responseEntity = restTemplate.postForObject(urlEndpoint, requestEntity, MensajeDTO.class);

            if (responseEntity != null) {
                if (responseEntity.getMensaje().equals("")) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (RestClientException e) {
            log.error("Error al invocar el servicio de validación de la foto en el servidor: {}", e.getMessage());
            return false;
        }
    }

    public void servicioReciclaProducto(Long idUsuario, Long idProducto, String foto, Long idQuiosco, Integer codigoRespuesta, String token, Integer peso,
                                        @NotBlank(message = "Falta el bar code") String barCode) {
        try {
            String urlEndpoint = environment.getProperty("server.url.service.recicla.producto");
            var restTemplate = new RestTemplate();
            var headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + token);

            var reciclaProductoQuioscoDTO = new ReciclaProductoQuioscoDTO();
            reciclaProductoQuioscoDTO.setBarCode(barCode);
            reciclaProductoQuioscoDTO.setIdUsuario(idUsuario);
            reciclaProductoQuioscoDTO.setFoto(foto);
            reciclaProductoQuioscoDTO.setIdProducto(idProducto);
            reciclaProductoQuioscoDTO.setIdQuiosco(idQuiosco);
            reciclaProductoQuioscoDTO.setCodigoRespuesta(codigoRespuesta);
            reciclaProductoQuioscoDTO.setPeso(peso);
            var requestEntity = new HttpEntity<>(reciclaProductoQuioscoDTO, headers);
            log.info("Enviando a reciclar: barcode: {}, codigoRespuesta: {}, foto: {}, idProducto: {}, idQuiosco:{}, idUsuario: {}, peso: {}",
                    reciclaProductoQuioscoDTO.getBarCode(), reciclaProductoQuioscoDTO.getCodigoRespuesta(),
                    reciclaProductoQuioscoDTO.getFoto() != null ? reciclaProductoQuioscoDTO.getFoto().length() : null,
                    reciclaProductoQuioscoDTO.getIdProducto(), reciclaProductoQuioscoDTO.getIdQuiosco(),
                    reciclaProductoQuioscoDTO.getIdUsuario(), reciclaProductoQuioscoDTO.getPeso());
            restTemplate.postForObject(urlEndpoint, requestEntity, Void.class);
        } catch (RestClientException e) {
            log.error("Ocurrió un error al guardar el reciclaje en el servidor para el usuario: {}. Error: {}", idUsuario, e.getMessage());
        }
    }

    private void servicioReciclaProductoV2(Long idUsuario, List<Long> idsProducto, Long idQuiosco, Integer codigoRespuesta, String token, Integer peso,
                                           @NotBlank(message = "Falta el bar code") String barCode) {
        try {
            String urlEndpoint = environment.getProperty("server.url.service.recicla.producto");
            var restTemplate = new RestTemplate();
            var headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + token);

            var reciclaProductoQuioscoDTO = new ReciclaProductoQuioscoV2DTO();
            reciclaProductoQuioscoDTO.setBarCode(barCode);
            reciclaProductoQuioscoDTO.setIdUsuario(idUsuario);
            reciclaProductoQuioscoDTO.setIdsProducto(idsProducto);
            reciclaProductoQuioscoDTO.setIdQuiosco(idQuiosco);
            reciclaProductoQuioscoDTO.setCodigoRespuesta(codigoRespuesta);
            reciclaProductoQuioscoDTO.setPeso(peso);
            var requestEntity = new HttpEntity<>(reciclaProductoQuioscoDTO, headers);
            log.info("Url recicla producto V2: {}", urlEndpoint);
            log.info("Enviando a reciclar: V2 barcode: {}, codigoRespuesta: {}, foto: {}, idProducto: {}, idQuiosco:{}, idUsuario: {}, totalObstruccion: {}",
                    reciclaProductoQuioscoDTO.getBarCode(), reciclaProductoQuioscoDTO.getCodigoRespuesta(),
                    reciclaProductoQuioscoDTO.getFoto() != null ? reciclaProductoQuioscoDTO.getFoto().length() : null,
                    reciclaProductoQuioscoDTO.getIdsProducto(), reciclaProductoQuioscoDTO.getIdQuiosco(),
                    reciclaProductoQuioscoDTO.getIdUsuario(), reciclaProductoQuioscoDTO.getPeso());
            restTemplate.postForObject(urlEndpoint, requestEntity, Void.class);
        } catch (RestClientException e) {
            log.error("Ocurrió un error al guardar el reciclaje en el servidor para el usuario: {}. Error: {}", idUsuario, e.getMessage());
            e.printStackTrace();
        }
    }


    public void servicioNotificaTerminoReciclaje(Long idUsuario, String token, Long idQuiosco) {
        try {
            String urlEndpoint = environment.getProperty("server.url.service.notifica.termino");
            var restTemplate = new RestTemplate();
            var headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + token);

            var notificaTerminoReciclajeDTO = new NotificaTerminoReciclajeDTO();
            notificaTerminoReciclajeDTO.setIdUsuario(idUsuario);
            notificaTerminoReciclajeDTO.setIdQuiosco(idQuiosco);
            log.info("Enviando a notificar termino de quiosco {}", idQuiosco);
            var requestEntity = new HttpEntity<>(notificaTerminoReciclajeDTO, headers);
            restTemplate.postForObject(urlEndpoint, requestEntity, Void.class);
        } catch (RestClientException e) {
            log.error("Ocurrió un error al intentar notificar el termino del reciclaje: {}. Error: {}", idUsuario, e.getMessage());
        }
    }

    @Override
    @Async
    public void reciclaProducto(ReciclarEnQuioscoDTO reciclarEnQuioscoDTO) {
        log.info("Inicia reciclaje: " + LocalDateTime.now());

        JwtDTO jwtDTO = this.servicioLoginServer();

        if (jwtDTO != null) {
            /* SE REALIZA EL RECICLAJE DE LA MÁQUINA */
            if (reciclarEnQuioscoDTO.getTipoPic() == TipoPicEnum.ARDUINO.getTipoPic())
                this.arduinoService.abrirConexion();
            /*else
                this.plcService.abrirConexion();*/

            try {
                Thread.sleep(1000);  //ERAN 2
            } catch (InterruptedException e) {

            }
            //Timestamp inicioReciclaje = null;
            Integer peso = null;
            if (reciclarEnQuioscoDTO.getTipoPic() == TipoPicEnum.ARDUINO.getTipoPic()) {
                this.arduinoService.enviarMensaje(CodigoEnum.CICLO_RECICLAJE_COMPLETO_1.getCodigo(), 1000, CodigoEnum.CICLO_RECICLAJE_COMPLETO_2.getCodigo());
                try {
                    Thread.sleep(5000); //ERAN 7
                } catch (InterruptedException e) {

                }
            }//else {
            //inicioReciclaje = new Timestamp(System.currentTimeMillis());
            //this.plcService.enviarMensaje(mx.com.tecnetia.orthogonal.utils.plc.CodigoEnum.CICLO_RECICLAJE_COMPLETO.getCodigo(), 1000);
            //}


            if (reciclarEnQuioscoDTO.getTipoPic() == TipoPicEnum.PLC.getTipoPic()) {
                peso = this.plcService.getPesoProducto();

                this.servicioNotificaTerminoReciclaje(reciclarEnQuioscoDTO.getIdUsuario(), jwtDTO.getToken(), reciclarEnQuioscoDTO.getIdQuiosco());
                this.servicioReciclaProducto(reciclarEnQuioscoDTO.getIdUsuario(), reciclarEnQuioscoDTO.getIdProducto(),
                        null, reciclarEnQuioscoDTO.getIdQuiosco(),
                        peso == null ? CodigoRespuestaMaquinaEnum.FALLO_RECICLAJE.getCodigoRespuesta() : CodigoRespuestaMaquinaEnum.RECICLAJE_EXITOSO.getCodigoRespuesta(),
                        jwtDTO.getToken(), peso, reciclarEnQuioscoDTO.getBarCode());
            } else {
                int i = 1;
                boolean salir = false;
                log.info("Validando puerta cerrada...");
                while (i <= 60 && !salir) {
                    try {
                        Thread.sleep(1000);
                        String puertaCerradaTmp = this.arduinoService.getCerradoPuerta();
                        log.info("Salir? " + puertaCerradaTmp);
                        Boolean tmp = true;
                        if (puertaCerradaTmp != null) {
                            log.info("Salir 2? -" + puertaCerradaTmp + "-");
                            log.info("Salir IF? " + puertaCerradaTmp.equals("true"));
                            log.info("Salir IF 2? " + puertaCerradaTmp.equals(new String("true")));
                            log.info("Salir IF 3? " + Objects.equals(puertaCerradaTmp, new String("true")));
                            log.info("Salir IF 4? " + Boolean.parseBoolean(puertaCerradaTmp));
                            log.info("Salir IF 6? " + (tmp.booleanValue() == Boolean.parseBoolean(puertaCerradaTmp)));

                            salir = true;
                        }
                        i = i + 1;
                    } catch (InterruptedException e) {
                        log.error("Se interrumpió la lectura del peso: " + e.getMessage());
                    } catch (Exception e) {
                        log.error("Error al leer el peso: " + e.getMessage());
                    }
                    log.info("Salir 4? " + salir);
                }
                this.arduinoService.cleanLastValue();

                ///////////////////////////////ETAPA 2////////////////////////////////////////
                /* SE REALIZA LA VALIDACION DE LA FOTO Y TERMINA EL RECICLAJE */
                FrameGrabber frameGrabber = null;

                //TODO: Hay que comentarlo para que no se encimen las fotos, y probarlo dentro del finally
//                this.servicioNotificaTerminoReciclaje(reciclarEnQuioscoDTO.getIdUsuario(), jwtDTO.getToken(), reciclarEnQuioscoDTO.getIdQuiosco());
                try {
                    log.info("Antes de this.fotoService.abrirConexion()");
                    frameGrabber = this.fotoService.abrirConexion();
                    log.info("Luego de this.fotoService.abrirConexion()");
                    log.info("Va a tomar Foto");
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {

                    }
                    log.info("Va a tomar Foto- Despues de delay");
                    byte[] fotoByte = this.fotoService.tomarFoto(frameGrabber);
                    log.info("Foto tomada.");
                    String foto = Base64.getEncoder().encodeToString(fotoByte);
                    //log.info(foto);
                    log.info("Foto tomada antes delay");
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {

                    }
                    log.info("Foto tomada despues delay");
                    if (reciclarEnQuioscoDTO.isMoverCharolaALaDerecha()) {
                        this.arduinoService.enviarMensaje(CodigoEnum.CICLO_FIN_RECICLAJE_GIRO_DER_1.getCodigo(), 1000, CodigoEnum.CICLO_FIN_RECICLAJE_GIRO_DER_2.getCodigo());
                    } else {
                        this.arduinoService.enviarMensaje(CodigoEnum.CICLO_FIN_RECICLAJE_GIRO_IZQ_1.getCodigo(), 1000, CodigoEnum.CICLO_FIN_RECICLAJE_GIRO_IZQ_2.getCodigo());
                    }
                    log.info("Se enviará a reciclar: getIdUsuario: {}, idProducto: {}, foto: {}, idQuiosco: {}, " +
                                    "getCodigoRespuesta: {}, token: {}, {}, getBarCode: {}",
                            reciclarEnQuioscoDTO.getIdUsuario(), reciclarEnQuioscoDTO.getIdProducto(), foto.length(),
                            reciclarEnQuioscoDTO.getIdQuiosco(), CodigoRespuestaMaquinaEnum.RECICLAJE_EXITOSO.getCodigoRespuesta(), jwtDTO.getToken(), null, reciclarEnQuioscoDTO.getBarCode());
                    this.servicioReciclaProducto(reciclarEnQuioscoDTO.getIdUsuario(), reciclarEnQuioscoDTO.getIdProducto(), foto,
                            reciclarEnQuioscoDTO.getIdQuiosco(), CodigoRespuestaMaquinaEnum.RECICLAJE_EXITOSO.getCodigoRespuesta(), jwtDTO.getToken(), null, reciclarEnQuioscoDTO.getBarCode());
                    log.info("Luego de llamada a this.servicioReciclaProducto.");
                } catch (Exception e) {
                    log.error("Error al realizar el reciclaje en la máquina: {}", e.getMessage());
                } finally {
                    log.info("Dentro del finally, antes de this.fotoService.cerrarConexion.");
                    this.fotoService.cerrarConexion(frameGrabber);
                    log.info("Dentro del finally, luego de this.fotoService.cerrarConexion.");
                    this.servicioNotificaTerminoReciclaje(reciclarEnQuioscoDTO.getIdUsuario(), jwtDTO.getToken(), reciclarEnQuioscoDTO.getIdQuiosco());
                    log.info("Dentro del finally, luego de llamar al servidor central (comenté la llamada).");
                }
            }

            log.info("Termina reciclaje: " + LocalDateTime.now());
        }
        log.info("Termina reciclaje - después de foto: " + LocalDateTime.now());
    }

    @Override
    @Async
    public void reciclaProductoV2(ReciclarEnQuioscoV2DTO reciclarEnQuioscoDTO) {
        log.info("Inicia reciclaje V2: " + LocalDateTime.now());

        JwtDTO jwtDTO = this.servicioLoginServer();

        if (jwtDTO != null) {
            /* SE REALIZA EL RECICLAJE DE LA MÁQUINA */
            if (reciclarEnQuioscoDTO.getTipoPic() == TipoPicEnum.PLC.getTipoPic()) {
                reciclajeInfoPlc = reciclarEnQuioscoDTO;
                this.servicioNotificaTerminoReciclaje(reciclarEnQuioscoDTO.getIdUsuario(), jwtDTO.getToken(), reciclarEnQuioscoDTO.getIdQuiosco());
            } else {
                try {
                    log.info("Se enviará a reciclar: getIdUsuario: {}, idProducto: {}, idQuiosco: {}, " +
                                    "getCodigoRespuesta: {}, token: {}, {}, getBarCode: {}",
                            reciclarEnQuioscoDTO.getIdUsuario(), reciclarEnQuioscoDTO.getIdsProducto(),
                            reciclarEnQuioscoDTO.getIdQuiosco(), CodigoRespuestaMaquinaEnum.RECICLAJE_EXITOSO.getCodigoRespuesta(), jwtDTO.getToken(), null, reciclarEnQuioscoDTO.getBarCode());
                    this.servicioReciclaProductoV2(reciclarEnQuioscoDTO.getIdUsuario(), reciclarEnQuioscoDTO.getIdsProducto(),
                            reciclarEnQuioscoDTO.getIdQuiosco(), CodigoRespuestaMaquinaEnum.RECICLAJE_EXITOSO.getCodigoRespuesta(), jwtDTO.getToken(), null, reciclarEnQuioscoDTO.getBarCode());
                    log.info("Luego de llamada a this.servicioReciclaProducto V2.");
                } catch (Exception e) {
                    log.error("Error al realizar el reciclaje en la máquina V2: {}", e.getMessage());
                }
            }

            log.info("Termina reciclaje: " + LocalDateTime.now());
        }
        log.info("Termina reciclaje - después de foto: " + LocalDateTime.now());
    }

    @Override
    @Async
    public void cerrarQuiosco(Long idUsuario, Long idQuiosco, int tipoPic) {
        JwtDTO jwtDTO = this.servicioLoginServer();
        if (tipoPic == TipoPicEnum.ARDUINO.getTipoPic()) {
            this.finalizaReciclajeArduino(idUsuario, idQuiosco);
            if (cerrarQuioscoTask != null)
                cerrarQuioscoTask.cancel(true);
        } else {
            this.finalizaReciclajePlc();
        }
        this.servicioNotificaTerminoReciclaje(idUsuario, jwtDTO.getToken(), idQuiosco);
        log.info("Notificando termino y cerrando Quiosco");
    }

    @Override
    public void abrirQuiosco(Long idUsuario, Long idQuiosco, int tipoPic) {
        try {
            if (tipoPic == TipoPicEnum.ARDUINO.getTipoPic()) {
                ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
                cerrarQuioscoTask = scheduledExecutorService.schedule(() -> this.cerrarQuiosco(idUsuario, idQuiosco, tipoPic), 75, TimeUnit.SECONDS);
                this.arduinoService.abrirConexion();
                Thread.sleep(1000);  //ERAN 2
                this.arduinoService.enviarMensaje(CodigoEnum.CICLO_INICIO_RECICLAJE_ABRIR_PUERTA_1.getCodigo(), 1000, CodigoEnum.CICLO_INICIO_RECICLAJE_ABRIR_PUERTA_2.getCodigo());
                Thread.sleep(5000); //ERAN 7
            } else {
                this.plcService.abrirQuiosco();
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private void finalizaReciclajeArduino(Long idUsuario, Long idQuiosco) {
        try {
            Thread.sleep(3000);
            this.arduinoService.abrirConexion();
            Thread.sleep(1000);
            this.arduinoService.enviarMensaje(CodigoEnum.CICLO_FIN_RECICLAJE_CERRAR_PUERTA_1.getCodigo(), 1000, CodigoEnum.CICLO_FIN_RECICLAJE_CERRAR_PUERTA_2.getCodigo());
            Thread.sleep(1000);
            tomarFoto(idUsuario, idQuiosco);
            this.arduinoService.enviarMensaje(CodigoEnum.CICLO_FIN_RECICLAJE_GIRO_DER_1.getCodigo(), 1000, CodigoEnum.CICLO_FIN_RECICLAJE_GIRO_DER_2.getCodigo());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void finalizaReciclajePlc() {
        JwtDTO jwtDTO = this.servicioLoginServer();
        var totalObstruccion = this.plcService.cerrarQuiosco();
        var diferencia = reciclajeInfoPlc.getIdsProducto().size() - totalObstruccion;
        if (diferencia > 0) {
            reciclajeInfoPlc.getIdsProducto().subList(0, diferencia).clear();
        }
        this.servicioReciclaProductoV2(reciclajeInfoPlc.getIdUsuario(), reciclajeInfoPlc.getIdsProducto(),
                reciclajeInfoPlc.getIdQuiosco(),
                totalObstruccion == null ? CodigoRespuestaMaquinaEnum.FALLO_RECICLAJE.getCodigoRespuesta() : CodigoRespuestaMaquinaEnum.RECICLAJE_EXITOSO.getCodigoRespuesta(),
                jwtDTO.getToken(), totalObstruccion, reciclajeInfoPlc.getBarCode());
        log.info("Finaliza PLC");
    }

    private void tomarFoto(Long idUsuario, Long idQuiosco) {
        try(FrameGrabber frameGrabber = this.fotoService.abrirConexion()) {
            log.info("Va a tomar Foto V2");
            Thread.sleep(1000);
            byte[] fotoByte = this.fotoService.tomarFoto(frameGrabber);
            this.fotoService.guardarFoto(fotoByte, idUsuario, idQuiosco);
            log.info("Foto tomada v2.");
            this.fotoService.cerrarConexion(frameGrabber);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
