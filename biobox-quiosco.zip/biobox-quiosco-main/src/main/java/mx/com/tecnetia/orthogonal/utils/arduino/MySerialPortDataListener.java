package mx.com.tecnetia.orthogonal.utils.arduino;

import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;

@RequiredArgsConstructor
@Log4j2
public class MySerialPortDataListener implements SerialPortDataListener {

    private SerialPort finalSerialPort;
    private Map<String,String> finalLastValue;
    private String valorCompletoConsola;

    public MySerialPortDataListener(SerialPort finalSerialPort, Map<String,String> finalLastValue, String valorCompletoConsola){
        this.finalLastValue = finalLastValue;
        this.finalSerialPort = finalSerialPort;
        this.valorCompletoConsola = valorCompletoConsola;
    }

    @Override
    public int getListeningEvents() {
        return SerialPort.LISTENING_EVENT_DATA_AVAILABLE;
    }

    @Override
    public void serialEvent(SerialPortEvent event) {
        if (event.getEventType() != SerialPort.LISTENING_EVENT_DATA_AVAILABLE)
            return;
        byte[] newData = new byte[19];
        int numRead = finalSerialPort.readBytes(newData, newData.length);

        if(finalLastValue == null) {
            finalLastValue = new HashMap<String, String>();
        }

        String lastValueTmp = new String(newData);
        log.info("Last ValueTmp: "+lastValueTmp);
        log.info("ValorCompConsola: "+valorCompletoConsola);

        if(lastValueTmp.indexOf("#")!=-1){
            if(valorCompletoConsola.equals("")){
                valorCompletoConsola = lastValueTmp.substring(lastValueTmp.indexOf("#") + 1);
                log.info("ValorCompConsola 1.1: "+valorCompletoConsola);
            }else{
                valorCompletoConsola = valorCompletoConsola.concat(lastValueTmp.substring(0,lastValueTmp.indexOf("|")));
                log.info("ValorCompConsola 1.2: "+valorCompletoConsola);
                StringTokenizer tokens = new StringTokenizer(valorCompletoConsola,"|");

                if(tokens.countTokens()>1) {
                    String key=tokens.nextToken();
                    String value = tokens.nextToken();
                    finalLastValue.put(key,value);
                }

                valorCompletoConsola = lastValueTmp.substring(lastValueTmp.indexOf("#") + 1);
            }
        }else{
            if(!valorCompletoConsola.equals("")){
                valorCompletoConsola = valorCompletoConsola.concat(lastValueTmp);
                log.info("ValorCompConsola 1.3: "+valorCompletoConsola);
            }
        }

        for(String key : finalLastValue.keySet()){
            log.info("Last Value - Key: -"+key+"- Value: -"+finalLastValue.get(key)+"-");
            if(key.trim().equals("1")){
                log.info("CERRADO PUERTA: -"+finalLastValue.get(key)+"-");
                log.info(finalLastValue.get(key) == null ? false : (finalLastValue.get(key).equals("true")));
            }
        }
    }

    public Map<String, String> getFinalLastValue() {
        return finalLastValue;
    }

    public void cleanLastValue() {
        finalLastValue = new HashMap<String, String>();
    }

    public void setFinalLastValue(Map<String, String> finalLastValue) {
        this.finalLastValue = finalLastValue;
    }

 }
