package mx.com.tecnetia.orthogonal.utils.arduino;

import com.fazecast.jSerialComm.SerialPort;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
@Log4j2
public class ArduinoService {
    private SerialPort serialPort;
    private Map<String,String> lastValue;
    private String valorCompletoConsola;
    private int estatusMaquina;
    private MySerialPortDataListener mySerialPortDataListener;

    public void abrirConexion() {
        boolean intentarConexion = this.serialPort == null ? true : (this.serialPort.isOpen() ? false : true);
        this.valorCompletoConsola="";
        this.lastValue = new HashMap<String, String>();

        if(intentarConexion) {
            SerialPort[] puertosDisponibles = SerialPort.getCommPorts();
            // use the for loop to print the available serial ports
            for (SerialPort serialPortTmp : puertosDisponibles) {
                if (serialPortTmp.toString().indexOf("Arduino") > -1) {
                    /* Puerto Serial encontrado*/
                    serialPortTmp.openPort();
                    this.serialPort = serialPortTmp;
                }
            }

            log.info("Antes del constructor:"+this.lastValue.toString());
           this.mySerialPortDataListener = new MySerialPortDataListener(this.serialPort, this.lastValue, this.valorCompletoConsola);
           this.serialPort.addDataListener(mySerialPortDataListener);
            log.info("--  DENTRO DEL LISTENER ------");
           log.info(this.mySerialPortDataListener.getFinalLastValue().toString());
            log.info("--  DENTRO DEL SERVICE  ------");
            log.info(this.lastValue.toString());
           log.info("Despues del constructor :"+this.lastValue.toString());
        }
    }

    public void cerrarConexion() {
        try {
            if (this.serialPort.isOpen()) //Check whether port open/not
                this.serialPort.closePort(); //Close the port
        } catch (Exception e) {

        }
    }

    public void enviarMensaje(int mensaje1, int sleepMsAfter, Integer mensaje2) {


        byte[] writeByte = new byte[mensaje2 == null ? 1 : 2];
        writeByte[0] = (byte) mensaje1; //Código ASCII
        if (mensaje2 != null)
            writeByte[1] = (byte) mensaje2.intValue(); //Código ASCII
        int bytesTxed = 0;

        log.info("Enviando mensaje... M1: "+mensaje1+" - M2:"+mensaje2);

        bytesTxed = this.serialPort.writeBytes(writeByte, mensaje2 == null ? 1 : 2);
        try {
            Thread.sleep(sleepMsAfter);
        } catch (InterruptedException e) {

        }

    }



    public SerialPort getSerialPort() {
        return this.serialPort;
    }

    public void setSerialPort(SerialPort serialPort) {
        this.serialPort = serialPort;
    }

    public void cleanLastValue() {
        this.lastValue = new HashMap<String, String>();
        this.mySerialPortDataListener.cleanLastValue();
    }
     public String getCerradoPuerta() {
        log.info("GetCerradoPuerta Last Value - Value: -"+this.lastValue.get("1")+"-");

        log.info("--  DENTRO DEL SERVICE  ------");
        String atr= "1";
        String lastValueStr = this.lastValue.toString();
        log.info(this.lastValue.toString());
        log.info("StrTmp: "+lastValueStr);

        lastValueStr = lastValueStr.substring(lastValueStr.indexOf(atr)+atr.length()+1);
        log.info("StrTmp 2: "+lastValueStr);

        if(lastValueStr!=null){
            if(!lastValueStr.equals("")){
                if(lastValueStr.indexOf(",")!=-1){
                    lastValueStr = lastValueStr.substring(0,lastValueStr.indexOf(","));
                }else{
                    lastValueStr = lastValueStr.substring(0,lastValueStr.indexOf("}"));
                }
            }
        }

        log.info("StrTmp 3: "+lastValueStr);

        return lastValueStr;
    }

    public String getLastValue(String nombreAtributo) {
        log.info("--  DENTRO DEL SERVICE  ------");
        String atr= "1";
        String lastValueStr = this.lastValue.toString();
        log.info(this.lastValue.toString());
        log.info("StrTmp: "+lastValueStr);

        lastValueStr = lastValueStr.substring(lastValueStr.indexOf(atr)+atr.length()+1);
        log.info("Atr: "+atr);
        log.info("StrTmp 2: "+lastValueStr);

        if(lastValueStr!=null){
            if(!lastValueStr.equals("")){
                if(lastValueStr.indexOf(",")!=-1){
                    lastValueStr = lastValueStr.substring(0,lastValueStr.indexOf(","));
                }else{
                    lastValueStr = lastValueStr.substring(0,lastValueStr.indexOf("}"));
                }
            }
        }

        log.info("StrTmp 3: "+lastValueStr);

        return lastValueStr;
    }

    public void setLastValue(String nombreAtributo , String lastValue) {
        if(this.lastValue != null)
            this.lastValue.put(nombreAtributo,lastValue);
    }

    public int getEstatusMaquina() {
        return estatusMaquina;
    }

    public void setEstatusMaquina(int estatusMaquina) {
        this.estatusMaquina = estatusMaquina;
    }


    public static void main(String[] args) {
        Map<String, String> mp = new HashMap<String, String>();
        mp.put("1","true");
        String l = mp.toString();
        String atr="1";
        String l2 = l.substring(l.indexOf(atr)+atr.length()+1);
        String l3 = l.substring(l.indexOf("1")+"1".length()+1);

        String lastValueStr ="{1=true}";
        log.info("StrTmp: "+lastValueStr);

        lastValueStr = lastValueStr.substring(lastValueStr.indexOf(atr)+atr.length()+1);
        log.info("StrTmp 2: "+lastValueStr);

        if(l2!=null){
            if(!l2.equals("")){
                if(l2.indexOf(",")!=-1){
                    l3 = l2.substring(0,l2.indexOf(","));
                }else{
                    l3 = l2.substring(0,l2.indexOf("}"));
                }
            }
        }

        System.out.println(l);
        System.out.println(l2);
        System.out.println("-"+l3+"-");

        mp.put("2","344");
        l = mp.toString();
        atr="2";
        l2 = l.substring(l.indexOf(atr)+atr.length()+1);
        l3 = l.substring(l.indexOf("2")+"2".length()+1);

        if(l2!=null){
            if(!l2.equals("")){
                if(l2.indexOf(",")!=-1){
                    l3 = l2.substring(0,l2.indexOf(","));
                }else{
                    l3 = l2.substring(0,l2.indexOf("}"));
                }
            }
        }

        System.out.println(l);
        System.out.println(l2);
        System.out.println("-"+l3+"-");

    }
}
