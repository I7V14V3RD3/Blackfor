package mx.com.tecnetia.orthogonal.utils.notificaciones;

public enum StepEnum {
    RECICLAJE_EXITOSO(1),
    RECICLAJE_FALLO(2);

    private int step;

    StepEnum(int step){
        this.step = step;
    }
    public int getStep() {
        return step;
    }

    public void setCodigo(int step) {
        this.step = step;
    }


}
