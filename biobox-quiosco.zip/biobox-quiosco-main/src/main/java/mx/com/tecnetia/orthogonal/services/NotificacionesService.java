package mx.com.tecnetia.orthogonal.services;

public interface NotificacionesService {
    //void guardarToken(Long idUsuario, String token);
}
