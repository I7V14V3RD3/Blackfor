package mx.com.tecnetia.orthogonal.utils.ftp;

import java.io.File;
import java.io.IOException;

public interface FtpClient {

    void open() throws Exception;

    void close() throws IOException;

    boolean putFileToPath(File file, String path) throws IOException;
}
