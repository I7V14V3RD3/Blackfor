package mx.com.tecnetia.orthogonal.utils.ftp;

import java.io.File;

public interface FtpService {

    boolean uploadFile(File file, String path) throws Exception;
}
