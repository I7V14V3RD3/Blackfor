package mx.com.tecnetia.orthogonal.services;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.dto.MailDTO;
import mx.com.tecnetia.orthogonal.security.NuevoUsuarioArquitecturaDTO;
import mx.com.tecnetia.orthogonal.security.UsuarioPrincipal;
import mx.com.tecnetia.orthogonal.security.auth.AuthenticationFacadeComponent;
import mx.com.tecnetia.orthogonal.utils.crypto.AES;
import mx.com.tecnetia.orthogonal.utils.email.EmailOperationsThymeleafService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Log4j2
public class UsuarioServiceImpl implements UsuarioService {
    /*private final ArqUsuarioRepository arqUsuarioRepository;
    private final ArqRolAplicacionRepository arqRolAplicacionRepository;
    private final PasswordEncoder passwordEncoder;
    private final ArqUsuarioRolAplicacionEntityRepository arqUsuarioRolAplicacionEntityRepository;
    private final ArqClienteEntityRepository arqClienteEntityRepository;
    private final AuthenticationFacadeComponent authenticationFacadeComponent;
    private final UsuarioPuntosColorEntityRepository usuarioPuntosColorEntityRepository;
    private final ColorEntityRepository colorEntityRepository;
    private final FotoUsuarioEntityRepository fotoUsuarioEntityRepository;
    private final SpringTemplateEngine thymeleafTemplateEngine;
    private final EmailOperationsThymeleafService emailOperationsThymeleafService;
*/
    @Value("${cliente.codigo}")
    private String codigoCliente;

    final String secretKey = "ssshhhhhhhhhhh!!!!";

   /* @Override
    @Transactional
    public ArqUsuarioEntity guardar(ArqUsuarioEntity usuario) {
        return arqUsuarioRepository.save(usuario);
    }

    @Override
    @Transactional
    public ArqUsuarioEntity guardar(NuevoUsuarioArquitecturaDTO nuevoUsuario, byte[] foto, String nombreFoto) {
        this.existeUsuario(nuevoUsuario);
        var usuarioEntity = new ArqUsuarioEntity();
        usuarioEntity.setActivo(true);
        usuarioEntity.setNombres(nuevoUsuario.getNombres());
        usuarioEntity.setNick(nuevoUsuario.getEmail().toLowerCase());
        usuarioEntity.setTelefono(nuevoUsuario.getTelefono());
        usuarioEntity.setPassw(passwordEncoder.encode(nuevoUsuario.getPassw()));
        usuarioEntity.setApellidoMaterno(nuevoUsuario.getApellidoMaterno());
        usuarioEntity.setApellidoPaterno(nuevoUsuario.getApellidoPaterno());
        usuarioEntity.setEmail(nuevoUsuario.getEmail().toLowerCase());
        usuarioEntity.setPendienteConfirmacion(false);
        var cliente = this.arqClienteEntityRepository.findByCodigoAndActivoIsTrue(codigoCliente)
                .orElseThrow(() -> new IllegalArgumentException("No está asignado el código del cliente en la BD"));
        usuarioEntity.setArqClienteByIdArqCliente(cliente);
        usuarioEntity = this.guardar(usuarioEntity);

        var rolEsp = this.arqRolAplicacionRepository.findByNombre(nuevoUsuario.getRol())
                .orElseThrow(() -> new IllegalArgumentException("El rol especificado no es válido."));

        var arqUsuarioRolAplicacion = new ArqUsuarioRolEntity();
        arqUsuarioRolAplicacion.setArqUsuarioByIdArqUsuario(usuarioEntity);
        arqUsuarioRolAplicacion.setArqRolByIdArqRol(rolEsp);

        this.arqUsuarioRolAplicacionEntityRepository.save(arqUsuarioRolAplicacion);

        var usuarioPuntosColorEntity = new UsuarioPuntosColorEntity();
        for(ColorEntity colorEntity : this.colorEntityRepository.findAll()){
            usuarioPuntosColorEntity = new UsuarioPuntosColorEntity();
            usuarioPuntosColorEntity.setIdArqUsuario(usuarioEntity.getIdArqUsuario());
            usuarioPuntosColorEntity.setPuntos(0);
            usuarioPuntosColorEntity.setColorByIdColor(colorEntity);
            this.usuarioPuntosColorEntityRepository.save(usuarioPuntosColorEntity);
        }

        var fotoUsuarioEntity = new FotoUsuarioEntity();
        fotoUsuarioEntity.setArqUsuarioEntity(usuarioEntity);
        fotoUsuarioEntity.setNombreFoto(nombreFoto);
        fotoUsuarioEntity.setFoto(foto);
        this.fotoUsuarioEntityRepository.save(fotoUsuarioEntity);

        log.info("Usuario de arquitectura guardado satisfactorimente.");
        return usuarioEntity;
    }*/

    //@Override
    public boolean cambiaContrasena(Long idUsuario, String anterior, String nueva) {
        return false;
    }

    /*@Override
    @Transactional(readOnly = true)
    public String generaToken(@Email @NotEmpty String email) {
        this.arqUsuarioRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("El email no existe en nuestra base de datos"));
        var builder = new StringBuilder();
        builder.append(email).append(",").append(LocalDateTime.now().plusHours(1));
        return AES.encrypt(builder.toString(), secretKey);
    }*/


    //@Override
    //@Transactional(readOnly = true)
    public String encrypt(@NotEmpty String msg) {
        return AES.encrypt(msg, secretKey);
    }

//    @Override
    //@Transactional(readOnly = true)
    public String decrypt(@NotEmpty String msg) {
        return AES.decrypt(msg, secretKey);
    }

    /*@Override
    @Transactional(readOnly = true)
    public Optional<ArqUsuarioEntity> getByNick(String nick) {
        return this.arqUsuarioRepository.findByNick(nick);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ArqUsuarioEntity> getByEmail(String email) {
        return this.arqUsuarioRepository.findByEmail(email);
    }*/

    //@Override
   // @Transactional(readOnly = true)
    public boolean existePorNick(String nu) {
        return false;
    }

   // @Override
    //@Transactional(readOnly = true)
    public boolean existePorEmail(String email) {
        return false;
    }

    /*@Transactional(readOnly = true)
    public void existeUsuario(NuevoUsuarioArquitecturaDTO nuevoUsuario) {
        if (this.arqUsuarioRepository.existsByEmail(nuevoUsuario.getEmail().toLowerCase()))
            throw new IllegalArgumentException("El email ya está registrado.");
        if (this.arqUsuarioRepository.existsByNick(nuevoUsuario.getNick().toLowerCase()))
            throw new IllegalArgumentException("El nick ya está registrado.");
    }

    @Override
    @Transactional
    public void cambiaPassw(UsuarioPrincipal usuarioLogeado, String passw) {
        ArqUsuarioEntity arqUsuarioEnt = arqUsuarioRepository.findByEmail(usuarioLogeado.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("El email del usuario logeado no aparece en la BD."));
        arqUsuarioEnt.setPassw(passwordEncoder.encode(passw));
        this.arqUsuarioRepository.save(arqUsuarioEnt);
    }*/

   /* @Override
    @Transactional
    public void recuperaPassw(String userMail) {
        ArqUsuarioEntity arqUsuarioEnt = arqUsuarioRepository.findByEmail(userMail)
                .orElseThrow(() -> new IllegalArgumentException("El email del usuario logeado no aparece en la BD."));
        String pwd = AES.obtenerPalabraAleatoria();
        arqUsuarioEnt.setPassw(passwordEncoder.encode(pwd));
        this.arqUsuarioRepository.save(arqUsuarioEnt);

        var model = new HashMap<String, Object>();
        model.put("contrasenia", pwd);
        var templateThymeleafFile = "cambio-pwd-email-thymeleaf.html";
        var mailDTO = new MailDTO();
        mailDTO.setMailTo(userMail);
        mailDTO.setMailSubject("BioBox - Nueva contraseña");
        mailDTO.setModel(model);
        try{
            this.emailOperationsThymeleafService.sendEmail(mailDTO, templateThymeleafFile);
        } catch (Exception ex) {
            log.error("Ocurrió un error al enviar el email con la nueva contraseña: {}", ex.getMessage());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public ArqUsuarioEntity getUsuarioLogeado() {
        var usuarioLogeado = (UsuarioPrincipal) authenticationFacadeComponent.getAuthentication().getPrincipal();
        return this.arqUsuarioRepository.findByEmail(usuarioLogeado.getEmail().toLowerCase())
                .orElseThrow(() -> new IllegalArgumentException("El email del usuario logeado no aparece en la BD"));
    }

    @Override
    @Transactional(readOnly = true)
    public ArqUsuarioEntity findById(Long id) {
        return this.arqUsuarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("No existe el usuario especificado."));
    }

    @Override
    @Transactional(readOnly = true)
    public Long getIdUsuarioLogeado() {
        return this.getUsuarioLogeado().getIdArqUsuario();
    }*/
}
