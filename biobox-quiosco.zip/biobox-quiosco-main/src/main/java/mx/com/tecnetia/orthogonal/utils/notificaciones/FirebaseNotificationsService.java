package mx.com.tecnetia.orthogonal.utils.notificaciones;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.dto.notificaciones.FirebaseNotificationDTO;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Log4j2
public class FirebaseNotificationsService {
    //private final ArqPropiedadEntityRepository arqPropiedadEntityRepository;
    private final Environment environment;

    //@Async("asyncExecutor")
    /*public void sendNotification(FirebaseNotificationDTO firebaseNotificationDTO) {
        String title = environment.getProperty("notification.firebase.title");
        String sound = environment.getProperty("notification.firebase.sound");
        String contentAvailable = environment.getProperty("notification.firebase.content_available");
        String priority = environment.getProperty("notification.firebase.priority");

        firebaseNotificationDTO.getNotification().setSound(this.arqPropiedadEntityRepository.findArqPropiedadEntitiesByActivoIsTrueAndCodigo(sound)
                .orElseThrow(() -> new IllegalArgumentException("No existe en la BD: " + sound)).getValor());
        firebaseNotificationDTO.getNotification().setTitle(this.arqPropiedadEntityRepository.findArqPropiedadEntitiesByActivoIsTrueAndCodigo(title)
                .orElseThrow(() -> new IllegalArgumentException("No existe en la BD: " + title)).getValor());
        String contentAvailableStr =  this.arqPropiedadEntityRepository.findArqPropiedadEntitiesByActivoIsTrueAndCodigo(contentAvailable)
                .orElseThrow(() -> new IllegalArgumentException("No existe en la BD: " + contentAvailable)).getValor();
        firebaseNotificationDTO.setContent_available(contentAvailableStr != null ? (contentAvailableStr.equals("") ? null : Integer.getInteger(contentAvailableStr)) : null);
        firebaseNotificationDTO.setPriority(this.arqPropiedadEntityRepository.findArqPropiedadEntitiesByActivoIsTrueAndCodigo(priority)
                .orElseThrow(() -> new IllegalArgumentException("No existe en la BD: " + priority)).getValor());
*/
        /* ENVIAR NOTIFICACION */
    //}
}
