package mx.com.tecnetia.orthogonal.utils.ftp;

import com.jcraft.jsch.*;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;

@Component("sFtpClientImpl")
@Log4j2
public class SFtpClientImpl implements FtpClient {

    @Value("${ftp.host}")
    private String host;

    @Value("${ftp.port}")
    private int port;

    @Value("${ftp.username}")
    private String username;

    @Value("${ftp.password}")
    private String password;

    @Value("${ftp.dir}")
    private String ftpDir;

    private ChannelSftp channelSftp;

    public void open() throws Exception {
        try {
            JSch jsch = new JSch();
            Session jschSession = jsch.getSession(username, host, port);
            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            jschSession.setConfig(config);
            jschSession.setPassword(password);
            jschSession.connect();
            channelSftp = (ChannelSftp) jschSession.openChannel("sftp");
        } catch (Exception exception) {
            log.info("Error al conectar por sftp: {} ", exception.getMessage());
            throw new IOException("No se pudo conectar al servidor ftp");
        }
    }

    @Override
    public void close() throws IOException {
        channelSftp.exit();
    }

    @Override
    public boolean putFileToPath(File file, String path) throws IOException {
        try {
            log.info("Enviando el archivo {} para la carpeta {} por sftp.", file.getPath(), path);
            channelSftp.connect();
            channelSftp.cd(ftpDir); // Entra en el directorio /DATA
            channelSftp.mkdir(path.split("/")[2]); // Crea carpeta quiosco en el ftp server
            channelSftp.put(file.getPath(), path);
            log.info("Se envio las fotos de forma exitosa");
            return true;
        } catch (SftpException exception) {
            log.error("Error on send file Sftp {}", exception.getMessage());
            return false;
        } catch (JSchException e) {
            log.error("Error on connect Sftp server: {}", e.getMessage());
            return false;
        }
    }
}
