package mx.com.tecnetia.orthogonal.utils.foto;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.bytedeco.javacpp.opencv_core;
import org.bytedeco.javacpp.opencv_imgcodecs;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;
import org.bytedeco.javacv.OpenCVFrameConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.concurrent.ExecutionException;

@Service
@RequiredArgsConstructor
@Log4j2
public class FotoService {
    //private final ArqPropiedadEntityRepository arqPropiedadEntityRepository;
    private final Environment environment;
    private FrameGrabber grabber;
    @Value("${dir.fotos}")
    private String dirFotos;

    @PostConstruct
    void onInit() throws FrameGrabber.Exception {

        this.grabber = FrameGrabber.createDefault(0);
        this.grabber.setImageWidth(1920);
        this.grabber.setImageHeight(1080);
        this.grabber.setDeinterlace(true);
        this.grabber.setTriggerMode(true);
        this.grabber.setBitsPerPixel(24);
        this.grabber.setTimestamp(10000);
        this.grabber.delayedGrab(10000);

    }

    public FrameGrabber abrirConexion() {
        if (this.grabber != null) {
            try {
                this.grabber.start();
            } catch (FrameGrabber.Exception e) {
                try {
                    grabber.stop();
                } catch (FrameGrabber.Exception e2) {
                    log.error("Fallo al cerrar conexion de la camara: {}", e2.getMessage());
                }
                try {
                    this.grabber.start();
                } catch (FrameGrabber.Exception e2) {
                    log.error("Fallo al abrir la conexion de la camara: {}", e2.getMessage());
                }
            }

        } else {
            try {
                this.grabber = FrameGrabber.createDefault(0);
                this.grabber.setImageWidth(1920);
                this.grabber.setImageHeight(1080);
                this.grabber.setDeinterlace(true);
                this.grabber.setTriggerMode(true);
                this.grabber.setBitsPerPixel(24);
                this.grabber.setTimestamp(1000);
                this.grabber.delayedGrab(1000);
            } catch (FrameGrabber.Exception e) {
                log.error("Fallo al crear conexion de la camara: {}", e.getMessage());
            }
        }
/*        try {
            Runtime.getRuntime().exec("C:\\Program Files (x86)\\Common Files\\LogiShrd\\LogiUCDpp\\LogitechCamera.exe", null,
                    new File("C:\\Program Files (x86)\\Common Files\\LogiShrd\\LogiUCDpp\\"));
        } catch (IOException e) {
            log.error("Fallo al abrir el setup de la maquina para el enfoque: {}", e.getMessage());
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            log.error("Fallo al esperar un seg al abrir la conexion: {}", e.getMessage());
        }
*/

        return this.grabber;
    }

    public void cerrarConexion(FrameGrabber grabber) {
        log.info("Dentro de cerrar conexión de la camara.");
        if (grabber != null) {
            try {
                log.info("Dentro de cerrar conexión de la camara. Antes de grabber.stop()");
                grabber.stop();
                log.info("Dentro de cerrar conexión de la camara. Después de grabber.stop()");
            } catch (FrameGrabber.Exception e) {
                log.error("Fallo al cerrar conexion de la camara: {}", e.getMessage());
            }
        }
    }

    public byte[] tomarFoto(FrameGrabber grabber) {
        if (grabber == null) {
            return null;
        }
        byte[] foto = new byte[1];
        String nombreFoto = "fotoBiobox.jpg";
        foto[0] = 1;
        try {
            log.info("Tomando foto: 1 **");
            grabber.delayedGrab(10000);
            log.info("Tomando foto: 2 **");
            grabber.setTimestamp(10000);
            log.info("Tomando foto: 3 **");
          /*  try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                log.error("Fallo en el delay: {}", e.getMessage());
            }*/
            //Frame frame = this.grabber.grab();
            Frame frame = grabber.getDelayedFrame();
            log.info("Tomando foto: 4 **");
            OpenCVFrameConverter.ToIplImage converter = new OpenCVFrameConverter.ToIplImage();
            log.info("Tomando foto: 5 **");

            opencv_core.IplImage img = converter.convertToIplImage(frame);
            log.info("Tomando foto: 6 **");

            opencv_imgcodecs.cvSaveImage(nombreFoto, img);
            log.info("Tomando foto: 7 **");

            foto = Files.readAllBytes(Paths.get(nombreFoto));
            log.info("Tomando foto: 8 **");

        } catch (FrameGrabber.Exception e) {
            log.error("No se pudo tomar la foto con la máquina: {}", e.getMessage());
        } catch (IOException e) {
            log.error("No se pudo tomar la foto con la máquina: {}", e.getMessage());
        } catch (ExecutionException e) {
            log.error("No se pudo tomar la foto con la máquina: {}", e.getMessage());
        } catch (InterruptedException e) {
            log.error("No se pudo tomar la foto con la máquina: {}", e.getMessage());
        }

        return foto;
    }

    public static void main(String[] args) {


        FrameGrabber grabberTmp = null;
        try {
            grabberTmp = FrameGrabber.createDefault(0);
        } catch (FrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }
        grabberTmp.setImageWidth(1920);
        grabberTmp.setImageHeight(1080);
        grabberTmp.setDeinterlace(true);
        grabberTmp.setTriggerMode(true);
        grabberTmp.setBitsPerPixel(24);

//        try {
        //          Runtime.getRuntime().exec("C:\\Program Files (x86)\\Common Files\\LogiShrd\\LogiUCDpp\\LogitechCamera.exe", null,
        //                new File("C:\\Program Files (x86)\\Common Files\\LogiShrd\\LogiUCDpp\\"));
        //  } catch (IOException e) {
        //    throw new RuntimeException(e);
        //}

        try {
            grabberTmp.start();
        } catch (FrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }


        byte[] foto = new byte[1];
        String nombreFoto = "fotoBiobox.jpg";
        foto[0] = 1;
        try {

            grabberTmp.setTimestamp(10000);

            Frame frame = grabberTmp.grab();
            OpenCVFrameConverter.ToIplImage converter = new OpenCVFrameConverter.ToIplImage();
            opencv_core.IplImage img = converter.convertToIplImage(frame);
            opencv_imgcodecs.cvSaveImage(nombreFoto, img);
            foto = Files.readAllBytes(Paths.get(nombreFoto));
            System.out.println(Base64.getEncoder().encodeToString(foto));

        } catch (FrameGrabber.Exception e) {
            log.error("No se pudo tomar la foto con la máquina: {}", e.getMessage());
        } catch (IOException e) {
            log.error("No se pudo tomar la foto con la máquina: {}", e.getMessage());
        }

    }

    public void guardarFoto(byte[] foto, Long idUsuario, Long idQuiosco) {
        Date fecha = new Date();
        long segundos = fecha.getTime() / 1000;
        SimpleDateFormat df = new SimpleDateFormat("ddMMyyyy");

        Path carpeta = Paths.get(dirFotos + "/" + df.format(fecha));
        Path archivo = Paths.get(carpeta.toString(), idQuiosco + "-" + idUsuario + "-"  + segundos + ".jpg");

        try {
            if (Files.notExists(carpeta)) {
                Files.createDirectories(carpeta);
            }
            if (Files.notExists(archivo)) {
                Files.createFile(archivo);
            }
            log.info("Guardando fotos. Carpeta: {}, Archivo: {}", carpeta.getFileName(), archivo.getFileName());
            Files.write(archivo.toFile().toPath(), foto);
        } catch (IOException e) {
            log.error("Ocurrió un error al guardar las fotos en la carpeta: {}. Error: {}",
                    carpeta.getFileName(), e.getMessage());
        }
    }
}
