package mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.repository;

import mx.com.tecnetia.marcoproyectoseguridad.persistence.hibernate.entity.ModbusData2Entity;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.Optional;

//@Repository
public interface ModbusData2EntityRepository //extends JpaRepository<ModbusData2Entity, Integer>
 {
    ModbusData2Entity findFirstByOrderByRecIdDesc();
    /*@Query("""
            select ent
            from ModbusData2Entity ent where ent.timestamp > :timestampInicial and ent.item2 = '1'
            """)*/
    Optional<ModbusData2Entity> getUltimoPeso(/*@Param("timestampInicial")*/Timestamp timestampInicial);
}