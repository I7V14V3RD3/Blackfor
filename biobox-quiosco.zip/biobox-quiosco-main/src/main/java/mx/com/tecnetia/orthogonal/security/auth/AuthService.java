package mx.com.tecnetia.orthogonal.security.auth;

import mx.com.tecnetia.orthogonal.security.JwtDTO;
import mx.com.tecnetia.orthogonal.security.LoginUsuarioDTO;
import mx.com.tecnetia.orthogonal.dto.NuevoUsuarioArquitecturaDTO;

public interface AuthService {
    void crearNuevoUsuario(NuevoUsuarioArquitecturaDTO nuevoUsuario);

    JwtDTO login(LoginUsuarioDTO loginUsuario);

}
