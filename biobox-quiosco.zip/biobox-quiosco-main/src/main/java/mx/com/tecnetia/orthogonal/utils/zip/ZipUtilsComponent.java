package mx.com.tecnetia.orthogonal.utils.zip;

import jakarta.validation.constraints.NotNull;
import mx.com.tecnetia.orthogonal.dto.csv.CsvBean;

import java.nio.file.Path;
import java.util.List;

public interface ZipUtilsComponent {

    void descomprimirArchivo(@NotNull String archivoZip, @NotNull String directorioSalida);
}
