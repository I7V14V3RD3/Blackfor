package mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO del termino del reciclaje para notificar a la app.")
public class CerrarQuioscoDTO implements Serializable {
    private Long usuarioId;
    private Long quioscoId;
    private int tipoPic;
}
