package mx.com.tecnetia.marcoproyectoseguridad.service;

import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.CerrarQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.ReciclarEnQuioscoDTO;
import mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje.ReciclarEnQuioscoV2DTO;

public interface ReciclajeService {

    void reciclaProducto(ReciclarEnQuioscoDTO reciclarEnQuioscoDTO);
    void reciclaProductoV2(ReciclarEnQuioscoV2DTO reciclarEnQuioscoDTO);
    void reiniciaMaquina();
    Integer validaLlenado();
    Integer plcLeerPeso();
    void cerrarQuiosco(Long idUsuario, Long idQuiosco, int tipoPic);
    void abrirQuiosco(Long idUsuario, Long idQuiosco, int tipoPic);
  }
