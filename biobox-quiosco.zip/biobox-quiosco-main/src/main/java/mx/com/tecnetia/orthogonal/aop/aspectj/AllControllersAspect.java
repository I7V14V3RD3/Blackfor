package mx.com.tecnetia.orthogonal.aop.aspectj;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import mx.com.tecnetia.orthogonal.components.ServicioRestDataComponent;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import java.util.concurrent.TimeUnit;

@Log4j2
@Component
@Aspect
@RequiredArgsConstructor
public class AllControllersAspect {
    private final ServicioRestDataComponent servicioRestDataComponent;

    @Pointcut("@within(org.springframework.web.bind.annotation.RestController)")
    public void restControllerMethods() {
    }

/*    @Before("@within(org.springframework.web.bind.annotation.RestController)")
    public void logMethod(JoinPoint joinPoint) {
        log.info("Entrando a: {}", joinPoint);
        log.info("Argumentos: {}", joinPoint.getArgs());

        HttpServletRequest request = ((ServletRequestAttributes)
                RequestContextHolder.currentRequestAttributes()).getRequest();

        String param = StringUtils.substringAfter(request.getRequestURI(), request.getContextPath());
        String method = request.getMethod();
        log.info("El servicio está disponible: {}", this.servicioRestDataComponent.isActive(param, method));

        request.getRequestURI() == "/Marco/catalogo/servicios"
        request.getContextPath() == "/Marco"
        request.getMethod() == "GET"

        log.info("AOP. Antes del rest controller: {}", request.getRequestURL().toString());
        log.info("AOP. Nos llaman desde: {}. Host: {}. Puerto: {}", request.getRemoteAddr(), request.getRemoteHost(), request.getRemotePort());
    }*/

    @Around("restControllerMethods()")
    public Object measureMethodExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        HttpServletRequest request = ((ServletRequestAttributes)
                RequestContextHolder.currentRequestAttributes()).getRequest();
        long initialTime = System.nanoTime();
        var uri = request.getRequestURL().toString();
        String methodName = joinPoint.getSignature().getName();
        log.info("{} {}. Inicio", methodName, request.getRequestURL().toString());
        Object returnedObject = joinPoint.proceed();
        log.info("{} {}. Fin", methodName, request.getRequestURL().toString());
        long endTime = System.nanoTime();
        log.info("La ejecución de {} llevó {} ms", uri, TimeUnit.NANOSECONDS.toMillis(endTime - initialTime));
        return returnedObject;
    }
}
