package mx.com.tecnetia.marcoproyectoseguridad.dto.reciclaje;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO del reciclado de un producto en máquina.")
public class ReciclaProductoQuioscoDTO implements Serializable {
    private Long idProducto;
    private String foto;
    private Long idQuiosco;
    private Integer codigoRespuesta;
    private Long idUsuario;
    private Integer peso;
    private String barCode;
}
