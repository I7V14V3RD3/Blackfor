package mx.com.tecnetia.orthogonal.utils.ftp;

import lombok.extern.log4j.Log4j2;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.ftp.FTPSClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.*;

@Component
@Log4j2
public class FtpsClientImpl implements FtpClient {

    @Value("${ftp.host}")
    private String host;

    @Value("${ftp.port}")
    private int port;

    @Value("${ftp.username}")
    private String user;

    @Value("${ftp.password}")
    private String password;

    @Value("${ftp.dir}")
    private String ftpDir;

    private FTPSClient ftp;

    public void open() throws IOException {
        ftp = new FTPSClient();
        ftp.connect(host, port);
        int reply = ftp.getReplyCode();
        if (!FTPReply.isPositiveCompletion(reply)) {
            ftp.disconnect();
            throw new IOException("Exception in connecting to FTP Server");
        }
        ftp.login(user, password);
        ftp.enterLocalPassiveMode();
        ftp.setFileType(FTP.BINARY_FILE_TYPE);
        ftp.setFileTransferMode(FTP.BINARY_FILE_TYPE);
    }

    public void close() throws IOException {
        ftp.disconnect();
    }

    public boolean putFileToPath(File file, String path) throws IOException {
        log.info("Enviando el archivo {} para la carpeta {} por ftps.", file.getPath(), path);
        boolean isUploadSuccess = false;
        try (InputStream inputStream = new FileInputStream(file)) {
            ftp.changeWorkingDirectory(ftpDir);
            ftp.makeDirectory(path.split("/")[2]); // cria un directorio con el quiosco id
            isUploadSuccess = ftp.storeFile(path, inputStream);
            if (isUploadSuccess) {
                log.info("Se envio el archivo de forma exitosa");
            }
            else {
                log.info("No se envio las fotos");
            }
        }
        return isUploadSuccess;
    }
}
