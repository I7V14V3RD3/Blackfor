package mx.com.tecnetia.orthogonal.services;

import mx.com.tecnetia.orthogonal.security.NuevoUsuarioArquitecturaDTO;
import mx.com.tecnetia.orthogonal.security.UsuarioPrincipal;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
//import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

public interface UsuarioService {
    /*@Transactional(readOnly = true)
    String encrypt(@NotEmpty String msg);

    @Transactional(readOnly = true)
    String decrypt(@NotEmpty String msg);
*/
    //Optional<ArqUsuarioEntity> getByNick(String nu);

    //Optional<ArqUsuarioEntity> getByEmail(String email);

   // boolean existePorNick(String nu);

    //boolean existePorEmail(String email);

    //ArqUsuarioEntity guardar(ArqUsuarioEntity usuario);

   // ArqUsuarioEntity guardar(NuevoUsuarioArquitecturaDTO nuevoUsuario, byte[] foto, String nombreFoto);

  //  boolean cambiaContrasena(Long idUsuario, String anterior, String nueva);

    //String generaToken(@Email @NotEmpty String email);

   // void cambiaPassw(UsuarioPrincipal usuarioLogeado, String passw);

 //   void recuperaPassw(String userMail);

    //ArqUsuarioEntity getUsuarioLogeado();

    //ArqUsuarioEntity findById(Long id);
   // Long getIdUsuarioLogeado();
}
