package mx.com.tecnetia.orthogonal.utils.arduino;

public enum CodigoEnum {
    /*   DOCUMENTACIÓN DEL ARDUINO DESDE IDE (CODIGO FUENTE ORIGINAL)
            case 1: Serial.println("Gira Derecha Motor 1. Abre puerta.");
            case 2: Serial.println("Gira Izquierda Motor 1. Cierra puerta.");
            case 3: Serial.println("Gira Derecha Motor 2. Gira charola.");
            case 4: Serial.println("Gira Izquierda Motor 2. Gira charola.");
            case 5: Serial.println("Prende led Rojo");
            case 6: Serial.println("Prende led Verde");
            case 7: Serial.print("Prende led Azul");
            case 8: Serial.println("Apagar led");
            case 9: Serial.println("Midiendo llenado de contenedor");
            case 10: Serial.println("Reiniciar y probar sensores");
            case 11: Serial.println("Detecta obstaculo");
            case 10: Serial.println("Prende led blanco para foto (flash)");

            SE DEBEN CONVERITIR A CODIGOS ASCII
        */

    ABRIR_PUERTA_A_LA_IZQUIERDA(50),
    CERRAR_PUERTA_A_LA_DERECHA(49),
    GIRAR_CHAROLA_A_LA_DERECHA(51),
    GIRAR_CHAROLA_A_LA_IZQUIERDA(52),
    PRENDER_LED_ROJO(53),
    PRENDER_LED_VERDE(54),
    PRENDER_LED_AZUL(55),
    APAGAR_LED(56),
    MEDIR_NIVEL_DEPOSITO(57),
    REINICIAR_MAQUINA_1(49),
    REINICIAR_MAQUINA_2(48),
    DETECTAR_OBSTACULO_1(49),
    DETECTAR_OBSTACULO_2(49),
    PRENDER_LED_BLANCO_1(49),
    PRENDER_LED_BLANCO_2(50),
    APAGAR_LED_BLANCO_1(49),
    APAGAR_LED_BLANCO_2(53),
    VALIDAR_PUERTA_CERRADA_1(49),

    VALIDAR_PUERTA_CERRADA_2(51),
    CICLO1_RECICLAJE_1(49),
    CICLO1_RECICLAJE_2(56),
    CICLO2_RECICLAJE_EXITOSO_1(49),
    CICLO2_RECICLAJE_EXITOSO_2(57),
    CICLO2_RECICLAJE_FALLO_1(50),
    CICLO2_RECICLAJE_FALLO_2(48),
    CICLO_RECICLAJE_COMPLETO_1(49),
    CICLO_RECICLAJE_COMPLETO_2(56),
    CICLO_FIN_RECICLAJE_GIRO_DER_1(49),
    CICLO_FIN_RECICLAJE_GIRO_DER_2(57),
    CICLO_FIN_RECICLAJE_GIRO_IZQ_1(50),
    CICLO_FIN_RECICLAJE_GIRO_IZQ_2(48),
    CICLO_FIN_RECICLAJE_CERRAR_PUERTA_1(50),
    CICLO_FIN_RECICLAJE_CERRAR_PUERTA_2(56),
    CICLO_INICIO_RECICLAJE_ABRIR_PUERTA_1(50),
    CICLO_INICIO_RECICLAJE_ABRIR_PUERTA_2(55);

    private int codigo;

    CodigoEnum(int codigo){
        this.codigo = codigo;
    }
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

}
